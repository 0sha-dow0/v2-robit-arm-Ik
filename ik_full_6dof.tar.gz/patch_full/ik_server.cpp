#include "common/skill_types.h"
#include "common/config_loader.h"
#include "common/safety.h"
#include "ik/ik_solver.h"
#include "ik/kinematics.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <cstring>
#include <chrono>
#include <unistd.h>
#include <Eigen/Dense>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

static float readLocalFloat(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}

static float clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static void clientWriteFloat(UA_Client *c, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteBool(UA_Client *c, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteUInt32(UA_Client *c, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}

// Build rotation matrix from roll/pitch/yaw (ZYX Tait-Bryan)
static Eigen::Matrix3d rpyToR(double roll, double pitch, double yaw) {
    Eigen::Matrix3d Rz, Ry, Rx;
    double cy = cos(yaw), sy = sin(yaw);
    double cp = cos(pitch), sp = sin(pitch);
    double cr = cos(roll), sr = sin(roll);
    Rz << cy, -sy, 0,  sy, cy, 0,  0, 0, 1;
    Ry << cp, 0, sp,   0, 1, 0,   -sp, 0, cp;
    Rx << 1, 0, 0,   0, cr, -sr,  0, sr, cr;
    return Rz * Ry * Rx;
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    std::string config_path = "configs/ik.yaml";
    if (argc > 1) config_path = argv[1];

    printf("═══════════════════════════════════════════\n");
    printf("  IK Server v4 — FULL 6-DOF world control\n");
    printf("═══════════════════════════════════════════\n");

    teleop::IKConfig config;
    try { config = teleop::loadIKConfig(config_path); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    UA_Server *server = UA_Server_new();
    UA_ServerConfig *sc = UA_Server_getConfig(server);
    UA_ServerConfig_setMinimal(sc, config.opcua_port, NULL);
    if (teleop::addCartesianInputSkillNodes(server) != UA_STATUSCODE_GOOD) return 1;
    if (UA_Server_run_startup(server) != UA_STATUSCODE_GOOD) return 1;
    printf("[IK] server on port %d\n", config.opcua_port);

    UA_Client *fb_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(fb_client));
    bool fb_connected = false;

    UA_Client *bridge_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(bridge_client));
    bool bridge_connected = false;

    teleop::ik::IKParams ik_params;
    ik_params.max_iterations = config.max_iterations;
    ik_params.eps_pos = config.eps_pos;
    ik_params.eps_ori = config.eps_ori;
    ik_params.damping_lambda = config.damping_lambda;
    ik_params.jl_weight = 0.05;  // gentle joint-limit push
    auto limits = teleop::ik::JointLimitsEigen::vx300();

    Eigen::Matrix<double, 5, 1> current_joints; current_joints.setZero();

    // Target pose broken into position + RPY for intuitive integration
    Eigen::Vector3d target_pos(0.4, 0.0, 0.3);
    double target_roll = 0.0, target_pitch = 0.0, target_yaw = 0.0;
    bool have_initial_pose = false;

    printf("[IK] Running at 50 Hz.\n\n");
    int period_us = 20000;
    uint32_t loop_count = 0;
    double dt = 0.02;

    while (g_running) {
        UA_Server_run_iterate(server, false);

        if (!fb_connected) {
            if (UA_Client_connect(fb_client, config.feedback_endpoint.c_str())
                == UA_STATUSCODE_GOOD) { fb_connected = true; printf("[IK] fb ok\n"); }
        }
        if (!bridge_connected) {
            if (UA_Client_connect(bridge_client, config.bridge_endpoint.c_str())
                == UA_STATUSCODE_GOOD) { bridge_connected = true; printf("[IK] bridge ok\n"); }
        }

        if (fb_connected) {
            for (int i = 0; i < 5; i++) {
                current_joints(i) = (double)clientReadFloat(fb_client,
                    teleop::opcua_ids::FB_JOINT_POS_BASE + i);
            }
        }

        float vx  = readLocalFloat(server, teleop::opcua_ids::CART_VEL_X);
        float vy  = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Y);
        float vz  = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Z);
        float vroll  = readLocalFloat(server, teleop::opcua_ids::CART_VEL_ROLL);
        float vpitch = readLocalFloat(server, teleop::opcua_ids::CART_VEL_PITCH);
        float vyaw   = readLocalFloat(server, teleop::opcua_ids::CART_VEL_YAW);
        float grip = readLocalFloat(server, teleop::opcua_ids::CART_GRIPPER);

        if (!have_initial_pose && fb_connected) {
            Eigen::Matrix4d T = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
            target_pos = T.block<3, 1>(0, 3);
            // extract initial RPY from rotation
            Eigen::Matrix3d R = T.block<3, 3>(0, 0);
            target_yaw   = atan2(R(1,0), R(0,0));
            target_pitch = atan2(-R(2,0), sqrt(R(2,1)*R(2,1) + R(2,2)*R(2,2)));
            target_roll  = atan2(R(2,1), R(2,2));
            have_initial_pose = true;
            printf("[IK] init pos=(%.3f,%.3f,%.3f) rpy=(%.2f,%.2f,%.2f)\n",
                   target_pos(0), target_pos(1), target_pos(2),
                   target_roll, target_pitch, target_yaw);
        }

        // WORLD-FRAME integration for position and RPY
        if (have_initial_pose) {
            target_pos(0) += vx * config.linear_vel_scale * dt;
            target_pos(1) += vy * config.linear_vel_scale * dt;
            target_pos(2) += vz * config.linear_vel_scale * dt;

            target_roll  += vroll  * config.angular_vel_scale * dt;
            target_pitch += vpitch * config.angular_vel_scale * dt;
            target_yaw   += vyaw   * config.angular_vel_scale * dt;

            // workspace clamp
            target_pos(0) = std::max(0.08, std::min(0.55, target_pos(0)));
            target_pos(1) = std::max(-0.40, std::min(0.40, target_pos(1)));
            target_pos(2) = std::max(0.02, std::min(0.55, target_pos(2)));
        }

        // Build target pose
        Eigen::Matrix4d T_target = Eigen::Matrix4d::Identity();
        T_target.block<3, 3>(0, 0) = rpyToR(target_roll, target_pitch, target_yaw);
        T_target.block<3, 1>(0, 3) = target_pos;

        Eigen::Matrix<double, 5, 1> new_joints = current_joints;
        bool ik_ok = false;
        if (have_initial_pose) {
            ik_ok = teleop::ik::solveIK(T_target, current_joints,
                                         ik_params, limits, new_joints);
            // If IK fails, revert target to prevent runaway
            if (!ik_ok) {
                Eigen::Matrix4d T_now = teleop::ik::fkInSpace(
                    teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
                target_pos = T_now.block<3,1>(0,3);
                Eigen::Matrix3d R = T_now.block<3,3>(0,0);
                target_yaw   = atan2(R(1,0), R(0,0));
                target_pitch = atan2(-R(2,0), sqrt(R(2,1)*R(2,1) + R(2,2)*R(2,2)));
                target_roll  = atan2(R(2,1), R(2,2));
                new_joints = current_joints;
            }
        }

        const float BRIDGE_MAX_RAD_S = 1.0f;
        float jvel[5];
        for (int i = 0; i < 5; i++) {
            double raw_vel = (new_joints(i) - current_joints(i)) / dt;
            float n = (float)(raw_vel / BRIDGE_MAX_RAD_S);
            if (n > 1.0f) n = 1.0f;
            if (n < -1.0f) n = -1.0f;
            jvel[i] = n;
        }

        if (bridge_connected) {
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WAIST,       jvel[0]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_SHOULDER,    jvel[1]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_ELBOW,       jvel[2]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ANGLE, jvel[3]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ROT,   jvel[4]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::GRIPPER_CMD,           grip);
            clientWriteBool (bridge_client, teleop::opcua_ids::DEADMAN, true);
            clientWriteUInt32(bridge_client, teleop::opcua_ids::STAMP, loop_count);
        }

        if (++loop_count % 25 == 0) {
            printf("[IK] pos=(%.3f,%.3f,%.3f) rpy=(%+.2f,%+.2f,%+.2f) ik_ok=%d\n",
                   target_pos(0), target_pos(1), target_pos(2),
                   target_roll, target_pitch, target_yaw, ik_ok);
        }

        usleep(period_us);
    }

    if (fb_connected) UA_Client_disconnect(fb_client);
    UA_Client_delete(fb_client);
    if (bridge_connected) UA_Client_disconnect(bridge_client);
    UA_Client_delete(bridge_client);
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    return 0;
}
