// IK Server v9 — ALL STEP-BASED (each tap = one increment)
#include "common/skill_types.h"
#include "common/config_loader.h"
#include "ik/ik_solver.h"
#include "ik/kinematics.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <cmath>
#include <chrono>
#include <unistd.h>
#include <Eigen/Dense>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

static float readLocalFloat(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static float clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static void clientWriteFloat(UA_Client *c, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteBool(UA_Client *c, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteUInt32(UA_Client *c, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}

static Eigen::Matrix3d rpyToR(double roll, double pitch, double yaw) {
    double cy = cos(yaw), sy = sin(yaw);
    double cp = cos(pitch), sp = sin(pitch);
    double cr = cos(roll), sr = sin(roll);
    Eigen::Matrix3d Rz, Ry, Rx;
    Rz << cy, -sy, 0,  sy, cy, 0,  0, 0, 1;
    Ry << cp, 0, sp,   0, 1, 0,   -sp, 0, cp;
    Rx << 1, 0, 0,   0, cr, -sr,  0, sr, cr;
    return Rz * Ry * Rx;
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    std::string config_path = "configs/ik.yaml";
    if (argc > 1) config_path = argv[1];

    printf("==========================================\n");
    printf("  IK Server v9 — FULL STEP MODE\n");
    printf("  Tap key = one step. No hold-to-move.\n");
    printf("==========================================\n");

    teleop::IKConfig config;
    try { config = teleop::loadIKConfig(config_path); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    UA_Server *server = UA_Server_new();
    UA_ServerConfig_setMinimal(UA_Server_getConfig(server), config.opcua_port, NULL);
    if (teleop::addCartesianInputSkillNodes(server) != UA_STATUSCODE_GOOD) return 1;
    if (UA_Server_run_startup(server) != UA_STATUSCODE_GOOD) return 1;

    UA_Client *fb_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(fb_client));
    bool fb_connected = false;
    UA_Client *bridge_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(bridge_client));
    bool bridge_connected = false;

    teleop::ik::IKParams ik_params;
    ik_params.max_iterations = config.max_iterations;
    ik_params.eps_pos = config.eps_pos;
    ik_params.eps_ori = config.eps_ori;
    ik_params.damping_lambda = config.damping_lambda;
    ik_params.jl_weight = 0.02;
    auto limits = teleop::ik::JointLimitsEigen::vx300();

    // --- STEP SIZES (tune these) ---
    const double STEP_POS   = 0.02;   // 2 cm per tap
    const double STEP_PITCH = 0.10;   // ~5.7 degrees per tap
    const double STEP_YAW   = 0.10;
    const float  STEP_GRIP  = 0.15f;  // 15% gripper travel per tap

    Eigen::Matrix<double, 5, 1> current_joints; current_joints.setZero();
    Eigen::Vector3d target_pos(0.4, 0.0, 0.3);
    double target_pitch = 0, target_yaw = 0;
    float gripper_pos = 0.0f;
    bool have_initial = false;

    const float DEADZONE = 0.05f;

    // Edge-detection state for every axis, both directions
    bool prev_x_pos = false, prev_x_neg = false;
    bool prev_y_pos = false, prev_y_neg = false;
    bool prev_z_pos = false, prev_z_neg = false;
    bool prev_pitch_pos = false, prev_pitch_neg = false;
    bool prev_yaw_pos = false, prev_yaw_neg = false;
    bool prev_grip_pos = false, prev_grip_neg = false;

    int period_us = 20000;
    uint32_t loop_count = 0;
    double dt = 0.02;

    printf("[IK] ALL keys are step-based. Tap once = one small step.\n\n");

    while (g_running) {
        UA_Server_run_iterate(server, false);

        if (!fb_connected && UA_Client_connect(fb_client, config.feedback_endpoint.c_str())
            == UA_STATUSCODE_GOOD) { fb_connected = true; printf("[IK] fb ok\n"); }
        if (!bridge_connected && UA_Client_connect(bridge_client, config.bridge_endpoint.c_str())
            == UA_STATUSCODE_GOOD) { bridge_connected = true; printf("[IK] bridge ok\n"); }

        if (fb_connected) {
            for (int i = 0; i < 5; i++) {
                current_joints(i) = (double)clientReadFloat(fb_client,
                    teleop::opcua_ids::FB_JOINT_POS_BASE + i);
            }
        }

        float vx = readLocalFloat(server, teleop::opcua_ids::CART_VEL_X);
        float vy = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Y);
        float vz = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Z);
        float vpitch = readLocalFloat(server, teleop::opcua_ids::CART_VEL_PITCH);
        float vyaw = readLocalFloat(server, teleop::opcua_ids::CART_VEL_YAW);
        float vgrip = readLocalFloat(server, teleop::opcua_ids::CART_GRIPPER);

        // Edge detection for every axis
        bool x_pos = vx >  DEADZONE, x_neg = vx < -DEADZONE;
        bool y_pos = vy >  DEADZONE, y_neg = vy < -DEADZONE;
        bool z_pos = vz >  DEADZONE, z_neg = vz < -DEADZONE;
        bool p_pos = vpitch >  DEADZONE, p_neg = vpitch < -DEADZONE;
        bool w_pos = vyaw   >  DEADZONE, w_neg = vyaw   < -DEADZONE;
        bool g_pos = vgrip  >  DEADZONE, g_neg = vgrip  < -DEADZONE;

        if (!have_initial && fb_connected) {
            Eigen::Matrix4d T = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
            target_pos = T.block<3,1>(0,3);
            Eigen::Matrix3d R = T.block<3,3>(0,0);
            target_yaw = atan2(R(1,0), R(0,0));
            target_pitch = atan2(-R(2,0), sqrt(R(2,1)*R(2,1) + R(2,2)*R(2,2)));
            have_initial = true;
            printf("[IK] init pos=(%.2f,%.2f,%.2f)\n",
                   target_pos(0), target_pos(1), target_pos(2));
        }

        // STEP on key-press edge (transition from not-pressed to pressed)
        bool step = false;
        if (x_pos && !prev_x_pos) { target_pos(0) += STEP_POS; step = true; printf("[STEP] +X -> %.3f\n", target_pos(0)); }
        if (x_neg && !prev_x_neg) { target_pos(0) -= STEP_POS; step = true; printf("[STEP] -X -> %.3f\n", target_pos(0)); }
        if (y_pos && !prev_y_pos) { target_pos(1) += STEP_POS; step = true; printf("[STEP] +Y -> %.3f\n", target_pos(1)); }
        if (y_neg && !prev_y_neg) { target_pos(1) -= STEP_POS; step = true; printf("[STEP] -Y -> %.3f\n", target_pos(1)); }
        if (z_pos && !prev_z_pos) { target_pos(2) += STEP_POS; step = true; printf("[STEP] +Z -> %.3f\n", target_pos(2)); }
        if (z_neg && !prev_z_neg) { target_pos(2) -= STEP_POS; step = true; printf("[STEP] -Z -> %.3f\n", target_pos(2)); }
        if (p_pos && !prev_pitch_pos) { target_pitch += STEP_PITCH; step = true; printf("[STEP] +pitch -> %.2f\n", target_pitch); }
        if (p_neg && !prev_pitch_neg) { target_pitch -= STEP_PITCH; step = true; printf("[STEP] -pitch -> %.2f\n", target_pitch); }
        if (w_pos && !prev_yaw_pos)   { target_yaw   += STEP_YAW;   step = true; printf("[STEP] +yaw -> %.2f\n", target_yaw); }
        if (w_neg && !prev_yaw_neg)   { target_yaw   -= STEP_YAW;   step = true; printf("[STEP] -yaw -> %.2f\n", target_yaw); }
        if (g_pos && !prev_grip_pos)  {
            gripper_pos += STEP_GRIP;
            if (gripper_pos > 1.0f) gripper_pos = 1.0f;
            step = true; printf("[STEP] grip open -> %.2f\n", gripper_pos);
        }
        if (g_neg && !prev_grip_neg)  {
            gripper_pos -= STEP_GRIP;
            if (gripper_pos < -1.0f) gripper_pos = -1.0f;
            step = true; printf("[STEP] grip close -> %.2f\n", gripper_pos);
        }

        prev_x_pos = x_pos; prev_x_neg = x_neg;
        prev_y_pos = y_pos; prev_y_neg = y_neg;
        prev_z_pos = z_pos; prev_z_neg = z_neg;
        prev_pitch_pos = p_pos; prev_pitch_neg = p_neg;
        prev_yaw_pos = w_pos; prev_yaw_neg = w_neg;
        prev_grip_pos = g_pos; prev_grip_neg = g_neg;

        // Clamp
        target_pos(0) = std::max(0.08, std::min(0.55, target_pos(0)));
        target_pos(1) = std::max(-0.40, std::min(0.40, target_pos(1)));
        target_pos(2) = std::max(0.02, std::min(0.55, target_pos(2)));
        target_pitch = std::max(-1.5, std::min(1.5, target_pitch));
        target_yaw   = std::max(-3.14, std::min(3.14, target_yaw));

        Eigen::Matrix4d T_target = Eigen::Matrix4d::Identity();
        T_target.block<3,3>(0,0) = rpyToR(0, target_pitch, target_yaw);
        T_target.block<3,1>(0,3) = target_pos;

        // IK always runs to drive arm toward target
        Eigen::Matrix<double, 5, 1> new_joints = current_joints;
        bool ik_ok = false;
        if (have_initial) {
            ik_ok = teleop::ik::solveIK(T_target, current_joints,
                                         ik_params, limits, new_joints);
            if (!ik_ok) new_joints = current_joints;
        }

        const float BRIDGE_MAX = 1.0f;
        float jvel[5];
        for (int i = 0; i < 5; i++) {
            double raw = (new_joints(i) - current_joints(i)) / dt;
            float n = (float)(raw / BRIDGE_MAX);
            if (n > 1.0f) n = 1.0f; if (n < -1.0f) n = -1.0f;
            jvel[i] = n;
        }

        if (bridge_connected) {
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WAIST,       jvel[0]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_SHOULDER,    jvel[1]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_ELBOW,       jvel[2]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ANGLE, jvel[3]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ROT,   jvel[4]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::GRIPPER_CMD,           gripper_pos);
            clientWriteBool (bridge_client, teleop::opcua_ids::DEADMAN, true);
            clientWriteUInt32(bridge_client, teleop::opcua_ids::STAMP, loop_count);
        }

        loop_count++;
        usleep(period_us);
    }

    if (fb_connected) UA_Client_disconnect(fb_client);
    UA_Client_delete(fb_client);
    if (bridge_connected) UA_Client_disconnect(bridge_client);
    UA_Client_delete(bridge_client);
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    return 0;
}
