# Proper Fix — Based on Deep Research of Interbotix SDK

## Root Cause

Our system was streaming `JointGroupCommand` at 50 Hz into an arm in **position** control
mode with **time** profile. The Interbotix SDK's own production code proves this is wrong:

```python
# Production Interbotix pattern:
set_trajectory_time(moving_time)     # tell arm how long move should take
pub_group.publish(positions)         # send ONE command
rospy.sleep(moving_time)             # WAIT for completion
# Now ready for next command
```

Our bridge was publishing every 20 ms — each new command overrode the previous before
the arm could complete it. Arm kept re-interpolating toward a moving goal → barely moves,
drifts, misbehaves.

## The Fix

Replace IK server + bridge with a single ROS 2 node `opcua_teleop` that:

1. Reads OPC UA input pulses from port 4840 (input server stays as-is)
2. On each key edge → updates absolute target → runs IK → publishes ONE
   position command → sleeps for `moving_time` before polling for next pulse
3. Uses `yaw = atan2(y, x)` per Interbotix convention for 5-DOF arms
4. Gripper via PWM single-joint command

**Our custom PoE IK stays** (capstone contribution intact).

## Install

1. Install the files:
```bash
cd ~/Downloads
tar xzf opcua_teleop.tar.gz

PROJ=~/Downloads/v2-robit-arm-Ik-master/teleop_opcua_v2
cp proper/opcua_teleop.cpp       $PROJ/src/opcua_teleop.cpp
cp proper/keyboard.yaml          $PROJ/configs/keyboard.yaml
cp proper/keyboard_handler.cpp   $PROJ/src/input/keyboard_handler.cpp
```

2. Update CMakeLists.txt: append the contents of `proper/CMakeLists_add.txt` to the end
   of `$PROJ/CMakeLists.txt`.

3. Verify `interbotix_xs_msgs` is in `package.xml` as a build/exec dependency:
```xml
<depend>interbotix_xs_msgs</depend>
```

4. Build:
```bash
source /opt/ros/humble/setup.bash
source ~/interbotix_ws/install/setup.bash
cd $PROJ/build
cmake ..
make -j$(nproc)
```

## Run

**Terminal 1 — Arm:**
```bash
cd ~/interbotix_ws
source install/setup.bash
ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=vx300 use_rviz:=true
```

**Terminal 2 — Input skill server:**
```bash
cd ~/Downloads/v2-robit-arm-Ik-master/teleop_opcua_v2/build
./input_skill_server ../configs/keyboard.yaml
```

**Terminal 3 — NEW teleop node (replaces IK server + bridge):**
```bash
source /opt/ros/humble/setup.bash
source ~/interbotix_ws/install/setup.bash
cd ~/Downloads/v2-robit-arm-Ik-master/teleop_opcua_v2/build
./opcua_teleop
```

That's it. **No selector, no bridge, no separate IK server.** Three terminals total for
the motion path (plus any dashboards/diagnostics you want).

## Controls

| Key | Action | Step |
|-----|--------|------|
| W/S | ±x (forward/back) | 1 cm |
| A/D | ±y (left/right) | 1 cm |
| R/F | ±z (up/down) | 1 cm |
| I/K | pitch up/down | 5° |
| J/L | wrist rotate CCW/CW | 5° |
| O/P | gripper open/close | PWM 150 for 200 ms |

Each tap = one discrete move. Arm moves for 250 ms (moving_time), then is ready for
the next command. If IK fails (target unreachable), target does NOT advance — arm
holds position.

## What the log looks like (T3)

Per keypress you should see:
```
[CMD] pos=(0.170,0.000,0.210) yaw=0.00 pitch=0.00 wrist=-0.63
      → joints=(-0.00,-1.80,1.50,0.20,-0.63)
```

and the arm visibly moves 1 cm in that direction, then stops.

## Why this works

- **One command per move** — matches the arm's position-mode expectations
- **Fixed moving_time of 250 ms** — smooth, predictable
- **Blocking sleep** — no command overruns
- **Absolute target state** — no integration drift
- **OPC UA skill layer preserved** — keyboard still publishes the Cartesian
  input skill for the report / architectural story
