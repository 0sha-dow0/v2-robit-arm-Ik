# Root Cause (verified against Interbotix production code)

Our architecture was streaming **velocities at 50 Hz** through:
keyboard → input → selector → IK → bridge → `JointGroupCommand` at 50 Hz → arm

This fundamentally fights the Interbotix SDK's own model. Their working `InterbotixArmXSInterface`:

```python
def publish_positions(self, positions, moving_time=0.2, blocking=True):
    self.set_trajectory_time(moving_time, accel_time)      # SetMotorRegisters service
    self.core.pub_group.publish(JointGroupCommand(name, positions))
    if blocking:
        rospy.sleep(self.moving_time)                      # ← CRITICAL: let motion finish
    self.T_sb = mr.FKinSpace(M, Slist, positions)          # update internal model
```

The arm in `position` mode with `time` profile expects ONE command → SLEEP for moving_time → next command. We were firing 50 cmds/sec at it, each one overwriting the previous before it completed. Result: the arm kept re-interpolating toward a moving target. Barely moves.

# Fix

1. **Single "Interbotix-style" teleop node** replaces IK server + bridge.
2. **Target state**: absolute `(x, y, z, pitch, wrist, gripper)`.
3. **Keypress → update state → IK → `publish_positions(joints)` → rospy.sleep(moving_time)**.
4. **No velocity streaming**. No selector-level pulse forwarding needed.
5. IK = our existing custom PoE IK (keeps capstone contribution intact).
6. yaw = atan2(y, x). No independent yaw (Interbotix docs confirm: "yaw parameter always ignored for <6-DOF arms").

# Architecture preserved

Keyboard → OPC UA Input Skill (port 4840) → **new `opcua_teleop` node** → ROS 2 publish.

OPC UA skill model stays (capstone contribution). Only the "IK server + bridge" duo gets replaced with one node that publishes positions correctly and sleeps.
