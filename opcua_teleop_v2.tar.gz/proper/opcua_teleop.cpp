// ─────────────────────────────────────────────────────────────────────
// opcua_teleop — ROS 2 node that replaces both IK server and bridge.
//
// Architecture:
//   Keyboard → OPC UA Input Skill (4840) → THIS NODE → ROS 2 publish
//
// Control loop (matches Interbotix SDK's own pattern):
//   1. Read current joint state from /vx300/joint_states subscription
//   2. Read Cartesian input pulses from OPC UA input server (port 4840)
//   3. On rising-edge of a key: update absolute target (x,y,z,pitch,wrist,gripper)
//   4. Run PoE IK (our custom solver) → target joint positions
//   5. Publish JointGroupCommand ONCE, then sleep(moving_time)
//   6. Next iteration
//
// Key difference from the broken bridge: publish-then-sleep matches how
// the Interbotix xs_sdk expects commands in position+time-profile mode.
// No streaming at 50 Hz — one command per keystroke.
//
// yaw = atan2(y, x) — 5-DOF vx300 has no independent yaw.
// ─────────────────────────────────────────────────────────────────────

#include "common/skill_types.h"
#include "common/config_loader.h"
#include "ik/ik_solver.h"
#include "ik/kinematics.h"

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <interbotix_xs_msgs/msg/joint_group_command.hpp>
#include <interbotix_xs_msgs/msg/joint_single_command.hpp>
#include <interbotix_xs_msgs/srv/register_values.hpp>

#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <Eigen/Dense>
#include <csignal>
#include <cstdio>
#include <cmath>
#include <chrono>
#include <thread>
#include <atomic>
#include <mutex>

using namespace std::chrono_literals;

static std::atomic<bool> g_running{true};
static void sig_handler(int) { g_running = false; }

// ── OPC UA client read helpers ──
static float clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}

// ── rpy → rotation matrix (ZYX) ──
static Eigen::Matrix3d rpyToR(double roll, double pitch, double yaw) {
    double cy = cos(yaw), sy = sin(yaw);
    double cp = cos(pitch), sp = sin(pitch);
    double cr = cos(roll), sr = sin(roll);
    Eigen::Matrix3d Rz, Ry, Rx;
    Rz << cy, -sy, 0,  sy, cy, 0,  0, 0, 1;
    Ry << cp, 0, sp,   0, 1, 0,   -sp, 0, cp;
    Rx << 1, 0, 0,   0, cr, -sr,  0, sr, cr;
    return Rz * Ry * Rx;
}

class OpcuaTeleop : public rclcpp::Node {
public:
    OpcuaTeleop() : Node("opcua_teleop") {
        // ── ROS 2 interfaces ──
        auto qos = rclcpp::QoS(10);
        pub_group_ = create_publisher<interbotix_xs_msgs::msg::JointGroupCommand>(
            "/vx300/commands/joint_group", qos);
        pub_single_ = create_publisher<interbotix_xs_msgs::msg::JointSingleCommand>(
            "/vx300/commands/joint_single", qos);
        sub_joints_ = create_subscription<sensor_msgs::msg::JointState>(
            "/vx300/joint_states", qos,
            std::bind(&OpcuaTeleop::jointStateCb, this, std::placeholders::_1));

        reg_client_ = create_client<interbotix_xs_msgs::srv::RegisterValues>(
            "/vx300/set_motor_registers");

        RCLCPP_INFO(get_logger(), "opcua_teleop node starting");

        // ── Joint limits ──
        limits_ = teleop::ik::JointLimitsEigen::vx300();

        // ── IK parameters ──
        ik_params_.max_iterations = 50;
        ik_params_.eps_pos = 1e-3;
        ik_params_.eps_ori = 100.0;   // POSITION-ONLY for 5-DOF (ignore orientation)
        ik_params_.damping_lambda = 0.1;
        ik_params_.jl_weight = 0.02;

        current_joints_.setZero();
        last_solution_.setZero();

        // ── OPC UA input client ──
        ua_client_ = UA_Client_new();
        UA_ClientConfig_setDefault(UA_Client_getConfig(ua_client_));
    }

    ~OpcuaTeleop() {
        if (ua_connected_) UA_Client_disconnect(ua_client_);
        UA_Client_delete(ua_client_);
    }

    void jointStateCb(const sensor_msgs::msg::JointState::SharedPtr msg) {
        std::lock_guard<std::mutex> lock(state_mutex_);
        // vx300 joint order is fixed: waist, shoulder, elbow, wrist_angle, wrist_rotate
        const std::vector<std::string> want = {
            "waist", "shoulder", "elbow", "wrist_angle", "wrist_rotate"};
        for (size_t i = 0; i < want.size(); i++) {
            for (size_t j = 0; j < msg->name.size(); j++) {
                if (msg->name[j] == want[i] && j < msg->position.size()) {
                    current_joints_(i) = msg->position[j];
                    break;
                }
            }
        }
        joint_states_ready_ = true;
    }

    // Try IK with multiple seeds. Returns true if a valid solution is found.
    bool solveWithSeeds(const Eigen::Matrix4d &T_target,
                        Eigen::Matrix<double, 5, 1> &out)
    {
        std::vector<Eigen::Matrix<double, 5, 1>> seeds;
        seeds.push_back(last_solution_);
        seeds.push_back(current_joints_);
        Eigen::Matrix<double, 5, 1> z; z.setZero(); seeds.push_back(z);
        Eigen::Matrix<double, 5, 1> a; a.setZero(); a(0) = -2.094; seeds.push_back(a);
        Eigen::Matrix<double, 5, 1> b; b.setZero(); b(0) =  2.094; seeds.push_back(b);

        for (auto &seed : seeds) {
            Eigen::Matrix<double, 5, 1> solved;
            bool ok = teleop::ik::solveIK(T_target, seed, ik_params_, limits_, solved);
            if (!ok) continue;
            bool in_limits = true;
            for (int i = 0; i < 5; i++) {
                if (solved(i) < limits_.lower(i) - 1e-6 ||
                    solved(i) > limits_.upper(i) + 1e-6) {
                    in_limits = false; break;
                }
            }
            if (!in_limits) continue;
            out = solved;
            return true;
        }
        return false;
    }

    // Set Profile_Velocity register to control moving_time (Dynamixel register 112).
    // moving_time_s: time in seconds for the move. Internally sent as milliseconds.
    void setTrajectoryTime(double moving_time_s) {
        if (!reg_client_->wait_for_service(100ms)) {
            RCLCPP_WARN(get_logger(), "set_motor_registers service unavailable");
            return;
        }
        auto req = std::make_shared<interbotix_xs_msgs::srv::RegisterValues::Request>();
        req->cmd_type = "group";
        req->name = "arm";
        req->reg = "Profile_Velocity";
        req->value = static_cast<int32_t>(moving_time_s * 1000.0);
        reg_client_->async_send_request(req);
    }

    // Publish a joint group command and block for moving_time.
    // Matches Interbotix SDK's publish_positions() pattern exactly.
    void publishPositions(const Eigen::Matrix<double, 5, 1> &positions,
                          double moving_time_s = 0.3)
    {
        // Set the Profile_Velocity register (moving_time) before sending the command.
        setTrajectoryTime(moving_time_s);

        interbotix_xs_msgs::msg::JointGroupCommand cmd;
        cmd.name = "arm";
        cmd.cmd.resize(5);
        for (int i = 0; i < 5; i++) cmd.cmd[i] = static_cast<float>(positions(i));
        pub_group_->publish(cmd);

        // BLOCK: let the arm finish moving before we send the next command.
        // This is the Interbotix convention — without it, rapid subsequent
        // commands override each other and the arm never settles.
        std::this_thread::sleep_for(
            std::chrono::milliseconds(static_cast<int>(moving_time_s * 1000)));
    }

    void publishGripper(double pwm_cmd) {
        interbotix_xs_msgs::msg::JointSingleCommand cmd;
        cmd.name = "gripper";
        cmd.cmd = static_cast<float>(pwm_cmd);
        pub_single_->publish(cmd);
    }

    // Main control loop. Runs in its own thread. One step per keypress.
    void controlLoop() {
        // Connect to input OPC UA server
        const std::string endpoint = "opc.tcp://localhost:4840";
        while (g_running && rclcpp::ok()) {
            if (UA_Client_connect(ua_client_, endpoint.c_str()) == UA_STATUSCODE_GOOD) {
                ua_connected_ = true;
                RCLCPP_INFO(get_logger(), "Connected to OPC UA input @ %s", endpoint.c_str());
                break;
            }
            RCLCPP_WARN(get_logger(), "Waiting for input server at %s ...", endpoint.c_str());
            std::this_thread::sleep_for(1s);
        }

        // Wait for joint states
        while (g_running && rclcpp::ok() && !joint_states_ready_) {
            RCLCPP_INFO(get_logger(), "Waiting for /vx300/joint_states ...");
            std::this_thread::sleep_for(500ms);
        }
        if (!g_running || !rclcpp::ok()) return;

        // Initialize target from current pose
        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            last_solution_ = current_joints_;
            Eigen::Matrix4d T = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints_);
            target_pos_ = T.block<3,1>(0,3);
            Eigen::Matrix3d R = T.block<3,3>(0,0);
            target_pitch_ = atan2(-R(2,0), sqrt(R(2,1)*R(2,1) + R(2,2)*R(2,2)));
            target_wrist_ = current_joints_(4);
        }
        RCLCPP_INFO(get_logger(),
            "Target initialized: pos=(%.3f,%.3f,%.3f) pitch=%.3f wrist=%.3f",
            target_pos_(0), target_pos_(1), target_pos_(2),
            target_pitch_, target_wrist_);

        // Step sizes
        const double STEP_XYZ   = 0.010;     // 1 cm per tap
        const double STEP_PITCH = 0.0873;    // 5°
        const double STEP_WRIST = 0.0873;    // 5°
        const float  STEP_GRIP  = 150.0f;    // PWM ticks per tap (safe)
        const double MOVING_TIME = 0.25;     // 250 ms per step (smooth, responsive)

        // Edge detection state
        bool prev[12] = {false};
        auto edge = [&](bool cur, int idx) -> bool {
            bool fire = cur && !prev[idx];
            prev[idx] = cur;
            return fire;
        };

        float grip_pwm = 0.0f;

        while (g_running && rclcpp::ok()) {
            // Read Cartesian pulses from input server
            float vx    = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_X);
            float vy    = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_Y);
            float vz    = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_Z);
            float vpit  = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_PITCH);
            float vwst  = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_YAW);  // yaw slot = wrist
            float vgrp  = clientReadFloat(ua_client_, teleop::opcua_ids::CART_GRIPPER);

            const float TH = 0.5f;
            bool xp = edge(vx >  TH, 0), xn = edge(vx < -TH, 1);
            bool yp = edge(vy >  TH, 2), yn = edge(vy < -TH, 3);
            bool zp = edge(vz >  TH, 4), zn = edge(vz < -TH, 5);
            bool pp = edge(vpit>  TH, 6), pn = edge(vpit< -TH, 7);
            bool wp = edge(vwst>  TH, 8), wn = edge(vwst< -TH, 9);
            bool gp = edge(vgrp>  TH,10), gn = edge(vgrp< -TH,11);

            bool need_move = false;
            Eigen::Vector3d new_pos = target_pos_;
            double new_pitch = target_pitch_;
            double new_wrist = target_wrist_;

            if (xp) { new_pos(0) += STEP_XYZ; need_move = true; }
            if (xn) { new_pos(0) -= STEP_XYZ; need_move = true; }
            if (yp) { new_pos(1) += STEP_XYZ; need_move = true; }
            if (yn) { new_pos(1) -= STEP_XYZ; need_move = true; }
            if (zp) { new_pos(2) += STEP_XYZ; need_move = true; }
            if (zn) { new_pos(2) -= STEP_XYZ; need_move = true; }
            if (pp) { new_pitch += STEP_PITCH; need_move = true; }
            if (pn) { new_pitch -= STEP_PITCH; need_move = true; }
            if (wp) { new_wrist += STEP_WRIST; need_move = true; }
            if (wn) { new_wrist -= STEP_WRIST; need_move = true; }

            // Workspace clamp
            new_pos(0) = std::max(0.10, std::min(0.55, new_pos(0)));
            new_pos(1) = std::max(-0.40, std::min(0.40, new_pos(1)));
            new_pos(2) = std::max(0.05, std::min(0.55, new_pos(2)));
            new_pitch  = std::max(-1.4,  std::min(1.4,  new_pitch));
            new_wrist  = std::max(limits_.lower(4), std::min(limits_.upper(4), new_wrist));

            if (need_move) {
                // yaw = atan2(y, x) per Interbotix convention for 5-DOF arms
                double new_yaw = atan2(new_pos(1), new_pos(0));
                Eigen::Matrix4d T_target = Eigen::Matrix4d::Identity();
                T_target.block<3,3>(0,0) = rpyToR(0.0, new_pitch, new_yaw);
                T_target.block<3,1>(0,3) = new_pos;

                Eigen::Matrix<double, 5, 1> solved;
                bool ok = solveWithSeeds(T_target, solved);

                if (ok) {
                    solved(4) = new_wrist;  // direct wrist control (5-DOF convention)
                    RCLCPP_INFO(get_logger(),
                        "[CMD] pos=(%.3f,%.3f,%.3f) yaw=%.2f pitch=%.2f wrist=%.2f "
                        "→ joints=(%.2f,%.2f,%.2f,%.2f,%.2f)",
                        new_pos(0), new_pos(1), new_pos(2),
                        new_yaw, new_pitch, new_wrist,
                        solved(0), solved(1), solved(2), solved(3), solved(4));

                    // PUBLISH + SLEEP (the key fix)
                    publishPositions(solved, MOVING_TIME);

                    // Commit target only on success
                    target_pos_   = new_pos;
                    target_pitch_ = new_pitch;
                    target_wrist_ = new_wrist;
                    last_solution_ = solved;
                } else {
                    RCLCPP_WARN(get_logger(),
                        "IK FAILED for target (%.3f,%.3f,%.3f) — not committed",
                        new_pos(0), new_pos(1), new_pos(2));
                }
            }

            // Gripper — separate PWM command (not via IK)
            if (gp) {
                grip_pwm = std::min(300.0f, grip_pwm + STEP_GRIP);
                publishGripper(grip_pwm);
                RCLCPP_INFO(get_logger(), "[GRIP] open pwm=%.0f", grip_pwm);
                std::this_thread::sleep_for(200ms);
                // Stop gripper (hold)
                publishGripper(0.0f);
                grip_pwm = 0.0f;
            }
            if (gn) {
                grip_pwm = std::max(-300.0f, grip_pwm - STEP_GRIP);
                publishGripper(grip_pwm);
                RCLCPP_INFO(get_logger(), "[GRIP] close pwm=%.0f", grip_pwm);
                std::this_thread::sleep_for(200ms);
                publishGripper(0.0f);
                grip_pwm = 0.0f;
            }

            // Poll at 50 Hz for new pulses (input server publishes at 50 Hz,
            // each pulse held for 5 ticks = 100 ms so we can't miss one)
            std::this_thread::sleep_for(20ms);
        }
    }

private:
    // ROS 2
    rclcpp::Publisher<interbotix_xs_msgs::msg::JointGroupCommand>::SharedPtr pub_group_;
    rclcpp::Publisher<interbotix_xs_msgs::msg::JointSingleCommand>::SharedPtr pub_single_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr sub_joints_;
    rclcpp::Client<interbotix_xs_msgs::srv::RegisterValues>::SharedPtr reg_client_;

    // OPC UA
    UA_Client *ua_client_ = nullptr;
    bool ua_connected_ = false;

    // IK
    teleop::ik::IKParams ik_params_;
    teleop::ik::JointLimitsEigen limits_;

    // State (guarded by mutex where joint_states_ is written/read)
    std::mutex state_mutex_;
    Eigen::Matrix<double, 5, 1> current_joints_;
    Eigen::Matrix<double, 5, 1> last_solution_;
    bool joint_states_ready_ = false;

    // Target
    Eigen::Vector3d target_pos_{0.3, 0.0, 0.3};
    double target_pitch_ = 0.0;
    double target_wrist_ = 0.0;
};

int main(int argc, char **argv) {
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);
    rclcpp::init(argc, argv);

    auto node = std::make_shared<OpcuaTeleop>();
    std::thread ctrl_thread([&]() { node->controlLoop(); });
    rclcpp::spin(node);
    g_running = false;
    ctrl_thread.join();
    rclcpp::shutdown();
    return 0;
}
