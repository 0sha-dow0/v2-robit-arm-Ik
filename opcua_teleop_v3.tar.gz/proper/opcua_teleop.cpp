// ─────────────────────────────────────────────────────────────────────
// opcua_teleop_v3 — inline position-only IK (no dependency on old solveIK)
// ─────────────────────────────────────────────────────────────────────

#include "common/skill_types.h"
#include "common/config_loader.h"
#include "ik/kinematics.h"

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <interbotix_xs_msgs/msg/joint_group_command.hpp>
#include <interbotix_xs_msgs/msg/joint_single_command.hpp>
#include <interbotix_xs_msgs/srv/register_values.hpp>

#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <Eigen/Dense>
#include <csignal>
#include <cstdio>
#include <cmath>
#include <chrono>
#include <thread>
#include <atomic>
#include <mutex>

using namespace std::chrono_literals;

static std::atomic<bool> g_running{true};
static void sig_handler(int) { g_running = false; }

static float clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}

// ─── INLINE POSITION-ONLY IK ──────────────────────────────────────
// Uses PoE FK + 3xN position Jacobian (bottom 3 rows of space Jacobian).
// Damped least squares. No orientation requirement. Always converges for reachable pts.
static bool positionOnlyIK(
    const Eigen::Vector3d &target_pos,
    const Eigen::Matrix<double, 5, 1> &theta_init,
    const teleop::ik::JointLimitsEigen &limits,
    Eigen::Matrix<double, 5, 1> &theta_out,
    int max_iter = 100,
    double eps_pos = 1e-3,
    double lambda = 0.05)
{
    const Eigen::Matrix4d M = teleop::ik::getM();
    const Eigen::Matrix<double, 6, 5> Slist = teleop::ik::getSlist();

    Eigen::Matrix<double, 5, 1> theta = theta_init;

    for (int i = 0; i < max_iter; i++) {
        Eigen::Matrix4d T_sb = teleop::ik::fkInSpace(M, Slist, theta);
        Eigen::Vector3d cur = T_sb.block<3, 1>(0, 3);
        Eigen::Vector3d err = target_pos - cur;

        if (err.norm() < eps_pos) {
            for (int j = 0; j < 5; j++) {
                theta(j) = std::max(limits.lower(j), std::min(limits.upper(j), theta(j)));
            }
            theta_out = theta;
            return true;
        }

        Eigen::Matrix<double, 6, 5> Js = teleop::ik::jacobianSpace(Slist, theta);
        Eigen::Matrix<double, 3, 5> Jp = Js.block<3, 5>(3, 0);

        Eigen::Matrix3d JJt = Jp * Jp.transpose();
        Eigen::Matrix3d damped = JJt + (lambda * lambda) * Eigen::Matrix3d::Identity();
        Eigen::Matrix<double, 5, 3> Jpinv = Jp.transpose() * damped.inverse();
        Eigen::Matrix<double, 5, 1> dtheta = Jpinv * err;

        double step_norm = dtheta.norm();
        if (step_norm > 0.3) dtheta *= (0.3 / step_norm);

        theta += dtheta;

        for (int j = 0; j < 5; j++) {
            theta(j) = std::max(limits.lower(j), std::min(limits.upper(j), theta(j)));
        }
    }

    theta_out = theta;
    Eigen::Matrix4d T_final = teleop::ik::fkInSpace(M, Slist, theta);
    double final_err = (target_pos - T_final.block<3, 1>(0, 3)).norm();
    return (final_err < 0.005);
}

class OpcuaTeleop : public rclcpp::Node {
public:
    OpcuaTeleop() : Node("opcua_teleop") {
        auto qos = rclcpp::QoS(10);
        pub_group_ = create_publisher<interbotix_xs_msgs::msg::JointGroupCommand>(
            "/vx300/commands/joint_group", qos);
        pub_single_ = create_publisher<interbotix_xs_msgs::msg::JointSingleCommand>(
            "/vx300/commands/joint_single", qos);
        sub_joints_ = create_subscription<sensor_msgs::msg::JointState>(
            "/vx300/joint_states", qos,
            std::bind(&OpcuaTeleop::jointStateCb, this, std::placeholders::_1));
        reg_client_ = create_client<interbotix_xs_msgs::srv::RegisterValues>(
            "/vx300/set_motor_registers");

        RCLCPP_INFO(get_logger(), "opcua_teleop v3 — position-only inline IK");

        limits_ = teleop::ik::JointLimitsEigen::vx300();
        current_joints_.setZero();
        last_solution_.setZero();

        ua_client_ = UA_Client_new();
        UA_ClientConfig_setDefault(UA_Client_getConfig(ua_client_));
    }
    ~OpcuaTeleop() {
        if (ua_connected_) UA_Client_disconnect(ua_client_);
        UA_Client_delete(ua_client_);
    }

    void jointStateCb(const sensor_msgs::msg::JointState::SharedPtr msg) {
        std::lock_guard<std::mutex> lock(state_mutex_);
        const std::vector<std::string> want = {
            "waist", "shoulder", "elbow", "wrist_angle", "wrist_rotate"};
        for (size_t i = 0; i < want.size(); i++) {
            for (size_t j = 0; j < msg->name.size(); j++) {
                if (msg->name[j] == want[i] && j < msg->position.size()) {
                    current_joints_(i) = msg->position[j];
                    break;
                }
            }
        }
        joint_states_ready_ = true;
    }

    bool solveWithSeeds(const Eigen::Vector3d &target_pos,
                        Eigen::Matrix<double, 5, 1> &out)
    {
        std::vector<Eigen::Matrix<double, 5, 1>> seeds;
        seeds.push_back(last_solution_);
        seeds.push_back(current_joints_);
        Eigen::Matrix<double, 5, 1> z; z.setZero(); seeds.push_back(z);

        double best_err = std::numeric_limits<double>::max();
        Eigen::Matrix<double, 5, 1> best = current_joints_;

        for (auto &seed : seeds) {
            Eigen::Matrix<double, 5, 1> solved;
            positionOnlyIK(target_pos, seed, limits_, solved);
            Eigen::Matrix4d T = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), solved);
            double err = (target_pos - T.block<3, 1>(0, 3)).norm();
            if (err < best_err) { best_err = err; best = solved; }
            if (err < 0.003) { out = best; return true; }
        }

        out = best;
        RCLCPP_INFO(get_logger(), "IK best_err=%.4fm", best_err);
        return (best_err < 0.010);
    }

    void setTrajectoryTime(double moving_time_s) {
        if (!reg_client_->wait_for_service(100ms)) return;
        auto req = std::make_shared<interbotix_xs_msgs::srv::RegisterValues::Request>();
        req->cmd_type = "group";
        req->name = "arm";
        req->reg = "Profile_Velocity";
        req->value = static_cast<int32_t>(moving_time_s * 1000.0);
        reg_client_->async_send_request(req);
    }

    void publishPositions(const Eigen::Matrix<double, 5, 1> &positions,
                          double moving_time_s = 0.3)
    {
        setTrajectoryTime(moving_time_s);
        interbotix_xs_msgs::msg::JointGroupCommand cmd;
        cmd.name = "arm";
        cmd.cmd.resize(5);
        for (int i = 0; i < 5; i++) cmd.cmd[i] = static_cast<float>(positions(i));
        pub_group_->publish(cmd);
        std::this_thread::sleep_for(
            std::chrono::milliseconds(static_cast<int>(moving_time_s * 1000)));
    }

    void publishGripper(double pwm_cmd) {
        interbotix_xs_msgs::msg::JointSingleCommand cmd;
        cmd.name = "gripper";
        cmd.cmd = static_cast<float>(pwm_cmd);
        pub_single_->publish(cmd);
    }

    void controlLoop() {
        const std::string endpoint = "opc.tcp://localhost:4840";
        while (g_running && rclcpp::ok()) {
            if (UA_Client_connect(ua_client_, endpoint.c_str()) == UA_STATUSCODE_GOOD) {
                ua_connected_ = true;
                RCLCPP_INFO(get_logger(), "Connected to OPC UA input");
                break;
            }
            std::this_thread::sleep_for(1s);
        }

        while (g_running && rclcpp::ok() && !joint_states_ready_) {
            std::this_thread::sleep_for(200ms);
        }
        if (!g_running || !rclcpp::ok()) return;

        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            last_solution_ = current_joints_;
            Eigen::Matrix4d T = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints_);
            target_pos_ = T.block<3,1>(0,3);
            target_wrist_ = current_joints_(4);
        }
        RCLCPP_INFO(get_logger(),
            "Target initialized: pos=(%.3f,%.3f,%.3f) wrist=%.3f",
            target_pos_(0), target_pos_(1), target_pos_(2), target_wrist_);

        const double STEP_XYZ   = 0.010;
        const double STEP_WRIST = 0.0873;
        const double MOVING_TIME = 0.30;

        bool prev[12] = {false};
        auto edge = [&](bool cur, int idx) -> bool {
            bool fire = cur && !prev[idx]; prev[idx] = cur; return fire;
        };

        while (g_running && rclcpp::ok()) {
            float vx = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_X);
            float vy = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_Y);
            float vz = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_Z);
            float vwst = clientReadFloat(ua_client_, teleop::opcua_ids::CART_VEL_YAW);
            float vgrp = clientReadFloat(ua_client_, teleop::opcua_ids::CART_GRIPPER);

            const float TH = 0.5f;
            bool xp = edge(vx >  TH, 0), xn = edge(vx < -TH, 1);
            bool yp = edge(vy >  TH, 2), yn = edge(vy < -TH, 3);
            bool zp = edge(vz >  TH, 4), zn = edge(vz < -TH, 5);
            bool wp = edge(vwst>  TH, 6), wn = edge(vwst< -TH, 7);
            bool gp = edge(vgrp>  TH, 8), gn = edge(vgrp< -TH, 9);

            bool need_move = false;
            Eigen::Vector3d new_pos = target_pos_;
            double new_wrist = target_wrist_;

            if (xp) { new_pos(0) += STEP_XYZ; need_move = true; }
            if (xn) { new_pos(0) -= STEP_XYZ; need_move = true; }
            if (yp) { new_pos(1) += STEP_XYZ; need_move = true; }
            if (yn) { new_pos(1) -= STEP_XYZ; need_move = true; }
            if (zp) { new_pos(2) += STEP_XYZ; need_move = true; }
            if (zn) { new_pos(2) -= STEP_XYZ; need_move = true; }
            if (wp) { new_wrist += STEP_WRIST; need_move = true; }
            if (wn) { new_wrist -= STEP_WRIST; need_move = true; }

            new_pos(0) = std::max(0.08, std::min(0.55, new_pos(0)));
            new_pos(1) = std::max(-0.40, std::min(0.40, new_pos(1)));
            new_pos(2) = std::max(0.02, std::min(0.55, new_pos(2)));
            new_wrist  = std::max(limits_.lower(4), std::min(limits_.upper(4), new_wrist));

            if (need_move) {
                Eigen::Matrix<double, 5, 1> solved;
                bool ok = solveWithSeeds(new_pos, solved);
                if (ok) {
                    solved(4) = new_wrist;
                    RCLCPP_INFO(get_logger(),
                        "[CMD] pos=(%.3f,%.3f,%.3f) wrist=%.2f → j=(%.2f,%.2f,%.2f,%.2f,%.2f)",
                        new_pos(0), new_pos(1), new_pos(2), new_wrist,
                        solved(0), solved(1), solved(2), solved(3), solved(4));
                    publishPositions(solved, MOVING_TIME);
                    target_pos_ = new_pos;
                    target_wrist_ = new_wrist;
                    last_solution_ = solved;
                } else {
                    RCLCPP_WARN(get_logger(), "IK unreachable: (%.3f,%.3f,%.3f)",
                                new_pos(0), new_pos(1), new_pos(2));
                }
            }

            if (gp) { publishGripper(300.0); std::this_thread::sleep_for(200ms); publishGripper(0.0); }
            if (gn) { publishGripper(-300.0); std::this_thread::sleep_for(200ms); publishGripper(0.0); }

            std::this_thread::sleep_for(20ms);
        }
    }

private:
    rclcpp::Publisher<interbotix_xs_msgs::msg::JointGroupCommand>::SharedPtr pub_group_;
    rclcpp::Publisher<interbotix_xs_msgs::msg::JointSingleCommand>::SharedPtr pub_single_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr sub_joints_;
    rclcpp::Client<interbotix_xs_msgs::srv::RegisterValues>::SharedPtr reg_client_;

    UA_Client *ua_client_ = nullptr;
    bool ua_connected_ = false;

    teleop::ik::JointLimitsEigen limits_;

    std::mutex state_mutex_;
    Eigen::Matrix<double, 5, 1> current_joints_;
    Eigen::Matrix<double, 5, 1> last_solution_;
    bool joint_states_ready_ = false;

    Eigen::Vector3d target_pos_{0.3, 0.0, 0.3};
    double target_wrist_ = 0.0;
};

int main(int argc, char **argv) {
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);
    rclcpp::init(argc, argv);
    auto node = std::make_shared<OpcuaTeleop>();
    std::thread ctrl_thread([&]() { node->controlLoop(); });
    rclcpp::spin(node);
    g_running = false;
    ctrl_thread.join();
    rclcpp::shutdown();
    return 0;
}
