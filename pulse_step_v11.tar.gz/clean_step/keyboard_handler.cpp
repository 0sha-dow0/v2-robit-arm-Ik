#include "input/keyboard_handler.h"
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <cstring>
#include <cstdio>
#include <chrono>
#include <algorithm>
#include <cerrno>

namespace teleop {

KeyboardHandler::KeyboardHandler(const InputConfig &config) : config_(config) {
    for (int i = 0; i < 7; i++) ramped_values_[i] = 0.0f;
}

KeyboardHandler::~KeyboardHandler() { stop(); }

std::string KeyboardHandler::findKeyboardDevice() {
    if (!config_.evdev_path.empty()) return config_.evdev_path;
    DIR *dir = opendir("/dev/input");
    if (!dir) return "";
    struct dirent *entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (strncmp(entry->d_name, "event", 5) != 0) continue;
        std::string path = std::string("/dev/input/") + entry->d_name;
        int fd = open(path.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;
        struct libevdev *dev = nullptr;
        int rc = libevdev_new_from_fd(fd, &dev);
        if (rc < 0) { close(fd); continue; }
        bool has_keys = libevdev_has_event_type(dev, EV_KEY) &&
                        libevdev_has_event_code(dev, EV_KEY, KEY_A);
        libevdev_free(dev); close(fd);
        if (has_keys) { closedir(dir); return path; }
    }
    closedir(dir);
    return "";
}

bool KeyboardHandler::start() {
    std::string devpath = findKeyboardDevice();
    if (devpath.empty()) { printf("[Keyboard] ERROR: No device\n"); return false; }
    evdev_fd_ = open(devpath.c_str(), O_RDONLY | O_NONBLOCK);
    if (evdev_fd_ < 0) { return false; }
    int rc = libevdev_new_from_fd(evdev_fd_, &evdev_);
    if (rc < 0) { close(evdev_fd_); return false; }
    printf("[Keyboard] Opened: %s\n", libevdev_get_name(evdev_));
    for (const auto &km : config_.key_mappings) key_states_[km.key_code] = false;
    running_.store(true);
    read_thread_ = std::thread(&KeyboardHandler::readLoop, this);
    return true;
}

void KeyboardHandler::stop() {
    running_.store(false);
    if (read_thread_.joinable()) read_thread_.join();
    if (evdev_) { libevdev_free(evdev_); evdev_ = nullptr; }
    if (evdev_fd_ >= 0) { close(evdev_fd_); evdev_fd_ = -1; }
}

// PULSE MODE: key-press -> pulse held for PULSE_TICKS so downstream can catch it.
void KeyboardHandler::readLoop() {
    int period_us = 1000000 / config_.publish_hz;
    const int PULSE_TICKS = 5;  // hold pulse for 5 ticks (100ms) so selector reads it

    float pulse_value[7] = {0};
    int   pulse_remaining[7] = {0};

    while (running_.load()) {
        struct input_event ev;
        int rc;
        do {
            rc = libevdev_next_event(evdev_,
                LIBEVDEV_READ_FLAG_NORMAL | LIBEVDEV_READ_FLAG_BLOCKING, &ev);
            if (rc == LIBEVDEV_READ_STATUS_SUCCESS) {
                if (ev.type == EV_KEY) {
                    if (ev.value == 2) continue;  // no autorepeat
                    int code = ev.code;
                    bool pressed = (ev.value == 1);
                    if (key_states_.count(code)) {
                        bool was = key_states_[code];
                        key_states_[code] = pressed;
                        if (pressed && !was) {
                            // Fire new pulse for this key
                            for (const auto &km : config_.key_mappings) {
                                if (km.key_code == code) {
                                    pulse_value[km.axis_index] = km.direction;
                                    pulse_remaining[km.axis_index] = PULSE_TICKS;
                                    printf("[KB] PULSE axis=%d dir=%+.1f\n",
                                           km.axis_index, km.direction);
                                }
                            }
                        }
                    }
                }
            }
        } while (rc == LIBEVDEV_READ_STATUS_SUCCESS ||
                 rc == LIBEVDEV_READ_STATUS_SYNC);

        // Build command from active pulses
        CartesianInputCommand cmd;
        memset(&cmd, 0, sizeof(cmd));
        float out[7] = {0};
        for (int i = 0; i < 7; i++) {
            if (pulse_remaining[i] > 0) {
                out[i] = pulse_value[i];
                pulse_remaining[i]--;
                if (pulse_remaining[i] == 0) pulse_value[i] = 0;
            }
        }
        for (int i = 0; i < 3; i++) cmd.linear_vel[i]  = out[i];
        for (int i = 0; i < 3; i++) cmd.angular_vel[i] = out[3 + i];
        cmd.gripper_cmd = out[6];
        cmd.deadman = true;
        cmd.stamp = stamp_counter_.fetch_add(1);

        {
            std::lock_guard<std::mutex> lock(cmd_mutex_);
            current_cmd_ = cmd;
        }
        usleep(period_us);
    }
}

void KeyboardHandler::updateRamps(double /*dt*/) {}

CartesianInputCommand KeyboardHandler::getCommand() {
    std::lock_guard<std::mutex> lock(cmd_mutex_);
    return current_cmd_;
}

} // namespace teleop
