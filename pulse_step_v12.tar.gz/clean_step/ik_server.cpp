// IK Server v12 — step control with robust motion (no orient requirement)
#include "common/skill_types.h"
#include "common/config_loader.h"
#include "ik/ik_solver.h"
#include "ik/kinematics.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <cmath>
#include <chrono>
#include <unistd.h>
#include <Eigen/Dense>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

static float readLocalFloat(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static uint32_t readLocalUInt32(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    uint32_t r = 0;
    if (v.type == &UA_TYPES[UA_TYPES_UINT32]) r = *(UA_UInt32*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static float clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static void clientWriteFloat(UA_Client *c, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteBool(UA_Client *c, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteUInt32(UA_Client *c, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    std::string config_path = "configs/ik.yaml";
    if (argc > 1) config_path = argv[1];

    printf("======================================\n");
    printf("  IK Server v12 — step + robust motion\n");
    printf("======================================\n");

    teleop::IKConfig config;
    try { config = teleop::loadIKConfig(config_path); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    UA_Server *server = UA_Server_new();
    UA_ServerConfig_setMinimal(UA_Server_getConfig(server), config.opcua_port, NULL);
    if (teleop::addCartesianInputSkillNodes(server) != UA_STATUSCODE_GOOD) return 1;
    if (UA_Server_run_startup(server) != UA_STATUSCODE_GOOD) return 1;

    UA_Client *fb_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(fb_client));
    bool fb_connected = false;
    UA_Client *bridge_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(bridge_client));
    bool bridge_connected = false;

    teleop::ik::IKParams ik_params;
    ik_params.max_iterations = 50;
    ik_params.eps_pos = 0.005;   // 5 mm tolerance (loose, always converge)
    ik_params.eps_ori = 100.0;   // huge - we don't care about orientation
    ik_params.damping_lambda = 0.1;
    ik_params.jl_weight = 0.02;
    auto limits = teleop::ik::JointLimitsEigen::vx300();

    const double STEP_POS   = 0.03;   // 3 cm per tap
    const double STEP_YAW   = 0.15;   // wrist rotate step
    const float  STEP_GRIP  = 0.20f;

    Eigen::Matrix<double, 5, 1> current_joints; current_joints.setZero();
    Eigen::Matrix<double, 5, 1> target_joints;  target_joints.setZero();
    Eigen::Vector3d target_pos(0.3, 0.0, 0.3);
    bool have_initial = false;

    uint32_t last_stamp = 0;

    int period_us = 20000;
    uint32_t loop_count = 0;
    double dt = 0.02;

    printf("[IK] step pos=%.3fm yaw=%.3frad grip=%.2f\n", STEP_POS, STEP_YAW, STEP_GRIP);

    while (g_running) {
        UA_Server_run_iterate(server, false);

        if (!fb_connected && UA_Client_connect(fb_client, config.feedback_endpoint.c_str())
            == UA_STATUSCODE_GOOD) { fb_connected = true; printf("[IK] fb ok\n"); }
        if (!bridge_connected && UA_Client_connect(bridge_client, config.bridge_endpoint.c_str())
            == UA_STATUSCODE_GOOD) { bridge_connected = true; printf("[IK] bridge ok\n"); }

        if (fb_connected) {
            for (int i = 0; i < 5; i++) {
                current_joints(i) = (double)clientReadFloat(fb_client,
                    teleop::opcua_ids::FB_JOINT_POS_BASE + i);
            }
        }

        float vx = readLocalFloat(server, teleop::opcua_ids::CART_VEL_X);
        float vy = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Y);
        float vz = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Z);
        float vyaw = readLocalFloat(server, teleop::opcua_ids::CART_VEL_YAW);
        float vgrip = readLocalFloat(server, teleop::opcua_ids::CART_GRIPPER);
        uint32_t stamp = readLocalUInt32(server, teleop::opcua_ids::CART_STAMP);

        if (!have_initial && fb_connected) {
            Eigen::Matrix4d T = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
            target_pos = T.block<3,1>(0,3);
            target_joints = current_joints;
            have_initial = true;
            last_stamp = stamp;
            printf("[IK] init pos=(%.3f,%.3f,%.3f) joints=(%.2f,%.2f,%.2f,%.2f,%.2f)\n",
                   target_pos(0), target_pos(1), target_pos(2),
                   current_joints(0), current_joints(1), current_joints(2),
                   current_joints(3), current_joints(4));
        }

        float gripper_out = 0.0f;
        static float gripper_state = 0.0f;
        static int gripper_pulse_ticks = 0;

        // Pulse detection: stamp changed AND nonzero input = new pulse
        const float PULSE_THRESH = 0.5f;
        bool new_pulse = (stamp != last_stamp);
        if (new_pulse && have_initial) {
            last_stamp = stamp;
            bool pos_step = false;
            Eigen::Vector3d new_target = target_pos;
            if (vx >  PULSE_THRESH) { new_target(0) += STEP_POS; pos_step = true; printf("[STEP] +X\n"); }
            if (vx < -PULSE_THRESH) { new_target(0) -= STEP_POS; pos_step = true; printf("[STEP] -X\n"); }
            if (vy >  PULSE_THRESH) { new_target(1) += STEP_POS; pos_step = true; printf("[STEP] +Y\n"); }
            if (vy < -PULSE_THRESH) { new_target(1) -= STEP_POS; pos_step = true; printf("[STEP] -Y\n"); }
            if (vz >  PULSE_THRESH) { new_target(2) += STEP_POS; pos_step = true; printf("[STEP] +Z\n"); }
            if (vz < -PULSE_THRESH) { new_target(2) -= STEP_POS; pos_step = true; printf("[STEP] -Z\n"); }

            // Clamp workspace
            new_target(0) = std::max(0.15, std::min(0.55, new_target(0)));
            new_target(1) = std::max(-0.35, std::min(0.35, new_target(1)));
            new_target(2) = std::max(0.08, std::min(0.55, new_target(2)));

            if (pos_step) {
                // Solve IK for the new position. Use position-only (orientation free)
                Eigen::Matrix4d T_target = Eigen::Matrix4d::Identity();
                T_target.block<3,1>(0,3) = new_target;

                Eigen::Matrix<double, 5, 1> solved = current_joints;
                bool ok = teleop::ik::solveIK(T_target, current_joints,
                                               ik_params, limits, solved);
                printf("[IK] target=(%.3f,%.3f,%.3f) ok=%d solved=(%.2f,%.2f,%.2f,%.2f,%.2f)\n",
                       new_target(0), new_target(1), new_target(2), ok,
                       solved(0), solved(1), solved(2), solved(3), solved(4));

                // Accept solution even if not fully converged — take whatever it gives
                target_joints = solved;
                target_pos = new_target;
            }

            // Direct wrist yaw (joint 4 = wrist_rotate)
            if (vyaw >  PULSE_THRESH) { target_joints(4) += STEP_YAW; printf("[STEP] +yaw\n"); }
            if (vyaw < -PULSE_THRESH) { target_joints(4) -= STEP_YAW; printf("[STEP] -yaw\n"); }
            target_joints(4) = std::max(limits.lower(4), std::min(limits.upper(4), target_joints(4)));

            if (vgrip >  PULSE_THRESH) {
                gripper_state += STEP_GRIP;
                if (gripper_state > 1.0f) gripper_state = 1.0f;
                gripper_pulse_ticks = 20;  // keep sending gripper command for 400ms
                printf("[STEP] grip+ -> %.2f\n", gripper_state);
            }
            if (vgrip < -PULSE_THRESH) {
                gripper_state -= STEP_GRIP;
                if (gripper_state < -1.0f) gripper_state = -1.0f;
                gripper_pulse_ticks = 20;
                printf("[STEP] grip- -> %.2f\n", gripper_state);
            }
        }

        if (gripper_pulse_ticks > 0) {
            gripper_out = gripper_state;
            gripper_pulse_ticks--;
        }

        // Drive arm to target_joints smoothly
        // Compute joint velocity: move each joint toward target at fixed rate
        const double STEP_LIMIT_RAD = 0.03;  // max 0.03 rad per tick (1.5 rad/s)
        float jvel[5];
        Eigen::Matrix<double, 5, 1> desired = current_joints;
        for (int i = 0; i < 5; i++) {
            double err = target_joints(i) - current_joints(i);
            double step = err;
            if (step >  STEP_LIMIT_RAD) step =  STEP_LIMIT_RAD;
            if (step < -STEP_LIMIT_RAD) step = -STEP_LIMIT_RAD;
            desired(i) = current_joints(i) + step;
            double raw_vel = step / dt;   // rad/s to get here in one tick
            float n = (float)raw_vel;     // keep in rad/s; bridge expects [-1,1] after scale
            if (n > 1.0f) n = 1.0f; if (n < -1.0f) n = -1.0f;
            jvel[i] = n;
        }

        if (bridge_connected) {
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WAIST,       jvel[0]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_SHOULDER,    jvel[1]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_ELBOW,       jvel[2]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ANGLE, jvel[3]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ROT,   jvel[4]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::GRIPPER_CMD,           gripper_out);
            clientWriteBool (bridge_client, teleop::opcua_ids::DEADMAN, true);
            clientWriteUInt32(bridge_client, teleop::opcua_ids::STAMP, loop_count);
        }

        if (++loop_count % 100 == 0) {
            printf("[IK] loop=%u cur=(%.2f,%.2f,%.2f,%.2f,%.2f) tgt=(%.2f,%.2f,%.2f,%.2f,%.2f)\n",
                   loop_count,
                   current_joints(0), current_joints(1), current_joints(2),
                   current_joints(3), current_joints(4),
                   target_joints(0), target_joints(1), target_joints(2),
                   target_joints(3), target_joints(4));
        }

        usleep(period_us);
    }

    if (fb_connected) UA_Client_disconnect(fb_client);
    UA_Client_delete(fb_client);
    if (bridge_connected) UA_Client_disconnect(bridge_client);
    UA_Client_delete(bridge_client);
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    return 0;
}
