// IK Server v13 — edge-triggered step, robust against lost messages
#include "common/skill_types.h"
#include "common/config_loader.h"
#include "ik/ik_solver.h"
#include "ik/kinematics.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <cmath>
#include <chrono>
#include <unistd.h>
#include <Eigen/Dense>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

static float readLocalFloat(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static float clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static void clientWriteFloat(UA_Client *c, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteBool(UA_Client *c, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteUInt32(UA_Client *c, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    std::string config_path = "configs/ik.yaml";
    if (argc > 1) config_path = argv[1];

    printf("========================================\n");
    printf("  IK Server v13 — edge-triggered step\n");
    printf("========================================\n");

    teleop::IKConfig config;
    try { config = teleop::loadIKConfig(config_path); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    UA_Server *server = UA_Server_new();
    UA_ServerConfig_setMinimal(UA_Server_getConfig(server), config.opcua_port, NULL);
    if (teleop::addCartesianInputSkillNodes(server) != UA_STATUSCODE_GOOD) return 1;
    if (UA_Server_run_startup(server) != UA_STATUSCODE_GOOD) return 1;

    UA_Client *fb_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(fb_client));
    bool fb_connected = false;
    UA_Client *bridge_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(bridge_client));
    bool bridge_connected = false;

    teleop::ik::IKParams ik_params;
    ik_params.max_iterations = 100;
    ik_params.eps_pos = 0.005;
    ik_params.eps_ori = 100.0;   // ignore orientation
    ik_params.damping_lambda = 0.1;
    ik_params.jl_weight = 0.0;
    auto limits = teleop::ik::JointLimitsEigen::vx300();

    const double STEP_POS   = 0.03;   // 3 cm per step
    const double STEP_YAW   = 0.15;   // wrist rotate step
    const float  STEP_GRIP  = 0.20f;

    Eigen::Matrix<double, 5, 1> current_joints; current_joints.setZero();
    Eigen::Matrix<double, 5, 1> target_joints;  target_joints.setZero();
    Eigen::Vector3d target_pos(0.3, 0.0, 0.3);
    bool have_initial = false;

    // Rising-edge state: was each axis active last tick?
    bool prev_xp = false, prev_xn = false;
    bool prev_yp = false, prev_yn = false;
    bool prev_zp = false, prev_zn = false;
    bool prev_ywp = false, prev_ywn = false;
    bool prev_gp = false, prev_gn = false;

    float gripper_state = 0.0f;
    int gripper_hold_ticks = 0;

    int period_us = 20000;
    uint32_t loop_count = 0;

    printf("[IK] Ready. Each key-press = 1 step.\n");

    while (g_running) {
        UA_Server_run_iterate(server, false);

        if (!fb_connected && UA_Client_connect(fb_client, config.feedback_endpoint.c_str())
            == UA_STATUSCODE_GOOD) { fb_connected = true; printf("[IK] fb ok\n"); }
        if (!bridge_connected && UA_Client_connect(bridge_client, config.bridge_endpoint.c_str())
            == UA_STATUSCODE_GOOD) { bridge_connected = true; printf("[IK] bridge ok\n"); }

        if (fb_connected) {
            for (int i = 0; i < 5; i++) {
                current_joints(i) = (double)clientReadFloat(fb_client,
                    teleop::opcua_ids::FB_JOINT_POS_BASE + i);
            }
        }

        float vx = readLocalFloat(server, teleop::opcua_ids::CART_VEL_X);
        float vy = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Y);
        float vz = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Z);
        float vyaw = readLocalFloat(server, teleop::opcua_ids::CART_VEL_YAW);
        float vgrip = readLocalFloat(server, teleop::opcua_ids::CART_GRIPPER);

        if (!have_initial && fb_connected) {
            Eigen::Matrix4d T = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
            target_pos = T.block<3,1>(0,3);
            target_joints = current_joints;
            have_initial = true;
            printf("[IK] init pos=(%.3f,%.3f,%.3f)\n",
                   target_pos(0), target_pos(1), target_pos(2));
        }

        // Rising edge detection (false -> true)
        const float TH = 0.5f;
        bool xp = vx >  TH, xn = vx < -TH;
        bool yp = vy >  TH, yn = vy < -TH;
        bool zp = vz >  TH, zn = vz < -TH;
        bool ywp = vyaw >  TH, ywn = vyaw < -TH;
        bool gp  = vgrip > TH, gn  = vgrip < -TH;

        Eigen::Vector3d new_target = target_pos;
        bool pos_step = false;

        if (xp && !prev_xp) { new_target(0) += STEP_POS; pos_step = true; printf("[STEP] +X -> %.3f\n", new_target(0)); }
        if (xn && !prev_xn) { new_target(0) -= STEP_POS; pos_step = true; printf("[STEP] -X -> %.3f\n", new_target(0)); }
        if (yp && !prev_yp) { new_target(1) += STEP_POS; pos_step = true; printf("[STEP] +Y -> %.3f\n", new_target(1)); }
        if (yn && !prev_yn) { new_target(1) -= STEP_POS; pos_step = true; printf("[STEP] -Y -> %.3f\n", new_target(1)); }
        if (zp && !prev_zp) { new_target(2) += STEP_POS; pos_step = true; printf("[STEP] +Z -> %.3f\n", new_target(2)); }
        if (zn && !prev_zn) { new_target(2) -= STEP_POS; pos_step = true; printf("[STEP] -Z -> %.3f\n", new_target(2)); }

        new_target(0) = std::max(0.15, std::min(0.55, new_target(0)));
        new_target(1) = std::max(-0.35, std::min(0.35, new_target(1)));
        new_target(2) = std::max(0.05, std::min(0.55, new_target(2)));

        if (pos_step && have_initial) {
            Eigen::Matrix4d T_target = Eigen::Matrix4d::Identity();
            T_target.block<3,1>(0,3) = new_target;
            Eigen::Matrix<double, 5, 1> solved = current_joints;
            bool ok = teleop::ik::solveIK(T_target, current_joints,
                                           ik_params, limits, solved);
            printf("[IK] solved ok=%d joints=(%.2f,%.2f,%.2f,%.2f,%.2f)\n",
                   ok, solved(0), solved(1), solved(2), solved(3), solved(4));
            target_joints.head<4>() = solved.head<4>();  // keep wrist_rotate separate
            target_pos = new_target;
        }

        // Wrist rotate direct
        if (ywp && !prev_ywp) { target_joints(4) += STEP_YAW; printf("[STEP] +yaw -> %.2f\n", target_joints(4)); }
        if (ywn && !prev_ywn) { target_joints(4) -= STEP_YAW; printf("[STEP] -yaw -> %.2f\n", target_joints(4)); }
        target_joints(4) = std::max(limits.lower(4), std::min(limits.upper(4), target_joints(4)));

        // Gripper
        if (gp && !prev_gp) {
            gripper_state += STEP_GRIP;
            if (gripper_state > 1.0f) gripper_state = 1.0f;
            gripper_hold_ticks = 25;
            printf("[STEP] grip+ -> %.2f\n", gripper_state);
        }
        if (gn && !prev_gn) {
            gripper_state -= STEP_GRIP;
            if (gripper_state < -1.0f) gripper_state = -1.0f;
            gripper_hold_ticks = 25;
            printf("[STEP] grip- -> %.2f\n", gripper_state);
        }

        prev_xp = xp; prev_xn = xn;
        prev_yp = yp; prev_yn = yn;
        prev_zp = zp; prev_zn = zn;
        prev_ywp = ywp; prev_ywn = ywn;
        prev_gp  = gp;  prev_gn  = gn;

        // Drive arm toward target_joints at a limited rate
        const double STEP_LIMIT = 0.04;
        float jvel[5];
        for (int i = 0; i < 5; i++) {
            double err = target_joints(i) - current_joints(i);
            double step = err;
            if (step >  STEP_LIMIT) step =  STEP_LIMIT;
            if (step < -STEP_LIMIT) step = -STEP_LIMIT;
            double raw_vel = step / 0.02;  // rad/s
            float n = (float)raw_vel;
            if (n > 1.0f) n = 1.0f; if (n < -1.0f) n = -1.0f;
            jvel[i] = n;
        }

        float gripper_out = 0.0f;
        if (gripper_hold_ticks > 0) {
            gripper_out = gripper_state;
            gripper_hold_ticks--;
        }

        if (bridge_connected) {
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WAIST,       jvel[0]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_SHOULDER,    jvel[1]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_ELBOW,       jvel[2]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ANGLE, jvel[3]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ROT,   jvel[4]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::GRIPPER_CMD,           gripper_out);
            clientWriteBool (bridge_client, teleop::opcua_ids::DEADMAN, true);
            clientWriteUInt32(bridge_client, teleop::opcua_ids::STAMP, loop_count);
        }

        if (++loop_count % 200 == 0) {
            printf("[IK] cur=(%.2f,%.2f,%.2f,%.2f,%.2f) tgt=(%.2f,%.2f,%.2f,%.2f,%.2f)\n",
                   current_joints(0), current_joints(1), current_joints(2), current_joints(3), current_joints(4),
                   target_joints(0), target_joints(1), target_joints(2), target_joints(3), target_joints(4));
        }

        usleep(period_us);
    }

    if (fb_connected) UA_Client_disconnect(fb_client);
    UA_Client_delete(fb_client);
    if (bridge_connected) UA_Client_disconnect(bridge_client);
    UA_Client_delete(bridge_client);
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    return 0;
}
