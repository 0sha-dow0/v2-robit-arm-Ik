# teleop_opcua_v2

C++ ROS 2 package for keyboard teleoperation of the **Interbotix ViperX-300 (`vx300`)** using:
- **OPC UA** as the input-to-controller skill interface
- **custom PoE forward kinematics + numerical IK**
- **Interbotix position commands** with the correct publish-once-then-wait behavior

This package is designed for the **5-DOF `vx300`**, not the `vx300s`.

## Architecture

```text
Keyboard (/dev/input/eventX)
   -> input_skill_server
   -> OPC UA variables on opc.tcp://<host>:4840
   -> opcua_teleop
   -> custom PoE position-only IK
   -> /vx300/commands/joint_group
   -> vx300 arm
```

## Key Mapping

- `W / S`: +x / -x
- `A / D`: +y / -y
- `R / F`: +z / -z
- `I / K`: wrist_angle up / down
- `J / L`: wrist_rotate CCW / CW
- `O / P`: gripper open / close

Defaults:
- Cartesian step = `0.01 m`
- Wrist step = `5 deg`
- Move time = `300 ms`

## Important Design Notes

1. The `vx300` is **5 DOF**, so this package uses **position-only IK**.
2. No full 6-DOF orientation target is enforced.
3. Wrist controls are direct joint increments.
4. The arm is commanded with **one joint-group message per move**.
5. Before each move, the package writes `Profile_Velocity` through `/<robot_name>/set_motor_registers` so the motion duration matches the requested `moving_time_ms`.

This follows the documented Interbotix ROS interface: `/<robot_name>/commands/joint_group`, `/<robot_name>/commands/joint_single`, `/<robot_name>/joint_states`, and `/<robot_name>/set_motor_registers`. The `JointGroupCommand`, `JointSingleCommand`, and `RegisterValues` definitions are published in Interbotix’s ROS 2 docs, and `Profile_Velocity` in time-based profile mode determines move duration in milliseconds. citeturn784819view2turn784819view0turn940444view1

## Dependencies

Install or confirm these are present on the target machine:
- ROS 2 Humble
- Interbotix X-Series SDK / messages
- `open62541` development package
- `libevdev` development package
- `yaml-cpp`
- Eigen3

Typical Ubuntu packages:

```bash
sudo apt-get install -y \
  libeigen3-dev \
  libyaml-cpp-dev \
  libevdev-dev \
  libopen62541-dev \
  pkg-config
```

## Build

Put this package inside a ROS 2 workspace `src/` folder, then build with colcon.

```bash
cd ~/Downloads/v2-robit-arm-Ik-master
mkdir -p src
cp -r teleop_opcua_v2 src/
source /opt/ros/humble/setup.bash
colcon build --packages-select teleop_opcua_v2
source install/setup.bash
```

## Run

### Terminal 1: launch the Interbotix driver

```bash
source /opt/ros/humble/setup.bash
source ~/interbotix_ws/install/setup.bash
ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=vx300 use_rviz:=true
```

### Terminal 2: run the keyboard OPC UA skill server

```bash
source /opt/ros/humble/setup.bash
source ~/Downloads/v2-robit-arm-Ik-master/install/setup.bash
ros2 run teleop_opcua_v2 input_skill_server \
  --ros-args \
  -p config:=/absolute/path/to/teleop_opcua_v2/config/keyboard.yaml \
  -p opcua_port:=4840
```

### Terminal 3: run the teleop consumer

```bash
source /opt/ros/humble/setup.bash
source ~/Downloads/v2-robit-arm-Ik-master/install/setup.bash
ros2 run teleop_opcua_v2 opcua_teleop \
  --ros-args \
  -p robot_name:=vx300 \
  -p opcua_endpoint:=opc.tcp://127.0.0.1:4840 \
  -p moving_time_ms:=300 \
  -p gripper_name:=gripper
```

## Expected Behavior

- One keyboard tap should produce one visible arm move.
- The arm should stop after each move.
- No velocity stream should be published.
- Cartesian keys should move the end-effector in approximately 1 cm increments.
- Wrist keys should adjust the last two arm joints directly.

## Notes You May Need To Tune On Hardware

### 1. OPC UA node lookup
This implementation uses fixed node IDs for a simple shared-variable skill model. If your open62541 build behaves differently with string node IDs, convert the client to browse by path instead of reading by fixed node ID.

### 2. Gripper command semantics
The gripper message uses `JointSingleCommand` on the configured `gripper_name`. Depending on your Interbotix mode configuration, you may need to tune `gripper_open_cmd` and `gripper_close_cmd` or swap from position-style values to current/PWM values.

### 3. Y direction sign
Depending on your base frame convention, you might prefer to swap the signs on `A` and `D` in `keyboard_reader.cpp`.

### 4. evdev permissions
If `/dev/input/eventX` access fails, run with sufficient permissions or add the user to the proper input group.

## File Layout

```text
teleop_opcua_v2/
├── CMakeLists.txt
├── package.xml
├── README.md
├── config/
│   └── keyboard.yaml
├── include/teleop_opcua_v2/
│   ├── arm_bridge.hpp
│   ├── ik_solver.hpp
│   ├── joint_limits.hpp
│   ├── keyboard_reader.hpp
│   ├── opcua_client.hpp
│   ├── opcua_server.hpp
│   ├── poe_kinematics.hpp
│   └── skill_types.hpp
└── src/
    ├── arm_bridge.cpp
    ├── ik_solver.cpp
    ├── input_skill_server.cpp
    ├── keyboard_reader.cpp
    ├── opcua_client.cpp
    ├── opcua_server.cpp
    ├── opcua_teleop.cpp
    └── poe_kinematics.cpp
```

## Testing Sequence

1. Launch the arm driver.
2. Confirm joint states are arriving:
   ```bash
   ros2 topic echo /vx300/joint_states
   ```
3. Start `input_skill_server`.
4. Start `opcua_teleop`.
5. Tap `W`, `A`, `R`, `I`, `J`, and confirm logs show one consumed pulse and one move command.
6. If IK fails near boundaries, move back toward the center of the workspace and retry.

## Why This Matches the Capstone Goal

- OPC UA stays between the input device and the arm controller.
- The IK is custom and uses PoE + numerical solve.
- The implementation respects the Interbotix ROS 2 control model instead of streaming commands continuously. The Interbotix docs describe the downstream arm-control stack and the message/service interfaces used here. citeturn784819view1turn784819view2turn784819view0
