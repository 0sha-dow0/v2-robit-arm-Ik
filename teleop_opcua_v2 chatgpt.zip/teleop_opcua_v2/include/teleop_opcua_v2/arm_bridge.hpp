#pragma once

#include <Eigen/Dense>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <interbotix_xs_msgs/msg/joint_group_command.hpp>
#include <interbotix_xs_msgs/msg/joint_single_command.hpp>
#include <interbotix_xs_msgs/srv/register_values.hpp>

#include <array>
#include <mutex>
#include <string>
#include <vector>

#include "teleop_opcua_v2/joint_limits.hpp"

namespace teleop_opcua_v2 {

class ArmBridge {
 public:
  using JointVec = Eigen::Matrix<double, kNumJoints, 1>;

  ArmBridge(rclcpp::Node* node, std::string robot_name, int moving_time_ms, std::string gripper_name);

  bool wait_for_joint_state(double timeout_sec) const;
  bool get_current_joints(JointVec* q_out) const;
  bool send_arm_command(const JointVec& q_target, bool block = true) const;
  void send_gripper_command(double cmd) const;
  int moving_time_ms() const { return moving_time_ms_; }

 private:
  void joint_state_cb(const sensor_msgs::msg::JointState::SharedPtr msg);
  bool set_profile_velocity_ms(int value_ms) const;

  rclcpp::Node* node_;
  std::string robot_name_;
  int moving_time_ms_;
  std::string gripper_name_;

  rclcpp::Publisher<interbotix_xs_msgs::msg::JointGroupCommand>::SharedPtr arm_pub_;
  rclcpp::Publisher<interbotix_xs_msgs::msg::JointSingleCommand>::SharedPtr gripper_pub_;
  rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
  rclcpp::Client<interbotix_xs_msgs::srv::RegisterValues>::SharedPtr reg_client_;

  mutable std::mutex mutex_;
  JointVec latest_q_ = JointVec::Zero();
  bool have_joint_state_{false};
  std::array<int, kNumJoints> name_to_index_{{-1, -1, -1, -1, -1}};
};

}  // namespace teleop_opcua_v2
