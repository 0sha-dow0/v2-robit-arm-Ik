#pragma once

#include <Eigen/Dense>

#include "teleop_opcua_v2/joint_limits.hpp"
#include "teleop_opcua_v2/poe_kinematics.hpp"

namespace teleop_opcua_v2 {

struct IkResult {
  bool success{false};
  int iterations{0};
  double final_error_norm{1e9};
  Eigen::Matrix<double, kNumJoints, 1> q;
};

class IkSolver {
 public:
  using JointVec = Eigen::Matrix<double, kNumJoints, 1>;

  explicit IkSolver(PoeKinematics kinematics);

  IkResult solve_position_only(
      const Eigen::Vector3d& target,
      const JointVec& seed,
      int max_iters = 60,
      double pos_tol = 1e-3,
      double lambda = 0.03,
      double joint_limit_gain = 0.02) const;

 private:
  PoeKinematics kinematics_;
};

}  // namespace teleop_opcua_v2
