#pragma once

#include <Eigen/Dense>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

namespace teleop_opcua_v2 {

inline constexpr int kArmDof = 5;
inline constexpr int kNumJoints = 5;

static const std::vector<std::string> kJointNames = {
    "waist", "shoulder", "elbow", "wrist_angle", "wrist_rotate"};

inline Eigen::Matrix<double, kNumJoints, 1> lower_limits() {
  Eigen::Matrix<double, kNumJoints, 1> q;
  q << -M_PI, -1.762783, -1.762783, -1.867502, -M_PI;
  return q;
}

inline Eigen::Matrix<double, kNumJoints, 1> upper_limits() {
  Eigen::Matrix<double, kNumJoints, 1> q;
  q << M_PI, 1.762783, 1.605703, 2.268928, M_PI;
  return q;
}

inline double clamp_scalar(double x, double lo, double hi) {
  return std::max(lo, std::min(x, hi));
}

inline Eigen::Matrix<double, kNumJoints, 1> clamp_joints(
    const Eigen::Matrix<double, kNumJoints, 1>& q) {
  const auto lo = lower_limits();
  const auto hi = upper_limits();
  Eigen::Matrix<double, kNumJoints, 1> out = q;
  for (int i = 0; i < kNumJoints; ++i) {
    out(i) = clamp_scalar(out(i), lo(i), hi(i));
  }
  return out;
}

inline Eigen::Matrix<double, kNumJoints, 1> joint_center() {
  return 0.5 * (lower_limits() + upper_limits());
}

}  // namespace teleop_opcua_v2
