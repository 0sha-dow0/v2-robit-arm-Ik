#pragma once

#include <libevdev/libevdev.h>

#include <optional>
#include <string>
#include <unordered_map>

#include "teleop_opcua_v2/skill_types.hpp"

namespace teleop_opcua_v2 {

struct KeyboardConfig {
  std::string device_path{"/dev/input/event4"};
  double cart_step_m{0.01};
  double wrist_step_rad{0.0872664626};
  double gripper_step{0.05};
};

class KeyboardReader {
 public:
  explicit KeyboardReader(KeyboardConfig config);
  ~KeyboardReader();

  bool open_device(std::string* error = nullptr);
  std::optional<SkillPulse> read_pulse();
  const KeyboardConfig& config() const { return config_; }

 private:
  std::optional<SkillPulse> pulse_from_keycode(unsigned int code) const;

  KeyboardConfig config_;
  int fd_{-1};
  libevdev* dev_{nullptr};
  int seq_{0};
};

}  // namespace teleop_opcua_v2
