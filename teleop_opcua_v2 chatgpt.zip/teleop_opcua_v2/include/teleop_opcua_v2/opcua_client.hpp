#pragma once

#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/plugin/log_stdout.h>
#include <open62541/types.h>

#include <string>

#include "teleop_opcua_v2/skill_types.hpp"

namespace teleop_opcua_v2 {

class OpcUaSkillClient {
 public:
  explicit OpcUaSkillClient(std::string endpoint);
  ~OpcUaSkillClient();

  bool connect(std::string* error = nullptr);
  bool read_latest_pulse(SkillPulse* pulse, std::string* error = nullptr);

 private:
  bool read_int32_node(const UA_NodeId& node_id, int32_t* value);
  bool read_double_node(const UA_NodeId& node_id, double* value);

  std::string endpoint_;
  UA_Client* client_{nullptr};

  UA_NodeId seq_node_id_;
  UA_NodeId dx_node_id_;
  UA_NodeId dy_node_id_;
  UA_NodeId dz_node_id_;
  UA_NodeId wrist_angle_node_id_;
  UA_NodeId wrist_rotate_node_id_;
  UA_NodeId gripper_node_id_;
};

}  // namespace teleop_opcua_v2
