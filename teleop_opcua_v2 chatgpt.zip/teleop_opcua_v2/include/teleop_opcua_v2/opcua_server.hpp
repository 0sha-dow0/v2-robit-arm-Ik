#pragma once

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/plugin/log_stdout.h>
#include <open62541/types.h>

#include <string>

#include "teleop_opcua_v2/skill_types.hpp"

namespace teleop_opcua_v2 {

class OpcUaSkillServer {
 public:
  explicit OpcUaSkillServer(uint16_t port = 4840);
  ~OpcUaSkillServer();

  bool init(std::string* error = nullptr);
  void publish_pulse(const SkillPulse& pulse);
  void iterate_once(bool wait_internal = false);

 private:
  UA_Server* server_{nullptr};
  uint16_t port_{4840};

  UA_NodeId skill_folder_id_;
  UA_NodeId seq_node_id_;
  UA_NodeId dx_node_id_;
  UA_NodeId dy_node_id_;
  UA_NodeId dz_node_id_;
  UA_NodeId wrist_angle_node_id_;
  UA_NodeId wrist_rotate_node_id_;
  UA_NodeId gripper_node_id_;

  UA_NodeId add_double_variable(const char* name, double initial_value, UA_NodeId parent);
  UA_NodeId add_int32_variable(const char* name, int32_t initial_value, UA_NodeId parent);
};

}  // namespace teleop_opcua_v2
