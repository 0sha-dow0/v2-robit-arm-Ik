#pragma once

#include <Eigen/Dense>

#include "teleop_opcua_v2/joint_limits.hpp"

namespace teleop_opcua_v2 {

class PoeKinematics {
 public:
  using JointVec = Eigen::Matrix<double, kNumJoints, 1>;
  using ScrewMat = Eigen::Matrix<double, 6, kNumJoints>;

  PoeKinematics();

  Eigen::Matrix4d forward_kinematics(const JointVec& q) const;
  Eigen::Vector3d position(const JointVec& q) const;
  Eigen::Matrix<double, 6, kNumJoints> jacobian_space(const JointVec& q) const;
  Eigen::Matrix<double, 3, kNumJoints> position_jacobian(const JointVec& q) const;

  const Eigen::Matrix4d& M() const { return M_; }
  const ScrewMat& Slist() const { return Slist_; }

 private:
  static Eigen::Matrix3d vec_to_so3(const Eigen::Vector3d& w);
  static Eigen::Matrix4d vec_to_se3(const Eigen::Matrix<double, 6, 1>& s);
  static Eigen::Matrix4d matrix_exp6(const Eigen::Matrix<double, 6, 1>& s_theta);
  static Eigen::Matrix<double, 6, 6> adjoint(const Eigen::Matrix4d& T);

  Eigen::Matrix4d M_;
  ScrewMat Slist_;
};

}  // namespace teleop_opcua_v2
