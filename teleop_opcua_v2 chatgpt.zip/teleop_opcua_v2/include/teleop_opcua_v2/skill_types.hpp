#pragma once

#include <cstdint>

namespace teleop_opcua_v2 {

struct SkillPulse {
  int32_t seq{0};
  double dx{0.0};
  double dy{0.0};
  double dz{0.0};
  double d_wrist_angle{0.0};
  double d_wrist_rotate{0.0};
  double d_gripper{0.0};
};

}  // namespace teleop_opcua_v2
