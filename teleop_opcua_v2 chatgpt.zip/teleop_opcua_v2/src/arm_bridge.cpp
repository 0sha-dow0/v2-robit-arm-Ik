#include "teleop_opcua_v2/arm_bridge.hpp"

#include <chrono>
#include <unordered_map>

using namespace std::chrono_literals;

namespace teleop_opcua_v2 {

ArmBridge::ArmBridge(
    rclcpp::Node* node,
    std::string robot_name,
    int moving_time_ms,
    std::string gripper_name)
    : node_(node),
      robot_name_(std::move(robot_name)),
      moving_time_ms_(moving_time_ms),
      gripper_name_(std::move(gripper_name)) {
  arm_pub_ = node_->create_publisher<interbotix_xs_msgs::msg::JointGroupCommand>(
      "/" + robot_name_ + "/commands/joint_group", 10);
  gripper_pub_ = node_->create_publisher<interbotix_xs_msgs::msg::JointSingleCommand>(
      "/" + robot_name_ + "/commands/joint_single", 10);
  joint_state_sub_ = node_->create_subscription<sensor_msgs::msg::JointState>(
      "/" + robot_name_ + "/joint_states", 20,
      std::bind(&ArmBridge::joint_state_cb, this, std::placeholders::_1));
  reg_client_ = node_->create_client<interbotix_xs_msgs::srv::RegisterValues>(
      "/" + robot_name_ + "/set_motor_registers");
}

void ArmBridge::joint_state_cb(const sensor_msgs::msg::JointState::SharedPtr msg) {
  std::lock_guard<std::mutex> lock(mutex_);
  std::unordered_map<std::string, size_t> index;
  for (size_t i = 0; i < msg->name.size(); ++i) {
    index[msg->name[i]] = i;
  }

  for (int i = 0; i < kNumJoints; ++i) {
    auto it = index.find(kJointNames[i]);
    if (it == index.end()) {
      return;
    }
    if (it->second >= msg->position.size()) {
      return;
    }
    latest_q_(i) = msg->position[it->second];
  }
  have_joint_state_ = true;
}

bool ArmBridge::wait_for_joint_state(double timeout_sec) const {
  const auto start = node_->now();
  rclcpp::Rate rate(100.0);
  while (rclcpp::ok()) {
    {
      std::lock_guard<std::mutex> lock(mutex_);
      if (have_joint_state_) {
        return true;
      }
    }
    if ((node_->now() - start).seconds() > timeout_sec) {
      return false;
    }
    rate.sleep();
  }
  return false;
}

bool ArmBridge::get_current_joints(JointVec* q_out) const {
  std::lock_guard<std::mutex> lock(mutex_);
  if (!have_joint_state_) {
    return false;
  }
  *q_out = latest_q_;
  return true;
}

bool ArmBridge::set_profile_velocity_ms(int value_ms) const {
  if (!reg_client_->wait_for_service(2s)) {
    RCLCPP_ERROR(node_->get_logger(), "set_motor_registers service unavailable");
    return false;
  }

  auto req = std::make_shared<interbotix_xs_msgs::srv::RegisterValues::Request>();
  req->cmd_type = "group";
  req->name = "arm";
  req->reg = "Profile_Velocity";
  req->value = value_ms;

  auto future = reg_client_->async_send_request(req);
  auto rc = rclcpp::spin_until_future_complete(node_->get_node_base_interface(), future, 2s);
  return rc == rclcpp::FutureReturnCode::SUCCESS;
}

bool ArmBridge::send_arm_command(const JointVec& q_target, bool block) const {
  if (!set_profile_velocity_ms(moving_time_ms_)) {
    return false;
  }

  interbotix_xs_msgs::msg::JointGroupCommand msg;
  msg.name = "arm";
  msg.cmd.resize(kNumJoints);
  for (int i = 0; i < kNumJoints; ++i) {
    msg.cmd[i] = static_cast<float>(q_target(i));
  }
  arm_pub_->publish(msg);

  if (block) {
    rclcpp::sleep_for(std::chrono::milliseconds(moving_time_ms_));
  }
  return true;
}

void ArmBridge::send_gripper_command(double cmd) const {
  interbotix_xs_msgs::msg::JointSingleCommand msg;
  msg.name = gripper_name_;
  msg.cmd = static_cast<float>(cmd);
  gripper_pub_->publish(msg);
}

}  // namespace teleop_opcua_v2
