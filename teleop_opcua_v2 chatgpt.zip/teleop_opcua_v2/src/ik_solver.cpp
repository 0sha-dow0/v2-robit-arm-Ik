#include "teleop_opcua_v2/ik_solver.hpp"

namespace teleop_opcua_v2 {

IkSolver::IkSolver(PoeKinematics kinematics) : kinematics_(std::move(kinematics)) {}

IkResult IkSolver::solve_position_only(
    const Eigen::Vector3d& target,
    const JointVec& seed,
    int max_iters,
    double pos_tol,
    double lambda,
    double joint_limit_gain) const {
  JointVec q = clamp_joints(seed);
  const JointVec q_mid = joint_center();
  const JointVec q_lo = lower_limits();
  const JointVec q_hi = upper_limits();

  IkResult result;
  result.q = q;

  for (int iter = 0; iter < max_iters; ++iter) {
    const Eigen::Vector3d p = kinematics_.position(q);
    const Eigen::Vector3d e = target - p;
    const double err = e.norm();

    result.iterations = iter + 1;
    result.final_error_norm = err;
    result.q = q;

    if (err < pos_tol) {
      result.success = true;
      return result;
    }

    const auto J = kinematics_.position_jacobian(q);
    const Eigen::Matrix3d JJt = J * J.transpose();
    const Eigen::Matrix3d damped = JJt + lambda * lambda * Eigen::Matrix3d::Identity();
    const JointVec dq_task = J.transpose() * damped.ldlt().solve(e);

    const Eigen::Matrix<double, kNumJoints, kNumJoints> I =
        Eigen::Matrix<double, kNumJoints, kNumJoints>::Identity();
    const auto J_pinv = J.transpose() * damped.inverse();

    JointVec grad = JointVec::Zero();
    for (int i = 0; i < kNumJoints; ++i) {
      const double range = (q_hi(i) - q_lo(i));
      grad(i) = -2.0 * (q(i) - q_mid(i)) / (range * range + 1e-9);
    }

    const JointVec dq_null = (I - J_pinv * J) * (joint_limit_gain * grad);
    q = clamp_joints(q + dq_task + dq_null);
  }

  return result;
}

}  // namespace teleop_opcua_v2
