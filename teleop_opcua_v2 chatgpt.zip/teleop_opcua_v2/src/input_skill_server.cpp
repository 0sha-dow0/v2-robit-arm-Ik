#include <chrono>
#include <memory>
#include <thread>

#include <rclcpp/rclcpp.hpp>
#include <yaml-cpp/yaml.h>

#include "teleop_opcua_v2/keyboard_reader.hpp"
#include "teleop_opcua_v2/opcua_server.hpp"

using namespace std::chrono_literals;

namespace teleop = teleop_opcua_v2;

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<rclcpp::Node>("input_skill_server");

  node->declare_parameter<std::string>("config", "config/keyboard.yaml");
  node->declare_parameter<int>("opcua_port", 4840);

  const auto config_path = node->get_parameter("config").as_string();
  const int opcua_port = node->get_parameter("opcua_port").as_int();

  teleop::KeyboardConfig config;
  try {
    const YAML::Node yaml = YAML::LoadFile(config_path);
    config.device_path = yaml["device_path"].as<std::string>(config.device_path);
    config.cart_step_m = yaml["cart_step_m"].as<double>(config.cart_step_m);
    config.wrist_step_rad = yaml["wrist_step_rad"].as<double>(config.wrist_step_rad);
    config.gripper_step = yaml["gripper_step"].as<double>(config.gripper_step);
  } catch (const std::exception& e) {
    RCLCPP_ERROR(node->get_logger(), "failed to load keyboard config: %s", e.what());
    rclcpp::shutdown();
    return 1;
  }

  teleop::KeyboardReader reader(config);
  std::string error;
  if (!reader.open_device(&error)) {
    RCLCPP_ERROR(node->get_logger(), "%s", error.c_str());
    rclcpp::shutdown();
    return 1;
  }

  teleop::OpcUaSkillServer server(static_cast<uint16_t>(opcua_port));
  if (!server.init(&error)) {
    RCLCPP_ERROR(node->get_logger(), "%s", error.c_str());
    rclcpp::shutdown();
    return 1;
  }

  RCLCPP_INFO(node->get_logger(), "Input skill server ready on OPC UA port %d, keyboard=%s",
              opcua_port, config.device_path.c_str());

  rclcpp::Rate rate(200.0);
  while (rclcpp::ok()) {
    server.iterate_once(false);
    if (auto pulse = reader.read_pulse(); pulse.has_value()) {
      server.publish_pulse(*pulse);
      RCLCPP_INFO(node->get_logger(),
                  "pulse seq=%d dx=%.3f dy=%.3f dz=%.3f d_wa=%.3f d_wr=%.3f d_g=%.3f",
                  pulse->seq, pulse->dx, pulse->dy, pulse->dz,
                  pulse->d_wrist_angle, pulse->d_wrist_rotate, pulse->d_gripper);
    }
    rclcpp::spin_some(node);
    rate.sleep();
  }

  rclcpp::shutdown();
  return 0;
}
