#include "teleop_opcua_v2/keyboard_reader.hpp"

#include <fcntl.h>
#include <linux/input-event-codes.h>
#include <unistd.h>

namespace teleop_opcua_v2 {

KeyboardReader::KeyboardReader(KeyboardConfig config) : config_(std::move(config)) {}

KeyboardReader::~KeyboardReader() {
  if (dev_ != nullptr) {
    libevdev_free(dev_);
    dev_ = nullptr;
  }
  if (fd_ >= 0) {
    close(fd_);
    fd_ = -1;
  }
}

bool KeyboardReader::open_device(std::string* error) {
  fd_ = open(config_.device_path.c_str(), O_RDONLY | O_NONBLOCK);
  if (fd_ < 0) {
    if (error) *error = "failed to open evdev device: " + config_.device_path;
    return false;
  }

  int rc = libevdev_new_from_fd(fd_, &dev_);
  if (rc < 0) {
    if (error) *error = "libevdev_new_from_fd failed";
    close(fd_);
    fd_ = -1;
    return false;
  }
  return true;
}

std::optional<SkillPulse> KeyboardReader::pulse_from_keycode(unsigned int code) const {
  SkillPulse pulse;
  pulse.seq = seq_ + 1;

  switch (code) {
    case KEY_W:
      pulse.dx = config_.cart_step_m;
      break;
    case KEY_S:
      pulse.dx = -config_.cart_step_m;
      break;
    case KEY_A:
      pulse.dy = config_.cart_step_m;
      break;
    case KEY_D:
      pulse.dy = -config_.cart_step_m;
      break;
    case KEY_R:
      pulse.dz = config_.cart_step_m;
      break;
    case KEY_F:
      pulse.dz = -config_.cart_step_m;
      break;
    case KEY_I:
      pulse.d_wrist_angle = config_.wrist_step_rad;
      break;
    case KEY_K:
      pulse.d_wrist_angle = -config_.wrist_step_rad;
      break;
    case KEY_J:
      pulse.d_wrist_rotate = config_.wrist_step_rad;
      break;
    case KEY_L:
      pulse.d_wrist_rotate = -config_.wrist_step_rad;
      break;
    case KEY_O:
      pulse.d_gripper = config_.gripper_step;
      break;
    case KEY_P:
      pulse.d_gripper = -config_.gripper_step;
      break;
    default:
      return std::nullopt;
  }

  return pulse;
}

std::optional<SkillPulse> KeyboardReader::read_pulse() {
  if (dev_ == nullptr) {
    return std::nullopt;
  }

  input_event ev{};
  int rc = libevdev_next_event(dev_, LIBEVDEV_READ_FLAG_NORMAL, &ev);
  if (rc == -EAGAIN) {
    return std::nullopt;
  }
  if (rc < 0) {
    return std::nullopt;
  }

  if (ev.type != EV_KEY) {
    return std::nullopt;
  }

  if (ev.value != 1) {
    return std::nullopt;
  }

  auto pulse = pulse_from_keycode(ev.code);
  if (pulse.has_value()) {
    ++seq_;
    pulse->seq = seq_;
  }
  return pulse;
}

}  // namespace teleop_opcua_v2
