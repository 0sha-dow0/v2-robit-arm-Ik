#include "teleop_opcua_v2/opcua_client.hpp"

namespace teleop_opcua_v2 {

namespace {
UA_NodeId make_string_node(const char* name) {
  return UA_NODEID_STRING(1, const_cast<char*>(name));
}
}  // namespace

OpcUaSkillClient::OpcUaSkillClient(std::string endpoint) : endpoint_(std::move(endpoint)) {
  seq_node_id_ = make_string_node("TeleopSkill/seq");
  dx_node_id_ = make_string_node("TeleopSkill/dx");
  dy_node_id_ = make_string_node("TeleopSkill/dy");
  dz_node_id_ = make_string_node("TeleopSkill/dz");
  wrist_angle_node_id_ = make_string_node("TeleopSkill/d_wrist_angle");
  wrist_rotate_node_id_ = make_string_node("TeleopSkill/d_wrist_rotate");
  gripper_node_id_ = make_string_node("TeleopSkill/d_gripper");
}

OpcUaSkillClient::~OpcUaSkillClient() {
  if (client_ != nullptr) {
    UA_Client_disconnect(client_);
    UA_Client_delete(client_);
    client_ = nullptr;
  }
}

bool OpcUaSkillClient::connect(std::string* error) {
  client_ = UA_Client_new();
  if (client_ == nullptr) {
    if (error) *error = "UA_Client_new failed";
    return false;
  }
  UA_ClientConfig_setDefault(UA_Client_getConfig(client_));
  const UA_StatusCode rc = UA_Client_connect(client_, endpoint_.c_str());
  if (rc != UA_STATUSCODE_GOOD) {
    if (error) *error = "UA_Client_connect failed";
    return false;
  }
  return true;
}

bool OpcUaSkillClient::read_int32_node(const UA_NodeId& node_id, int32_t* value) {
  UA_Variant val;
  UA_Variant_init(&val);
  const auto rc = UA_Client_readValueAttribute(client_, node_id, &val);
  if (rc != UA_STATUSCODE_GOOD || !UA_Variant_hasScalarType(&val, &UA_TYPES[UA_TYPES_INT32])) {
    UA_Variant_clear(&val);
    return false;
  }
  *value = *static_cast<UA_Int32*>(val.data);
  UA_Variant_clear(&val);
  return true;
}

bool OpcUaSkillClient::read_double_node(const UA_NodeId& node_id, double* value) {
  UA_Variant val;
  UA_Variant_init(&val);
  const auto rc = UA_Client_readValueAttribute(client_, node_id, &val);
  if (rc != UA_STATUSCODE_GOOD || !UA_Variant_hasScalarType(&val, &UA_TYPES[UA_TYPES_DOUBLE])) {
    UA_Variant_clear(&val);
    return false;
  }
  *value = *static_cast<UA_Double*>(val.data);
  UA_Variant_clear(&val);
  return true;
}

bool OpcUaSkillClient::read_latest_pulse(SkillPulse* pulse, std::string* error) {
  if (client_ == nullptr) {
    if (error) *error = "client not connected";
    return false;
  }

  if (!read_int32_node(seq_node_id_, &pulse->seq) ||
      !read_double_node(dx_node_id_, &pulse->dx) ||
      !read_double_node(dy_node_id_, &pulse->dy) ||
      !read_double_node(dz_node_id_, &pulse->dz) ||
      !read_double_node(wrist_angle_node_id_, &pulse->d_wrist_angle) ||
      !read_double_node(wrist_rotate_node_id_, &pulse->d_wrist_rotate) ||
      !read_double_node(gripper_node_id_, &pulse->d_gripper)) {
    if (error) *error = "failed to read OPC UA pulse node";
    return false;
  }
  return true;
}

}  // namespace teleop_opcua_v2
