#include "teleop_opcua_v2/opcua_server.hpp"

namespace teleop_opcua_v2 {

OpcUaSkillServer::OpcUaSkillServer(uint16_t port) : port_(port) {}

OpcUaSkillServer::~OpcUaSkillServer() {
  if (server_ != nullptr) {
    UA_Server_delete(server_);
    server_ = nullptr;
  }
}

UA_NodeId OpcUaSkillServer::add_int32_variable(const char* name, int32_t initial_value, UA_NodeId parent) {
  UA_VariableAttributes attr = UA_VariableAttributes_default;
  UA_Int32 value = initial_value;
  UA_Variant_setScalar(&attr.value, &value, &UA_TYPES[UA_TYPES_INT32]);
  attr.displayName = UA_LOCALIZEDTEXT(const_cast<char*>("en-US"), const_cast<char*>(name));
  attr.accessLevel = UA_ACCESSLEVELMASK_READ | UA_ACCESSLEVELMASK_WRITE;

  UA_NodeId new_node_id;
  UA_QualifiedName browse_name = UA_QUALIFIEDNAME(1, const_cast<char*>(name));
  std::string node_id_text = std::string("TeleopSkill/") + name;
  UA_NodeId requested = UA_NODEID_STRING(1, const_cast<char*>(node_id_text.c_str()));
  UA_Server_addVariableNode(
      server_, requested, parent,
      UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES), browse_name,
      UA_NODEID_NUMERIC(0, UA_NS0ID_BASEDATAVARIABLETYPE), attr,
      nullptr, &new_node_id);
  return new_node_id;
}

UA_NodeId OpcUaSkillServer::add_double_variable(const char* name, double initial_value, UA_NodeId parent) {
  UA_VariableAttributes attr = UA_VariableAttributes_default;
  UA_Double value = initial_value;
  UA_Variant_setScalar(&attr.value, &value, &UA_TYPES[UA_TYPES_DOUBLE]);
  attr.displayName = UA_LOCALIZEDTEXT(const_cast<char*>("en-US"), const_cast<char*>(name));
  attr.accessLevel = UA_ACCESSLEVELMASK_READ | UA_ACCESSLEVELMASK_WRITE;

  UA_NodeId new_node_id;
  UA_QualifiedName browse_name = UA_QUALIFIEDNAME(1, const_cast<char*>(name));
  std::string node_id_text = std::string("TeleopSkill/") + name;
  UA_NodeId requested = UA_NODEID_STRING(1, const_cast<char*>(node_id_text.c_str()));
  UA_Server_addVariableNode(
      server_, requested, parent,
      UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES), browse_name,
      UA_NODEID_NUMERIC(0, UA_NS0ID_BASEDATAVARIABLETYPE), attr,
      nullptr, &new_node_id);
  return new_node_id;
}

bool OpcUaSkillServer::init(std::string* error) {
  server_ = UA_Server_new();
  if (server_ == nullptr) {
    if (error) *error = "UA_Server_new failed";
    return false;
  }

  UA_ServerConfig* config = UA_Server_getConfig(server_);
  UA_ServerConfig_setDefault(config);
  config->networkLayers[0].port = port_;

  UA_ObjectAttributes folder_attr = UA_ObjectAttributes_default;
  folder_attr.displayName = UA_LOCALIZEDTEXT(const_cast<char*>("en-US"), const_cast<char*>("TeleopSkill"));
  UA_Server_addObjectNode(
      server_, UA_NODEID_STRING(1, const_cast<char*>("TeleopSkill")),
      UA_NODEID_NUMERIC(0, UA_NS0ID_OBJECTSFOLDER),
      UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES),
      UA_QUALIFIEDNAME(1, const_cast<char*>("TeleopSkill")),
      UA_NODEID_NUMERIC(0, UA_NS0ID_BASEOBJECTTYPE), folder_attr,
      nullptr, &skill_folder_id_);

  seq_node_id_ = add_int32_variable("seq", 0, skill_folder_id_);
  dx_node_id_ = add_double_variable("dx", 0.0, skill_folder_id_);
  dy_node_id_ = add_double_variable("dy", 0.0, skill_folder_id_);
  dz_node_id_ = add_double_variable("dz", 0.0, skill_folder_id_);
  wrist_angle_node_id_ = add_double_variable("d_wrist_angle", 0.0, skill_folder_id_);
  wrist_rotate_node_id_ = add_double_variable("d_wrist_rotate", 0.0, skill_folder_id_);
  gripper_node_id_ = add_double_variable("d_gripper", 0.0, skill_folder_id_);
  return true;
}

void OpcUaSkillServer::publish_pulse(const SkillPulse& pulse) {
  UA_Variant value;
  UA_Variant_init(&value);

  UA_Int32 seq = pulse.seq;
  UA_Variant_setScalar(&value, &seq, &UA_TYPES[UA_TYPES_INT32]);
  UA_Server_writeValue(server_, seq_node_id_, value);

  UA_Double d = pulse.dx;
  UA_Variant_setScalar(&value, &d, &UA_TYPES[UA_TYPES_DOUBLE]);
  UA_Server_writeValue(server_, dx_node_id_, value);

  d = pulse.dy;
  UA_Variant_setScalar(&value, &d, &UA_TYPES[UA_TYPES_DOUBLE]);
  UA_Server_writeValue(server_, dy_node_id_, value);

  d = pulse.dz;
  UA_Variant_setScalar(&value, &d, &UA_TYPES[UA_TYPES_DOUBLE]);
  UA_Server_writeValue(server_, dz_node_id_, value);

  d = pulse.d_wrist_angle;
  UA_Variant_setScalar(&value, &d, &UA_TYPES[UA_TYPES_DOUBLE]);
  UA_Server_writeValue(server_, wrist_angle_node_id_, value);

  d = pulse.d_wrist_rotate;
  UA_Variant_setScalar(&value, &d, &UA_TYPES[UA_TYPES_DOUBLE]);
  UA_Server_writeValue(server_, wrist_rotate_node_id_, value);

  d = pulse.d_gripper;
  UA_Variant_setScalar(&value, &d, &UA_TYPES[UA_TYPES_DOUBLE]);
  UA_Server_writeValue(server_, gripper_node_id_, value);
}

void OpcUaSkillServer::iterate_once(bool wait_internal) {
  if (server_ != nullptr) {
    UA_Server_run_iterate(server_, wait_internal);
  }
}

}  // namespace teleop_opcua_v2
