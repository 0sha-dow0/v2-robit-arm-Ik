#include <chrono>
#include <memory>
#include <string>

#include <Eigen/Dense>
#include <rclcpp/rclcpp.hpp>

#include "teleop_opcua_v2/arm_bridge.hpp"
#include "teleop_opcua_v2/ik_solver.hpp"
#include "teleop_opcua_v2/opcua_client.hpp"
#include "teleop_opcua_v2/poe_kinematics.hpp"

using namespace std::chrono_literals;

namespace teleop = teleop_opcua_v2;

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<rclcpp::Node>("opcua_teleop");

  node->declare_parameter<std::string>("robot_name", "vx300");
  node->declare_parameter<std::string>("opcua_endpoint", "opc.tcp://127.0.0.1:4840");
  node->declare_parameter<int>("moving_time_ms", 300);
  node->declare_parameter<std::string>("gripper_name", "gripper");
  node->declare_parameter<double>("gripper_open_cmd", 0.7);
  node->declare_parameter<double>("gripper_close_cmd", -0.7);

  const auto robot_name = node->get_parameter("robot_name").as_string();
  const auto endpoint = node->get_parameter("opcua_endpoint").as_string();
  const int moving_time_ms = node->get_parameter("moving_time_ms").as_int();
  const auto gripper_name = node->get_parameter("gripper_name").as_string();
  const double gripper_open_cmd = node->get_parameter("gripper_open_cmd").as_double();
  const double gripper_close_cmd = node->get_parameter("gripper_close_cmd").as_double();

  teleop::ArmBridge arm(node.get(), robot_name, moving_time_ms, gripper_name);
  if (!arm.wait_for_joint_state(10.0)) {
    RCLCPP_ERROR(node->get_logger(), "Timed out waiting for /%s/joint_states", robot_name.c_str());
    rclcpp::shutdown();
    return 1;
  }

  teleop::OpcUaSkillClient client(endpoint);
  std::string error;
  if (!client.connect(&error)) {
    RCLCPP_ERROR(node->get_logger(), "%s", error.c_str());
    rclcpp::shutdown();
    return 1;
  }

  teleop::PoeKinematics kinematics;
  teleop::IkSolver ik(kinematics);
  teleop::SkillPulse pulse;
  int last_seq = 0;

  RCLCPP_INFO(node->get_logger(), "opcua_teleop connected to %s and controlling /%s",
              endpoint.c_str(), robot_name.c_str());

  rclcpp::Rate poll_rate(50.0);
  while (rclcpp::ok()) {
    rclcpp::spin_some(node);

    if (!client.read_latest_pulse(&pulse, &error)) {
      RCLCPP_WARN_THROTTLE(node->get_logger(), *node->get_clock(), 2000, "%s", error.c_str());
      poll_rate.sleep();
      continue;
    }

    if (pulse.seq == 0 || pulse.seq == last_seq) {
      poll_rate.sleep();
      continue;
    }
    last_seq = pulse.seq;

    teleop::ArmBridge::JointVec q;
    if (!arm.get_current_joints(&q)) {
      RCLCPP_WARN(node->get_logger(), "No joint state available");
      poll_rate.sleep();
      continue;
    }

    bool handled = false;

    if (std::abs(pulse.d_wrist_angle) > 1e-12 || std::abs(pulse.d_wrist_rotate) > 1e-12) {
      auto q_next = q;
      q_next(3) += pulse.d_wrist_angle;
      q_next(4) += pulse.d_wrist_rotate;
      q_next = teleop::clamp_joints(q_next);
      handled = arm.send_arm_command(q_next, true);
      RCLCPP_INFO(node->get_logger(),
                  "joint-step seq=%d -> [%.3f %.3f %.3f %.3f %.3f]",
                  pulse.seq, q_next(0), q_next(1), q_next(2), q_next(3), q_next(4));
    } else if (std::abs(pulse.dx) > 1e-12 || std::abs(pulse.dy) > 1e-12 || std::abs(pulse.dz) > 1e-12) {
      const Eigen::Vector3d p_now = kinematics.position(q);
      const Eigen::Vector3d target = p_now + Eigen::Vector3d(pulse.dx, pulse.dy, pulse.dz);
      auto result = ik.solve_position_only(target, q, 60, 1e-3, 0.03, 0.02);
      if (!result.success) {
        RCLCPP_WARN(node->get_logger(),
                    "IK failed seq=%d target=[%.3f %.3f %.3f] err=%.6f",
                    pulse.seq, target.x(), target.y(), target.z(), result.final_error_norm);
      } else {
        handled = arm.send_arm_command(result.q, true);
        RCLCPP_INFO(node->get_logger(),
                    "cart-step seq=%d target=[%.3f %.3f %.3f] err=%.6f",
                    pulse.seq, target.x(), target.y(), target.z(), result.final_error_norm);
      }
    }

    if (std::abs(pulse.d_gripper) > 1e-12) {
      arm.send_gripper_command(pulse.d_gripper > 0.0 ? gripper_open_cmd : gripper_close_cmd);
      handled = true;
      RCLCPP_INFO(node->get_logger(), "gripper-step seq=%d cmd=%.3f",
                  pulse.seq, pulse.d_gripper > 0.0 ? gripper_open_cmd : gripper_close_cmd);
    }

    if (!handled) {
      RCLCPP_WARN(node->get_logger(), "Pulse seq=%d had no actionable delta", pulse.seq);
    }
  }

  rclcpp::shutdown();
  return 0;
}
