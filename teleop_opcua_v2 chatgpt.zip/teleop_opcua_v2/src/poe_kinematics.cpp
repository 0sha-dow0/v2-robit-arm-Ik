#include "teleop_opcua_v2/poe_kinematics.hpp"

#include <cmath>

namespace teleop_opcua_v2 {

PoeKinematics::PoeKinematics() {
  M_.setIdentity();
  M_(0, 3) = 0.536494;
  M_(2, 3) = 0.42705;

  Slist_.col(0) << 0.0, 0.0, 1.0, 0.0, 0.0, 0.0;
  Slist_.col(1) << 0.0, 1.0, 0.0, -0.12705, 0.0, 0.0;
  Slist_.col(2) << 0.0, 1.0, 0.0, -0.42705, 0.0, 0.05955;
  Slist_.col(3) << 0.0, 1.0, 0.0, -0.42705, 0.0, 0.35955;
  Slist_.col(4) << 1.0, 0.0, 0.0, 0.0, 0.42705, 0.0;
}

Eigen::Matrix3d PoeKinematics::vec_to_so3(const Eigen::Vector3d& w) {
  Eigen::Matrix3d m;
  m << 0.0, -w.z(), w.y(),
      w.z(), 0.0, -w.x(),
      -w.y(), w.x(), 0.0;
  return m;
}

Eigen::Matrix4d PoeKinematics::vec_to_se3(const Eigen::Matrix<double, 6, 1>& s) {
  Eigen::Matrix4d mat = Eigen::Matrix4d::Zero();
  mat.block<3, 3>(0, 0) = vec_to_so3(s.head<3>());
  mat.block<3, 1>(0, 3) = s.tail<3>();
  return mat;
}

Eigen::Matrix4d PoeKinematics::matrix_exp6(const Eigen::Matrix<double, 6, 1>& s_theta) {
  const Eigen::Vector3d wtheta = s_theta.head<3>();
  const Eigen::Vector3d vtheta = s_theta.tail<3>();
  const double theta = wtheta.norm();

  Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
  if (theta < 1e-10) {
    T.block<3, 1>(0, 3) = vtheta;
    return T;
  }

  const Eigen::Vector3d w = wtheta / theta;
  const Eigen::Vector3d v = vtheta / theta;
  const Eigen::Matrix3d wx = vec_to_so3(w);
  const Eigen::Matrix3d R =
      Eigen::Matrix3d::Identity() + std::sin(theta) * wx + (1.0 - std::cos(theta)) * wx * wx;
  const Eigen::Matrix3d G =
      Eigen::Matrix3d::Identity() * theta +
      (1.0 - std::cos(theta)) * wx +
      (theta - std::sin(theta)) * wx * wx;

  T.block<3, 3>(0, 0) = R;
  T.block<3, 1>(0, 3) = G * v;
  return T;
}

Eigen::Matrix<double, 6, 6> PoeKinematics::adjoint(const Eigen::Matrix4d& T) {
  Eigen::Matrix<double, 6, 6> Ad = Eigen::Matrix<double, 6, 6>::Zero();
  const Eigen::Matrix3d R = T.block<3, 3>(0, 0);
  const Eigen::Vector3d p = T.block<3, 1>(0, 3);
  const Eigen::Matrix3d px = vec_to_so3(p);

  Ad.block<3, 3>(0, 0) = R;
  Ad.block<3, 3>(3, 0) = px * R;
  Ad.block<3, 3>(3, 3) = R;
  return Ad;
}

Eigen::Matrix4d PoeKinematics::forward_kinematics(const JointVec& q) const {
  Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
  for (int i = 0; i < kNumJoints; ++i) {
    T = T * matrix_exp6(Slist_.col(i) * q(i));
  }
  return T * M_;
}

Eigen::Vector3d PoeKinematics::position(const JointVec& q) const {
  return forward_kinematics(q).block<3, 1>(0, 3);
}

Eigen::Matrix<double, 6, kNumJoints> PoeKinematics::jacobian_space(const JointVec& q) const {
  Eigen::Matrix<double, 6, kNumJoints> J;
  J.col(0) = Slist_.col(0);

  Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
  for (int i = 1; i < kNumJoints; ++i) {
    T = T * matrix_exp6(Slist_.col(i - 1) * q(i - 1));
    J.col(i) = adjoint(T) * Slist_.col(i);
  }
  return J;
}

Eigen::Matrix<double, 3, kNumJoints> PoeKinematics::position_jacobian(const JointVec& q) const {
  return jacobian_space(q).bottomRows<3>();
}

}  // namespace teleop_opcua_v2
