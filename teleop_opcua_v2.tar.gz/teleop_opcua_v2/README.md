# OPC UA Teleoperation for ViperX-300 with IK Control (v2)

Bidirectional OPC UA teleoperation system with **Cartesian end-effector control
via inverse kinematics** for the Interbotix ViperX-300 robotic arm.

## Architecture (v2 — with IK)

```
┌──────────┐      ┌───────────────┐      ┌─────────┐      ┌──────────┐      ┌────────────┐
│ Keyboard │─────>│ OPC UA        │─────>│Selector │─────>│ OPC UA   │─────>│ OPC UA ↔   │
│ (evdev)  │      │ Input Skill   │ 4840 │(priority│      │ IK       │ 4842 │ ROS 2      │
│          │      │ (Cartesian)   │      │+safety) │      │ Server   │      │ Bridge     │───> VX-300
└──────────┘      └───────────────┘      └─────────┘      └──────────┘      │            │
                                                                 ↑           │ cmd:4842   │
┌──────────┐      ┌───────────────┐                              │           │ fb :4843   │<─── /vx300/joint_states
│Dashboard │<─────│ Feedback OPC  │<─────────────────────────────┴───────────│            │
│          │ 4843 │ UA Server     │                                           └────────────┘
└──────────┘      └───────────────┘
```

### Data flow for one keypress (with SPACE held + W pressed):

1. Keyboard handler: W → `linear_vel[0] = +1.0`
2. Input server publishes `CartesianInputSkill` OPC UA vars on **port 4840**
3. Selector reads port 4840, applies deadman/safety, writes to **port 4844**
4. **IK server** (port 4844):
   - Reads current joints from feedback server (port 4843)
   - Reads Cartesian velocity from its own OPC UA vars
   - Integrates into a target pose: `T_target = exp([V] * dt) * T_target`
   - Runs Newton-Raphson IK with DLS pseudo-inverse + joint-limit null-space
   - Writes resulting joint velocities to bridge (**port 4842**) as `ArmInputSkill`
5. Bridge reads port 4842, converts to absolute positions, publishes to
   `/vx300/commands/joint_group` (Interbotix ROS 2 topic)
6. Arm moves; joint states stream back → port 4843 → dashboard + IK server

## Prerequisites

- Ubuntu 22.04 with ROS 2 Humble
- Interbotix X-Series SDK at `~/interbotix_ws` (you already have this)
- ViperX-300 connected via USB **or** simulated in Gazebo

## Build

```bash
# 1. Install deps (once)
chmod +x scripts/install_deps.sh
./scripts/install_deps.sh

# 2. Build
source /opt/ros/humble/setup.bash
source ~/interbotix_ws/install/setup.bash
mkdir -p build && cd build
cmake ..
make -j$(nproc)
```

## Run (6 terminals)

**Terminal 1 — Arm driver (or Gazebo sim):**
```bash
cd ~/interbotix_ws
source install/setup.bash
ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=vx300 use_rviz:=true
```

**Terminal 2 — Bridge:**
```bash
source /opt/ros/humble/setup.bash
source ~/interbotix_ws/install/setup.bash
cd build
./opcua_ros2_bridge ../configs/bridge.yaml
```

**Terminal 3 — IK Server:**
```bash
cd build
./ik_server ../configs/ik.yaml
```

**Terminal 4 — Input Skill Server (Cartesian keyboard):**
```bash
cd build
sudo ./input_skill_server ../configs/keyboard.yaml
```

**Terminal 5 — Selector:**
```bash
cd build
./selector_client ../configs/selector.yaml
```

**Terminal 6 — Feedback Dashboard:**
```bash
cd build
./feedback_receiver opc.tcp://localhost:4843
```

## Controls (Cartesian now!)

Hold **SPACE** (deadman) + use:

| Key | Action |
|-----|--------|
| W / S | End-effector +X / -X (forward/back) |
| A / D | End-effector +Y / -Y (left/right) |
| R / F | End-effector +Z / -Z (up/down) |
| ↑ / ↓ | Pitch up / down |
| ← / → | Yaw left / right |
| Q / E | Roll CW / CCW |
| O / C | Gripper open / close |
| SPACE | **Deadman** (must hold) |

## Verify the IK Math (no arm needed)

```bash
cd build
./test_ik
```

This runs a standalone round-trip sanity check:
- FK(θ) → T → IK(T) → θ′
- Reports position error and whether solver converged.

## IK Details

**Kinematics:** Product of Exponentials (PoE) from Modern Robotics (Kevin Lynch).
Matches Interbotix's own convention exactly.

**M matrix** (home):
```
[1 0 0 0.536494]
[0 1 0 0      ]
[0 0 1 0.42705]
[0 0 0 1      ]
```

**Slist** — 5 space-frame screw axes (waist, shoulder, elbow, wrist_angle, wrist_rotate).

**Solver:** Newton-Raphson iteration with:
- **Damped Least Squares** pseudo-inverse: `J⁺ = Jᵀ(JJᵀ + λ²I)⁻¹`
- **Joint-limit avoidance** via null-space projection: push joints toward the
  midpoint of their safe range whenever the primary task allows
- **Convergence:** position error < 1 mm, orientation error < 0.06°
- **Fallback:** if IK fails to converge, target pose resets to current pose
  (safe — arm holds still rather than making a wild jump)

## Tuning

In `configs/ik.yaml`:
- **`linear_vel_scale`** — max m/s of end-effector travel. Default 0.10 is slow/safe.
- **`angular_vel_scale`** — max rad/s of rotation.
- **`damping_lambda`** — bigger = more stable near singularities but slower.
- **`jl_weight`** — joint-limit avoidance strength.
- **`max_iterations`** — more = better convergence but more CPU per tick.

In `configs/bridge.yaml`:
- **`joint_velocity_scale`** — final cap on joint motion speed.

## Key Files

```
teleop_opcua/
├── configs/{keyboard,gamepad,selector,ik,bridge}.yaml
├── include/
│   ├── common/        # skill types, config, safety
│   ├── input/         # keyboard + gamepad handlers
│   ├── selector/      # priority + deadman logic
│   ├── ik/            # kinematics + IK solver (new!)
│   └── bridge/        # OPC UA ↔ ROS 2
├── src/
│   ├── common/...
│   ├── input/...
│   ├── selector/...
│   ├── ik/{kinematics.cpp, ik_solver.cpp}    # ← Eigen-based PoE math
│   ├── bridge/...
│   ├── input_skill_server.cpp       # publishes Cartesian skill
│   ├── selector_client.cpp
│   ├── ik_server.cpp                 # ← NEW: Cartesian → Joint IK
│   ├── opcua_ros2_bridge.cpp
│   ├── feedback_receiver.cpp
│   ├── test_opcua_client.cpp
│   └── test_ik.cpp                   # ← standalone IK sanity test
└── scripts/{install_deps, find_keyboard}.sh
```

## Safety

- **Deadman**: release SPACE → all velocities zeroed immediately
- **Stale timeout (200 ms)**: if no fresh stamp arrives, commands zero out
- **Joint-limit clamping**: every IK iteration clamps output to VX-300 safe range
- **DLS damping**: prevents wild joint motion near kinematic singularities
- **IK failure fallback**: rejected targets don't cause the arm to move

## Troubleshooting

- **"Cannot open /dev/input/eventN"** — run `./scripts/find_keyboard.sh` to find
  the right device, update `configs/keyboard.yaml`, run input server with `sudo`.
- **Arm drifts on startup** — expected: target pose initializes from current pose
  on first feedback. Should stabilize within a tick.
- **Arm jumps at singularity** — increase `damping_lambda` in `configs/ik.yaml`.
- **IK won't converge** — check `test_ik` output. If that works but real arm
  fails, current joint positions may be outside the reachable target.
