#pragma once

#include "common/skill_types.h"
#include "common/config_loader.h"
#include <open62541/server.h>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <interbotix_xs_msgs/msg/joint_group_command.hpp>
#include <interbotix_xs_msgs/msg/joint_single_command.hpp>
#include <mutex>
#include <atomic>
#include <chrono>

namespace teleop {

class CommandBridge {
public:
    CommandBridge(UA_Server *server, rclcpp::Node::SharedPtr node,
                  const BridgeConfig &config);

    // Update currently known joint positions (called by FeedbackBridge).
    void updatePositions(const float pos[5]);

    // Read latest joint velocity command from OPC UA and publish to ROS 2.
    void tick();

    bool isCommandFresh() const;

private:
    UA_Server *server_;
    rclcpp::Node::SharedPtr node_;
    BridgeConfig config_;

    rclcpp::Publisher<interbotix_xs_msgs::msg::JointGroupCommand>::SharedPtr arm_pub_;
    rclcpp::Publisher<interbotix_xs_msgs::msg::JointSingleCommand>::SharedPtr gripper_pub_;

    uint32_t last_stamp_ = 0;
    std::chrono::steady_clock::time_point last_cmd_time_;

    float current_positions_[5] = {0};
    std::mutex pos_mutex_;
};

class FeedbackBridge {
public:
    FeedbackBridge(UA_Server *server, rclcpp::Node::SharedPtr node,
                   const BridgeConfig &config,
                   CommandBridge *cmd_bridge);

    void tick();

private:
    void jointStateCallback(sensor_msgs::msg::JointState::SharedPtr msg);

    UA_Server *server_;
    rclcpp::Node::SharedPtr node_;
    BridgeConfig config_;
    CommandBridge *cmd_bridge_;

    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_sub_;

    std::mutex fb_mutex_;
    RobotFeedback latest_feedback_;
    std::atomic<uint32_t> heartbeat_{0};
};

} // namespace teleop
