#pragma once

#include <string>
#include <vector>
#include <map>
#include <cstdint>
#include <yaml-cpp/yaml.h>

namespace teleop {

// ─────────────────────────────────────────────
// Input config (keyboard / gamepad)
// ─────────────────────────────────────────────
struct KeyMapping {
    int key_code;
    int axis_index;      // 0=x,1=y,2=z,3=roll,4=pitch,5=yaw,6=gripper
    float direction;
};

struct AxisMapping {
    int axis_code;
    int axis_index;
    float scale;
    float deadzone;
    bool invert;
};

struct ButtonMapping {
    int button_code;
    int axis_index;
    float direction;
};

struct InputConfig {
    std::string device_type;
    std::string device_name;
    std::string evdev_path;
    uint16_t opcua_port = 4840;
    int publish_hz = 50;
    float max_velocity = 1.0f;
    float ramp_rate = 8.0f;

    std::vector<KeyMapping> key_mappings;
    int deadman_key = 0;

    std::vector<AxisMapping> axis_mappings;
    std::vector<ButtonMapping> button_mappings;
    int deadman_button = 0;
};

// ─────────────────────────────────────────────
// Selector config
// ─────────────────────────────────────────────
struct SelectorConfig {
    struct ProviderEntry {
        std::string name;
        std::string endpoint;
        int priority;
    };
    std::vector<ProviderEntry> providers;
    float deadman_timeout_ms = 200.0f;
    float stale_timeout_ms = 150.0f;
    std::string ik_endpoint = "opc.tcp://localhost:4844";
};

// ─────────────────────────────────────────────
// IK server config
// ─────────────────────────────────────────────
struct IKConfig {
    uint16_t opcua_port = 4844;       // IK server OPC UA port
    std::string feedback_endpoint = "opc.tcp://localhost:4843"; // to read current joints
    std::string bridge_endpoint = "opc.tcp://localhost:4842";   // to write joint commands

    // Cartesian velocity scaling (normalized [-1,1] * this = m/s or rad/s)
    float linear_vel_scale = 0.10f;   // 0.10 m/s max
    float angular_vel_scale = 0.50f;  // 0.50 rad/s max

    // IK numerical parameters
    int max_iterations = 30;
    double eps_pos = 1e-3;   // position tolerance
    double eps_ori = 1e-3;   // orientation tolerance
    double damping_lambda = 0.05;  // DLS damping factor
    double jl_weight = 1.0;         // joint-limit avoidance weight

    // Safety
    float command_timeout_ms = 200.0f;
};

// ─────────────────────────────────────────────
// Bridge config
// ─────────────────────────────────────────────
struct BridgeConfig {
    uint16_t opcua_command_port = 4842;
    uint16_t opcua_feedback_port = 4843;
    std::string ros_joint_group_topic = "/vx300/commands/joint_group";
    std::string ros_joint_single_topic = "/vx300/commands/joint_single";
    std::string ros_joint_states_topic = "/vx300/joint_states";
    std::string arm_group_name = "arm";
    std::string gripper_group_name = "gripper";
    float joint_velocity_scale = 0.8f;
    float gripper_pwm_scale = 200.0f;
    float command_timeout_ms = 200.0f;
};

// Loaders
InputConfig    loadInputConfig(const std::string &filepath);
SelectorConfig loadSelectorConfig(const std::string &filepath);
IKConfig       loadIKConfig(const std::string &filepath);
BridgeConfig   loadBridgeConfig(const std::string &filepath);

} // namespace teleop
