#pragma once

#include <chrono>
#include <atomic>
#include <mutex>

namespace teleop {

class SafetyMonitor {
public:
    SafetyMonitor(double timeout_ms);

    void markAlive();
    void setDeadman(bool pressed);
    bool shouldStop() const;
    double getElapsedMs() const;
    bool isDeadmanPressed() const { return deadman_pressed_.load(); }
    bool isStale() const;

private:
    double timeout_ms_;
    std::atomic<bool> deadman_pressed_{false};
    mutable std::chrono::steady_clock::time_point last_alive_;
    mutable std::mutex time_mutex_;
};

} // namespace teleop
