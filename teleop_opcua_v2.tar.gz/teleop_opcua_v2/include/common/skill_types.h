#pragma once

#include <open62541/server.h>
#include <open62541/client.h>
#include <string>
#include <vector>
#include <cstdint>
#include <atomic>
#include <mutex>

namespace teleop {

// ─────────────────────────────────────────────
// ViperX-300 joint info (5-DOF standard VX300)
// ─────────────────────────────────────────────
static const std::vector<std::string> VX300_ARM_JOINTS = {
    "waist", "shoulder", "elbow", "wrist_angle", "wrist_rotate"
};
static const int VX300_NUM_ARM_JOINTS = 5;

// Joint limits (radians) - from Trossen spec
struct JointLimits {
    double min;
    double max;
};
static const JointLimits VX300_JOINT_LIMITS[5] = {
    {-3.14159, 3.14159},  // waist: ±180°
    {-1.76278, 1.76278},  // shoulder: ±101°
    {-1.76278, 1.60570},  // elbow: -101° to +92°
    {-1.86750, 2.26893},  // wrist_angle: -107° to +130°
    {-3.14159, 3.14159}   // wrist_rotate: ±180°
};

// ─────────────────────────────────────────────
// CartesianInputSkill — new, used by IK flow
// ─────────────────────────────────────────────
struct CartesianInputCommand {
    float linear_vel[3]  = {0};   // dx, dy, dz (normalized [-1,1])
    float angular_vel[3] = {0};   // droll, dpitch, dyaw (normalized)
    float gripper_cmd    = 0.0f;
    bool  deadman        = false;
    uint32_t stamp       = 0;
};

// ─────────────────────────────────────────────
// ArmInputSkill — joint-level, used by bridge
// ─────────────────────────────────────────────
struct ArmInputCommand {
    float joint_velocities[5] = {0};
    float gripper_cmd = 0.0f;
    bool  deadman = false;
    uint32_t stamp = 0;
};

// ─────────────────────────────────────────────
// Robot feedback (from arm via bridge)
// ─────────────────────────────────────────────
struct RobotFeedback {
    float joint_positions[5] = {0};
    float joint_velocities_fb[5] = {0};
    float joint_efforts[5] = {0};
    float gripper_position = 0.0f;
    uint32_t heartbeat_counter = 0;
    bool fault_active = false;
    uint32_t fault_code = 0;
    bool driver_ready = false;
    uint64_t timestamp_ms = 0;
};

// ─────────────────────────────────────────────
// Skill states
// ─────────────────────────────────────────────
enum class SkillState : uint32_t {
    HALTED = 0, READY = 1, RUNNING = 2, SUSPENDED = 3, ERROR = 4
};

// ─────────────────────────────────────────────
// OPC UA node IDs
// ─────────────────────────────────────────────
namespace opcua_ids {
    static const uint16_t NS = 1;

    // ArmInput skill (joint-level): used by IK_server output and bridge input
    static const uint32_t JOINT_VEL_WAIST       = 1001;
    static const uint32_t JOINT_VEL_SHOULDER    = 1002;
    static const uint32_t JOINT_VEL_ELBOW       = 1003;
    static const uint32_t JOINT_VEL_WRIST_ANGLE = 1004;
    static const uint32_t JOINT_VEL_WRIST_ROT   = 1005;
    static const uint32_t GRIPPER_CMD           = 1006;
    static const uint32_t DEADMAN               = 1007;
    static const uint32_t STAMP                 = 1008;
    static const uint32_t SKILL_STATE           = 1010;

    // CartesianInput skill (Cartesian-level): used by input_server output and selector/IK input
    static const uint32_t CART_VEL_X         = 1101;
    static const uint32_t CART_VEL_Y         = 1102;
    static const uint32_t CART_VEL_Z         = 1103;
    static const uint32_t CART_VEL_ROLL      = 1104;
    static const uint32_t CART_VEL_PITCH     = 1105;
    static const uint32_t CART_VEL_YAW       = 1106;
    static const uint32_t CART_GRIPPER       = 1107;
    static const uint32_t CART_DEADMAN       = 1108;
    static const uint32_t CART_STAMP         = 1109;

    // Feedback nodes
    static const uint32_t FB_JOINT_POS_BASE  = 2001;
    static const uint32_t FB_JOINT_VEL_BASE  = 2011;
    static const uint32_t FB_JOINT_EFF_BASE  = 2021;
    static const uint32_t FB_GRIPPER_POS     = 2030;
    static const uint32_t FB_HEARTBEAT       = 2040;
    static const uint32_t FB_FAULT_ACTIVE    = 2041;
    static const uint32_t FB_FAULT_CODE      = 2042;
    static const uint32_t FB_DRIVER_READY    = 2043;
    static const uint32_t FB_TIMESTAMP       = 2044;

    // Object nodes
    static const uint32_t OBJ_SKILLS    = 100;
    static const uint32_t OBJ_ARM_INPUT = 101;
    static const uint32_t OBJ_CART_INPUT= 102;
    static const uint32_t OBJ_FEEDBACK  = 200;
    static const uint32_t OBJ_HEALTH    = 201;
}

// Node-adding helpers
UA_StatusCode addArmInputSkillNodes(UA_Server *server);
UA_StatusCode addCartesianInputSkillNodes(UA_Server *server);
UA_StatusCode addRobotFeedbackNodes(UA_Server *server);

} // namespace teleop
