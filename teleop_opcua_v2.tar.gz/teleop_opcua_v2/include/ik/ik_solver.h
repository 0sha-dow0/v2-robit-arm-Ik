#pragma once

#include "ik/kinematics.h"
#include <Eigen/Dense>

namespace teleop {
namespace ik {

struct IKParams {
    int    max_iterations = 30;
    double eps_pos        = 1e-3;   // position error tolerance (m)
    double eps_ori        = 1e-3;   // orientation error tolerance (rad)
    double damping_lambda = 0.05;   // DLS damping
    double jl_weight      = 1.0;    // null-space joint-limit avoidance weight
};

// Joint limits for the VX300 (lower, upper per joint).
struct JointLimitsEigen {
    Eigen::Matrix<double, NUM_JOINTS, 1> lower;
    Eigen::Matrix<double, NUM_JOINTS, 1> upper;

    // Build from the static VX300_JOINT_LIMITS array.
    static JointLimitsEigen vx300();
};

// ─────────────────────────────────────────────
// Inverse kinematics solver (Newton-Raphson + DLS + joint-limit null-space)
//
// Inputs:
//   T_target   - desired 4×4 SE(3) pose of end-effector
//   theta_init - current joint angles (seed)
//   params     - tuning
//   limits     - joint limits
//
// Outputs:
//   theta_out  - joint angles (clamped to limits)
//
// Returns true on convergence, false if max_iterations reached without convergence
// (theta_out will still contain the best-effort result).
// ─────────────────────────────────────────────
bool solveIK(
    const Eigen::Matrix4d &T_target,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &theta_init,
    const IKParams &params,
    const JointLimitsEigen &limits,
    Eigen::Matrix<double, NUM_JOINTS, 1> &theta_out
);

// ─────────────────────────────────────────────
// Integrate a Cartesian velocity into a new target pose.
// Useful for velocity-resolved teleop: integrate over dt, then IK to joints.
// Returns T_new = exp([V] * dt) * T_current  (space frame integration)
// ─────────────────────────────────────────────
Eigen::Matrix4d integrateTwist(
    const Eigen::Matrix4d &T_current,
    const Eigen::Matrix<double, 6, 1> &twist_space,
    double dt
);

// ─────────────────────────────────────────────
// Damped least-squares pseudo-inverse with joint-limit null-space projection.
// Used internally by solveIK, exposed for reuse.
// ─────────────────────────────────────────────
Eigen::Matrix<double, NUM_JOINTS, 1> dlsWithJLAvoidance(
    const Eigen::Matrix<double, 6, NUM_JOINTS> &J,
    const Eigen::Matrix<double, 6, 1> &V_err,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &theta,
    const JointLimitsEigen &limits,
    double damping_lambda,
    double jl_weight
);

} // namespace ik
} // namespace teleop
