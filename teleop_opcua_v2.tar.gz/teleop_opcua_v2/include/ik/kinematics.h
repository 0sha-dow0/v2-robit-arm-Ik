#pragma once

#include <Eigen/Dense>
#include <vector>

namespace teleop {
namespace ik {

// ─────────────────────────────────────────────
// ViperX-300 kinematic constants
// ─────────────────────────────────────────────
constexpr int NUM_JOINTS = 5;

// Returns the 4×4 home configuration M for the VX300.
Eigen::Matrix4d getM();

// Returns the 6×5 space-frame screw axis list Slist (each column is a screw).
Eigen::Matrix<double, 6, NUM_JOINTS> getSlist();

// ─────────────────────────────────────────────
// SE(3) / se(3) helpers (Modern Robotics formulations)
// ─────────────────────────────────────────────

// Convert 3-vector to its 3×3 skew-symmetric matrix (so(3) hat).
Eigen::Matrix3d vecToSo3(const Eigen::Vector3d &w);

// Extract 3-vector from 3×3 skew-symmetric matrix (so(3) vee).
Eigen::Vector3d so3ToVec(const Eigen::Matrix3d &W);

// Convert 6-vector twist to its 4×4 se(3) hat matrix.
Eigen::Matrix4d vecToSe3(const Eigen::Matrix<double, 6, 1> &V);

// Extract twist 6-vector from 4×4 se(3) matrix.
Eigen::Matrix<double, 6, 1> se3ToVec(const Eigen::Matrix4d &T);

// 3×3 rotation matrix exponential (Rodrigues).
Eigen::Matrix3d matrixExp3(const Eigen::Matrix3d &so3mat);

// 4×4 SE(3) matrix exponential.
Eigen::Matrix4d matrixExp6(const Eigen::Matrix4d &se3mat);

// 3×3 matrix log (rotation axis-angle extraction).
Eigen::Matrix3d matrixLog3(const Eigen::Matrix3d &R);

// 4×4 matrix log (SE(3) -> se(3)).
Eigen::Matrix4d matrixLog6(const Eigen::Matrix4d &T);

// SE(3) adjoint representation (6×6 matrix).
Eigen::Matrix<double, 6, 6> adjoint(const Eigen::Matrix4d &T);

// Invert an SE(3) matrix efficiently.
Eigen::Matrix4d trInv(const Eigen::Matrix4d &T);

// ─────────────────────────────────────────────
// Forward kinematics and Jacobian
// ─────────────────────────────────────────────

// Forward kinematics in space frame (Product of Exponentials).
// T(θ) = exp([S1]θ1) · exp([S2]θ2) · ... · exp([Sn]θn) · M
Eigen::Matrix4d fkInSpace(
    const Eigen::Matrix4d &M,
    const Eigen::Matrix<double, 6, NUM_JOINTS> &Slist,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &thetaList
);

// Space Jacobian (6 × NUM_JOINTS).
Eigen::Matrix<double, 6, NUM_JOINTS> jacobianSpace(
    const Eigen::Matrix<double, 6, NUM_JOINTS> &Slist,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &thetaList
);

} // namespace ik
} // namespace teleop
