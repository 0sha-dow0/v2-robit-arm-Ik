#pragma once

#include "input/keyboard_handler.h"

namespace teleop {

class GamepadHandler : public InputDeviceHandler {
public:
    explicit GamepadHandler(const InputConfig &config);
    ~GamepadHandler() override;

    bool start() override;
    void stop() override;
    CartesianInputCommand getCommand() override;
    bool isRunning() const override { return running_.load(); }

private:
    void readLoop();

    InputConfig config_;
    std::atomic<bool> running_{false};
    std::thread read_thread_;

    mutable std::mutex cmd_mutex_;
    CartesianInputCommand current_cmd_;
    std::atomic<uint32_t> stamp_counter_{0};

    int evdev_fd_ = -1;
    struct libevdev *evdev_ = nullptr;
};

} // namespace teleop
