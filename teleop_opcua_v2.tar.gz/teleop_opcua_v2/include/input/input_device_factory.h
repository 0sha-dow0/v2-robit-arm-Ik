#pragma once

#include "input/keyboard_handler.h"
#include "input/gamepad_handler.h"
#include "common/config_loader.h"
#include <memory>

namespace teleop {

std::unique_ptr<InputDeviceHandler> createInputDevice(const InputConfig &config);

} // namespace teleop
