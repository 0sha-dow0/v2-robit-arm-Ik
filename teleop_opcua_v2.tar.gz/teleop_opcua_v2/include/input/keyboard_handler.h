#pragma once

#include "common/config_loader.h"
#include "common/skill_types.h"
#include <libevdev/libevdev.h>
#include <linux/input.h>
#include <atomic>
#include <thread>
#include <mutex>
#include <map>

namespace teleop {

// ─────────────────────────────────────────────
// Abstract input device handler
// Produces CartesianInputCommand (new for IK flow)
// ─────────────────────────────────────────────
class InputDeviceHandler {
public:
    virtual ~InputDeviceHandler() = default;
    virtual bool start() = 0;
    virtual void stop() = 0;
    virtual CartesianInputCommand getCommand() = 0;
    virtual bool isRunning() const = 0;
};

// ─────────────────────────────────────────────
// Keyboard handler
// ─────────────────────────────────────────────
class KeyboardHandler : public InputDeviceHandler {
public:
    explicit KeyboardHandler(const InputConfig &config);
    ~KeyboardHandler() override;

    bool start() override;
    void stop() override;
    CartesianInputCommand getCommand() override;
    bool isRunning() const override { return running_.load(); }

private:
    void readLoop();
    void updateRamps(double dt);
    std::string findKeyboardDevice();

    InputConfig config_;
    std::atomic<bool> running_{false};
    std::thread read_thread_;

    std::map<int, bool> key_states_;
    float ramped_values_[7] = {0};  // x,y,z,roll,pitch,yaw,gripper

    mutable std::mutex cmd_mutex_;
    CartesianInputCommand current_cmd_;
    std::atomic<uint32_t> stamp_counter_{0};

    int evdev_fd_ = -1;
    struct libevdev *evdev_ = nullptr;
};

} // namespace teleop
