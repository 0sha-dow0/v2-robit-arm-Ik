#pragma once

#include "common/skill_types.h"
#include "common/config_loader.h"
#include "common/safety.h"
#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>
#include <string>
#include <vector>
#include <mutex>
#include <atomic>
#include <chrono>

namespace teleop {

struct ProviderState {
    std::string name;
    std::string endpoint;
    int priority;
    UA_Client *client = nullptr;
    bool connected = false;
    uint32_t last_stamp = 0;
    std::chrono::steady_clock::time_point last_update;
};

class SelectorLogic {
public:
    explicit SelectorLogic(const SelectorConfig &config);
    ~SelectorLogic();

    bool initialize();
    void tick();
    void shutdown();
    std::string getActiveProvider() const;

private:
    bool readProvider(ProviderState &prov, CartesianInputCommand &cmd);
    bool writeToIKServer(const CartesianInputCommand &cmd);
    int selectBestProvider();

    SelectorConfig config_;
    std::vector<ProviderState> providers_;

    UA_Client *ik_client_ = nullptr;
    bool ik_connected_ = false;

    int active_index_ = -1;
    mutable std::mutex mutex_;
    SafetyMonitor safety_;
};

} // namespace teleop
