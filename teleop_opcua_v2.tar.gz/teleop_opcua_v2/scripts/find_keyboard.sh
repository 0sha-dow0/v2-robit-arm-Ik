#!/bin/bash
# Find keyboard event device. Writes its path + key instructions to keyboard.yaml
echo "Listing input devices..."
echo ""
for dev in /dev/input/event*; do
    name=$(cat /sys/class/input/$(basename $dev)/device/name 2>/dev/null || echo "?")
    echo "  $dev -> $name"
done
echo ""
echo "Pick your keyboard (usually has 'Keyboard' in the name)"
echo "Update evdev_path in configs/keyboard.yaml accordingly."
echo ""
echo "To verify keys produce the right codes:"
echo "  sudo evtest /dev/input/eventN"
