#!/bin/bash
set -e

echo "═══════════════════════════════════════════"
echo "  Installing teleop_opcua v2 dependencies"
echo "═══════════════════════════════════════════"

# System
sudo apt update
sudo apt install -y \
    build-essential cmake git pkg-config \
    libyaml-cpp-dev libevdev-dev libeigen3-dev evtest

# open62541
OPEN62541_DIR="/tmp/open62541_build"
if [ ! -d "$OPEN62541_DIR" ]; then
    git clone --branch v1.3.9 --depth 1 \
        https://github.com/open62541/open62541.git "$OPEN62541_DIR"
fi
cd "$OPEN62541_DIR"
mkdir -p build && cd build
cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=ON \
    -DUA_ENABLE_SUBSCRIPTIONS=ON \
    -DUA_ENABLE_METHODCALLS=ON \
    -DUA_ENABLE_DISCOVERY=ON
make -j$(nproc)
sudo make install
sudo ldconfig

echo ""
echo "Done. Build with:"
echo "  source /opt/ros/humble/setup.bash"
echo "  source ~/interbotix_ws/install/setup.bash"
echo "  mkdir build && cd build && cmake .. && make -j\$(nproc)"
