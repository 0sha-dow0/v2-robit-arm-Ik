#include "bridge/bridge_node.h"
#include <cstdio>
#include <cstring>
#include <cmath>

namespace teleop {

static float readLocalFloat(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static bool readLocalBool(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(opcua_ids::NS, id), &v);
    bool r = false;
    if (v.type == &UA_TYPES[UA_TYPES_BOOLEAN]) r = *(UA_Boolean*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static uint32_t readLocalUInt32(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(opcua_ids::NS, id), &v);
    uint32_t r = 0;
    if (v.type == &UA_TYPES[UA_TYPES_UINT32]) r = *(UA_UInt32*)v.data;
    UA_Variant_clear(&v);
    return r;
}

CommandBridge::CommandBridge(UA_Server *server, rclcpp::Node::SharedPtr node,
                             const BridgeConfig &config)
    : server_(server), node_(node), config_(config) {
    arm_pub_ = node_->create_publisher<interbotix_xs_msgs::msg::JointGroupCommand>(
        config_.ros_joint_group_topic, 10);
    gripper_pub_ = node_->create_publisher<interbotix_xs_msgs::msg::JointSingleCommand>(
        config_.ros_joint_single_topic, 10);
    last_cmd_time_ = std::chrono::steady_clock::now();
    RCLCPP_INFO(node_->get_logger(),
        "CommandBridge: publishing to %s and %s",
        config_.ros_joint_group_topic.c_str(),
        config_.ros_joint_single_topic.c_str());
}

void CommandBridge::updatePositions(const float pos[5]) {
    std::lock_guard<std::mutex> lock(pos_mutex_);
    for (int i = 0; i < 5; i++) current_positions_[i] = pos[i];
}

void CommandBridge::tick() {
    float vels[5];
    vels[0] = readLocalFloat(server_, opcua_ids::JOINT_VEL_WAIST);
    vels[1] = readLocalFloat(server_, opcua_ids::JOINT_VEL_SHOULDER);
    vels[2] = readLocalFloat(server_, opcua_ids::JOINT_VEL_ELBOW);
    vels[3] = readLocalFloat(server_, opcua_ids::JOINT_VEL_WRIST_ANGLE);
    vels[4] = readLocalFloat(server_, opcua_ids::JOINT_VEL_WRIST_ROT);
    float gripper = readLocalFloat(server_, opcua_ids::GRIPPER_CMD);
    bool deadman = readLocalBool(server_, opcua_ids::DEADMAN);
    uint32_t stamp = readLocalUInt32(server_, opcua_ids::STAMP);

    if (stamp != last_stamp_) {
        last_stamp_ = stamp;
        last_cmd_time_ = std::chrono::steady_clock::now();
    }
    auto elapsed = std::chrono::duration<double, std::milli>(
        std::chrono::steady_clock::now() - last_cmd_time_).count();
    bool fresh = elapsed < config_.command_timeout_ms;

    if (!deadman || !fresh) {
        memset(vels, 0, sizeof(vels));
        gripper = 0.0f;
    }

    // Read current joint positions (cached from feedback bridge)
    float current_pos[5];
    {
        std::lock_guard<std::mutex> lock(pos_mutex_);
        for (int i = 0; i < 5; i++) current_pos[i] = current_positions_[i];
    }

    // Interbotix JointGroupCommand expects absolute positions.
    // Compute: new_pos = current_pos + vel * scale * dt
    float dt = 0.02f;  // 50 Hz
    bool has_motion = false;
    auto arm_msg = interbotix_xs_msgs::msg::JointGroupCommand();
    arm_msg.name = config_.arm_group_name;
    arm_msg.cmd.resize(5);
    for (int i = 0; i < 5; i++) {
        float delta = vels[i] * config_.joint_velocity_scale * dt;
        arm_msg.cmd[i] = current_pos[i] + delta;
        if (std::abs(delta) > 1e-6f) has_motion = true;
    }

    if (has_motion && deadman && fresh) {
        arm_pub_->publish(arm_msg);
    }

    if (std::abs(gripper) > 0.01f && deadman && fresh) {
        auto grip_msg = interbotix_xs_msgs::msg::JointSingleCommand();
        grip_msg.name = "gripper";
        grip_msg.cmd = gripper * config_.gripper_pwm_scale;
        gripper_pub_->publish(grip_msg);
    }
}

bool CommandBridge::isCommandFresh() const {
    auto elapsed = std::chrono::duration<double, std::milli>(
        std::chrono::steady_clock::now() - last_cmd_time_).count();
    return elapsed < config_.command_timeout_ms;
}

} // namespace teleop
