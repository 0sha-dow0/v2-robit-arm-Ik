#include "bridge/bridge_node.h"
#include <cstdio>
#include <chrono>

namespace teleop {

static void writeLocalFloat(UA_Server *s, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Server_writeValue(s, UA_NODEID_NUMERIC(opcua_ids::NS, id), val);
}
static void writeLocalBool(UA_Server *s, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Server_writeValue(s, UA_NODEID_NUMERIC(opcua_ids::NS, id), val);
}
static void writeLocalUInt32(UA_Server *s, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Server_writeValue(s, UA_NODEID_NUMERIC(opcua_ids::NS, id), val);
}
static void writeLocalUInt64(UA_Server *s, uint32_t id, uint64_t v) {
    UA_UInt64 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT64]);
    UA_Server_writeValue(s, UA_NODEID_NUMERIC(opcua_ids::NS, id), val);
}

FeedbackBridge::FeedbackBridge(UA_Server *server, rclcpp::Node::SharedPtr node,
                                const BridgeConfig &config,
                                CommandBridge *cmd_bridge)
    : server_(server), node_(node), config_(config), cmd_bridge_(cmd_bridge) {

    // Use lambda subscription (avoids std::bind signature issues on humble)
    auto cb = [this](sensor_msgs::msg::JointState::SharedPtr msg) {
        this->jointStateCallback(msg);
    };
    joint_sub_ = node_->create_subscription<sensor_msgs::msg::JointState>(
        config_.ros_joint_states_topic, 10, cb);

    RCLCPP_INFO(node_->get_logger(),
        "FeedbackBridge: subscribing to %s",
        config_.ros_joint_states_topic.c_str());
}

void FeedbackBridge::jointStateCallback(sensor_msgs::msg::JointState::SharedPtr msg) {
    std::lock_guard<std::mutex> lock(fb_mutex_);

    static const std::vector<std::string> target_joints = {
        "waist", "shoulder", "elbow", "wrist_angle", "wrist_rotate"
    };

    float pos_snapshot[5] = {0, 0, 0, 0, 0};

    for (size_t i = 0; i < msg->name.size(); i++) {
        for (int j = 0; j < 5; j++) {
            if (msg->name[i] == target_joints[j]) {
                if (i < msg->position.size())
                    latest_feedback_.joint_positions[j] = (float)msg->position[i];
                if (i < msg->velocity.size())
                    latest_feedback_.joint_velocities_fb[j] = (float)msg->velocity[i];
                if (i < msg->effort.size())
                    latest_feedback_.joint_efforts[j] = (float)msg->effort[i];
                pos_snapshot[j] = latest_feedback_.joint_positions[j];
            }
        }
        if (msg->name[i] == "left_finger" && i < msg->position.size()) {
            latest_feedback_.gripper_position = (float)msg->position[i];
        }
    }

    latest_feedback_.driver_ready = true;
    latest_feedback_.timestamp_ms =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();

    for (int j = 0; j < 5; j++) {
        writeLocalFloat(server_, opcua_ids::FB_JOINT_POS_BASE + j,
                        latest_feedback_.joint_positions[j]);
        writeLocalFloat(server_, opcua_ids::FB_JOINT_VEL_BASE + j,
                        latest_feedback_.joint_velocities_fb[j]);
        writeLocalFloat(server_, opcua_ids::FB_JOINT_EFF_BASE + j,
                        latest_feedback_.joint_efforts[j]);
    }
    writeLocalFloat(server_, opcua_ids::FB_GRIPPER_POS,
                    latest_feedback_.gripper_position);
    writeLocalBool(server_, opcua_ids::FB_DRIVER_READY,
                   latest_feedback_.driver_ready);
    writeLocalUInt64(server_, opcua_ids::FB_TIMESTAMP,
                     latest_feedback_.timestamp_ms);

    // Feed positions to command bridge so it can compute absolute position targets.
    if (cmd_bridge_) cmd_bridge_->updatePositions(pos_snapshot);
}

void FeedbackBridge::tick() {
    uint32_t hb = heartbeat_.fetch_add(1);
    writeLocalUInt32(server_, opcua_ids::FB_HEARTBEAT, hb);
}

} // namespace teleop
