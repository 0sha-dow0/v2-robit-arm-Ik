#include "common/config_loader.h"
#include <cstdio>

namespace teleop {

InputConfig loadInputConfig(const std::string &filepath) {
    InputConfig cfg;
    YAML::Node root = YAML::LoadFile(filepath);

    cfg.device_type = root["device_type"].as<std::string>("keyboard");
    cfg.device_name = root["device_name"].as<std::string>("Unknown Device");
    cfg.evdev_path  = root["evdev_path"].as<std::string>("");
    cfg.opcua_port  = root["opcua_port"].as<uint16_t>(4840);
    cfg.publish_hz  = root["publish_hz"].as<int>(50);
    cfg.max_velocity = root["max_velocity"].as<float>(1.0f);
    cfg.ramp_rate    = root["ramp_rate"].as<float>(8.0f);

    if (root["key_mappings"]) {
        for (const auto &entry : root["key_mappings"]) {
            KeyMapping km;
            km.key_code   = entry["key_code"].as<int>();
            km.axis_index = entry["axis_index"].as<int>();
            km.direction  = entry["direction"].as<float>(1.0f);
            cfg.key_mappings.push_back(km);
        }
    }
    cfg.deadman_key = root["deadman_key"].as<int>(0);

    if (root["axis_mappings"]) {
        for (const auto &entry : root["axis_mappings"]) {
            AxisMapping am;
            am.axis_code = entry["axis_code"].as<int>();
            am.axis_index = entry["axis_index"].as<int>();
            am.scale     = entry["scale"].as<float>(1.0f);
            am.deadzone  = entry["deadzone"].as<float>(0.05f);
            am.invert    = entry["invert"].as<bool>(false);
            cfg.axis_mappings.push_back(am);
        }
    }
    if (root["button_mappings"]) {
        for (const auto &entry : root["button_mappings"]) {
            ButtonMapping bm;
            bm.button_code = entry["button_code"].as<int>();
            bm.axis_index  = entry["axis_index"].as<int>();
            bm.direction   = entry["direction"].as<float>(1.0f);
            cfg.button_mappings.push_back(bm);
        }
    }
    cfg.deadman_button = root["deadman_button"].as<int>(0);

    printf("[Config] Loaded input config: %s (%s)\n",
           cfg.device_name.c_str(), cfg.device_type.c_str());
    return cfg;
}

SelectorConfig loadSelectorConfig(const std::string &filepath) {
    SelectorConfig cfg;
    YAML::Node root = YAML::LoadFile(filepath);

    if (root["providers"]) {
        for (const auto &entry : root["providers"]) {
            SelectorConfig::ProviderEntry pe;
            pe.name     = entry["name"].as<std::string>();
            pe.endpoint = entry["endpoint"].as<std::string>();
            pe.priority = entry["priority"].as<int>(0);
            cfg.providers.push_back(pe);
        }
    }
    cfg.deadman_timeout_ms = root["deadman_timeout_ms"].as<float>(200.0f);
    cfg.stale_timeout_ms   = root["stale_timeout_ms"].as<float>(150.0f);
    cfg.ik_endpoint        = root["ik_endpoint"].as<std::string>("opc.tcp://localhost:4844");

    printf("[Config] Loaded selector: %zu providers\n", cfg.providers.size());
    return cfg;
}

IKConfig loadIKConfig(const std::string &filepath) {
    IKConfig cfg;
    YAML::Node root = YAML::LoadFile(filepath);

    cfg.opcua_port = root["opcua_port"].as<uint16_t>(4844);
    cfg.feedback_endpoint = root["feedback_endpoint"].as<std::string>("opc.tcp://localhost:4843");
    cfg.bridge_endpoint   = root["bridge_endpoint"].as<std::string>("opc.tcp://localhost:4842");

    cfg.linear_vel_scale  = root["linear_vel_scale"].as<float>(0.10f);
    cfg.angular_vel_scale = root["angular_vel_scale"].as<float>(0.50f);

    cfg.max_iterations = root["max_iterations"].as<int>(30);
    cfg.eps_pos        = root["eps_pos"].as<double>(1e-3);
    cfg.eps_ori        = root["eps_ori"].as<double>(1e-3);
    cfg.damping_lambda = root["damping_lambda"].as<double>(0.05);
    cfg.jl_weight      = root["jl_weight"].as<double>(1.0);
    cfg.command_timeout_ms = root["command_timeout_ms"].as<float>(200.0f);

    printf("[Config] Loaded IK config: port=%d\n", cfg.opcua_port);
    return cfg;
}

BridgeConfig loadBridgeConfig(const std::string &filepath) {
    BridgeConfig cfg;
    YAML::Node root = YAML::LoadFile(filepath);

    cfg.opcua_command_port = root["opcua_command_port"].as<uint16_t>(4842);
    cfg.opcua_feedback_port = root["opcua_feedback_port"].as<uint16_t>(4843);

    cfg.ros_joint_group_topic = root["ros_joint_group_topic"].as<std::string>("/vx300/commands/joint_group");
    cfg.ros_joint_single_topic = root["ros_joint_single_topic"].as<std::string>("/vx300/commands/joint_single");
    cfg.ros_joint_states_topic = root["ros_joint_states_topic"].as<std::string>("/vx300/joint_states");

    cfg.arm_group_name = root["arm_group_name"].as<std::string>("arm");
    cfg.gripper_group_name = root["gripper_group_name"].as<std::string>("gripper");
    cfg.joint_velocity_scale = root["joint_velocity_scale"].as<float>(0.8f);
    cfg.gripper_pwm_scale    = root["gripper_pwm_scale"].as<float>(200.0f);
    cfg.command_timeout_ms   = root["command_timeout_ms"].as<float>(200.0f);

    printf("[Config] Loaded bridge: cmd_port=%d fb_port=%d\n",
           cfg.opcua_command_port, cfg.opcua_feedback_port);
    return cfg;
}

} // namespace teleop
