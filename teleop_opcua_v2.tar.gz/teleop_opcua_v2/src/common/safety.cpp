#include "common/safety.h"

namespace teleop {

SafetyMonitor::SafetyMonitor(double timeout_ms) : timeout_ms_(timeout_ms) {
    last_alive_ = std::chrono::steady_clock::now();
}

void SafetyMonitor::markAlive() {
    std::lock_guard<std::mutex> lock(time_mutex_);
    last_alive_ = std::chrono::steady_clock::now();
}

void SafetyMonitor::setDeadman(bool pressed) {
    deadman_pressed_.store(pressed);
}

bool SafetyMonitor::isStale() const {
    std::lock_guard<std::mutex> lock(time_mutex_);
    auto now = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double, std::milli>(now - last_alive_).count();
    return elapsed > timeout_ms_;
}

double SafetyMonitor::getElapsedMs() const {
    std::lock_guard<std::mutex> lock(time_mutex_);
    auto now = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::milli>(now - last_alive_).count();
}

bool SafetyMonitor::shouldStop() const {
    return !deadman_pressed_.load() || isStale();
}

} // namespace teleop
