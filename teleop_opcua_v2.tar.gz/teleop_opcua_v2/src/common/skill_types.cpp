#include "common/skill_types.h"
#include <open62541/server.h>
#include <cstdio>

namespace teleop {

static UA_StatusCode addFloatVariable(UA_Server *server, uint32_t id,
                                       const char *name, UA_NodeId parentId) {
    UA_VariableAttributes attr = UA_VariableAttributes_default;
    UA_Float val = 0.0f;
    UA_Variant_setScalar(&attr.value, &val, &UA_TYPES[UA_TYPES_FLOAT]);
    attr.displayName = UA_LOCALIZEDTEXT_ALLOC("en-US", name);
    attr.accessLevel = UA_ACCESSLEVELMASK_READ | UA_ACCESSLEVELMASK_WRITE;
    attr.dataType = UA_TYPES[UA_TYPES_FLOAT].typeId;

    UA_NodeId nodeId = UA_NODEID_NUMERIC(opcua_ids::NS, id);
    UA_QualifiedName qname = UA_QUALIFIEDNAME_ALLOC(opcua_ids::NS, name);

    UA_StatusCode status = UA_Server_addVariableNode(
        server, nodeId, parentId,
        UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES),
        qname, UA_NODEID_NUMERIC(0, UA_NS0ID_BASEDATAVARIABLETYPE),
        attr, NULL, NULL);

    UA_LocalizedText_clear(&attr.displayName);
    UA_QualifiedName_clear(&qname);
    return status;
}

static UA_StatusCode addBoolVariable(UA_Server *server, uint32_t id,
                                      const char *name, UA_NodeId parentId) {
    UA_VariableAttributes attr = UA_VariableAttributes_default;
    UA_Boolean val = false;
    UA_Variant_setScalar(&attr.value, &val, &UA_TYPES[UA_TYPES_BOOLEAN]);
    attr.displayName = UA_LOCALIZEDTEXT_ALLOC("en-US", name);
    attr.accessLevel = UA_ACCESSLEVELMASK_READ | UA_ACCESSLEVELMASK_WRITE;
    attr.dataType = UA_TYPES[UA_TYPES_BOOLEAN].typeId;

    UA_NodeId nodeId = UA_NODEID_NUMERIC(opcua_ids::NS, id);
    UA_QualifiedName qname = UA_QUALIFIEDNAME_ALLOC(opcua_ids::NS, name);

    UA_StatusCode status = UA_Server_addVariableNode(
        server, nodeId, parentId,
        UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES),
        qname, UA_NODEID_NUMERIC(0, UA_NS0ID_BASEDATAVARIABLETYPE),
        attr, NULL, NULL);

    UA_LocalizedText_clear(&attr.displayName);
    UA_QualifiedName_clear(&qname);
    return status;
}

static UA_StatusCode addUInt32Variable(UA_Server *server, uint32_t id,
                                        const char *name, UA_NodeId parentId) {
    UA_VariableAttributes attr = UA_VariableAttributes_default;
    UA_UInt32 val = 0;
    UA_Variant_setScalar(&attr.value, &val, &UA_TYPES[UA_TYPES_UINT32]);
    attr.displayName = UA_LOCALIZEDTEXT_ALLOC("en-US", name);
    attr.accessLevel = UA_ACCESSLEVELMASK_READ | UA_ACCESSLEVELMASK_WRITE;
    attr.dataType = UA_TYPES[UA_TYPES_UINT32].typeId;

    UA_NodeId nodeId = UA_NODEID_NUMERIC(opcua_ids::NS, id);
    UA_QualifiedName qname = UA_QUALIFIEDNAME_ALLOC(opcua_ids::NS, name);

    UA_StatusCode status = UA_Server_addVariableNode(
        server, nodeId, parentId,
        UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES),
        qname, UA_NODEID_NUMERIC(0, UA_NS0ID_BASEDATAVARIABLETYPE),
        attr, NULL, NULL);

    UA_LocalizedText_clear(&attr.displayName);
    UA_QualifiedName_clear(&qname);
    return status;
}

static UA_StatusCode addUInt64Variable(UA_Server *server, uint32_t id,
                                        const char *name, UA_NodeId parentId) {
    UA_VariableAttributes attr = UA_VariableAttributes_default;
    UA_UInt64 val = 0;
    UA_Variant_setScalar(&attr.value, &val, &UA_TYPES[UA_TYPES_UINT64]);
    attr.displayName = UA_LOCALIZEDTEXT_ALLOC("en-US", name);
    attr.accessLevel = UA_ACCESSLEVELMASK_READ | UA_ACCESSLEVELMASK_WRITE;
    attr.dataType = UA_TYPES[UA_TYPES_UINT64].typeId;

    UA_NodeId nodeId = UA_NODEID_NUMERIC(opcua_ids::NS, id);
    UA_QualifiedName qname = UA_QUALIFIEDNAME_ALLOC(opcua_ids::NS, name);

    UA_StatusCode status = UA_Server_addVariableNode(
        server, nodeId, parentId,
        UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES),
        qname, UA_NODEID_NUMERIC(0, UA_NS0ID_BASEDATAVARIABLETYPE),
        attr, NULL, NULL);

    UA_LocalizedText_clear(&attr.displayName);
    UA_QualifiedName_clear(&qname);
    return status;
}

static UA_StatusCode addObjectNode(UA_Server *server, uint32_t id,
                                    const char *name, UA_NodeId parentId) {
    UA_ObjectAttributes attr = UA_ObjectAttributes_default;
    attr.displayName = UA_LOCALIZEDTEXT_ALLOC("en-US", name);
    UA_NodeId nodeId = UA_NODEID_NUMERIC(opcua_ids::NS, id);
    UA_QualifiedName qname = UA_QUALIFIEDNAME_ALLOC(opcua_ids::NS, name);

    UA_StatusCode status = UA_Server_addObjectNode(
        server, nodeId, parentId,
        UA_NODEID_NUMERIC(0, UA_NS0ID_ORGANIZES),
        qname, UA_NODEID_NUMERIC(0, UA_NS0ID_BASEOBJECTTYPE),
        attr, NULL, NULL);

    UA_LocalizedText_clear(&attr.displayName);
    UA_QualifiedName_clear(&qname);
    return status;
}

// ─────────────────────────────────────────────
// ArmInputSkill (joint-level)
// ─────────────────────────────────────────────
UA_StatusCode addArmInputSkillNodes(UA_Server *server) {
    UA_NodeId objectsId = UA_NODEID_NUMERIC(0, UA_NS0ID_OBJECTSFOLDER);
    UA_StatusCode status = addObjectNode(server, opcua_ids::OBJ_SKILLS, "Skills", objectsId);
    if (status != UA_STATUSCODE_GOOD) return status;

    UA_NodeId skillsId = UA_NODEID_NUMERIC(opcua_ids::NS, opcua_ids::OBJ_SKILLS);
    status = addObjectNode(server, opcua_ids::OBJ_ARM_INPUT, "ArmInput", skillsId);
    if (status != UA_STATUSCODE_GOOD) return status;

    UA_NodeId armInputId = UA_NODEID_NUMERIC(opcua_ids::NS, opcua_ids::OBJ_ARM_INPUT);

    const char *names[] = {"VelWaist", "VelShoulder", "VelElbow",
                           "VelWristAngle", "VelWristRotate"};
    uint32_t ids[] = {
        opcua_ids::JOINT_VEL_WAIST, opcua_ids::JOINT_VEL_SHOULDER,
        opcua_ids::JOINT_VEL_ELBOW, opcua_ids::JOINT_VEL_WRIST_ANGLE,
        opcua_ids::JOINT_VEL_WRIST_ROT
    };
    for (int i = 0; i < 5; i++) {
        status = addFloatVariable(server, ids[i], names[i], armInputId);
        if (status != UA_STATUSCODE_GOOD) return status;
    }

    status = addFloatVariable(server, opcua_ids::GRIPPER_CMD, "GripperCmd", armInputId);
    if (status != UA_STATUSCODE_GOOD) return status;
    status = addBoolVariable(server, opcua_ids::DEADMAN, "Deadman", armInputId);
    if (status != UA_STATUSCODE_GOOD) return status;
    status = addUInt32Variable(server, opcua_ids::STAMP, "Stamp", armInputId);
    if (status != UA_STATUSCODE_GOOD) return status;
    status = addUInt32Variable(server, opcua_ids::SKILL_STATE, "SkillState", armInputId);
    if (status != UA_STATUSCODE_GOOD) return status;

    printf("[SkillTypes] ArmInputSkill nodes added\n");
    return UA_STATUSCODE_GOOD;
}

// ─────────────────────────────────────────────
// CartesianInputSkill (new)
// ─────────────────────────────────────────────
UA_StatusCode addCartesianInputSkillNodes(UA_Server *server) {
    UA_NodeId objectsId = UA_NODEID_NUMERIC(0, UA_NS0ID_OBJECTSFOLDER);

    // Add Skills object if not present yet
    UA_NodeId skillsId = UA_NODEID_NUMERIC(opcua_ids::NS, opcua_ids::OBJ_SKILLS);
    UA_NodeId existingTest;
    UA_NodeId_init(&existingTest);
    UA_BrowseDescription bd;
    UA_BrowseDescription_init(&bd);
    // Safe approach: try to add, ignore "already exists" errors
    addObjectNode(server, opcua_ids::OBJ_SKILLS, "Skills", objectsId);

    UA_StatusCode status = addObjectNode(server, opcua_ids::OBJ_CART_INPUT,
                                          "CartesianInput", skillsId);
    if (status != UA_STATUSCODE_GOOD) return status;

    UA_NodeId cartId = UA_NODEID_NUMERIC(opcua_ids::NS, opcua_ids::OBJ_CART_INPUT);

    const char *names[] = {"VelX", "VelY", "VelZ",
                           "VelRoll", "VelPitch", "VelYaw"};
    uint32_t ids[] = {
        opcua_ids::CART_VEL_X, opcua_ids::CART_VEL_Y, opcua_ids::CART_VEL_Z,
        opcua_ids::CART_VEL_ROLL, opcua_ids::CART_VEL_PITCH, opcua_ids::CART_VEL_YAW
    };
    for (int i = 0; i < 6; i++) {
        status = addFloatVariable(server, ids[i], names[i], cartId);
        if (status != UA_STATUSCODE_GOOD) return status;
    }
    status = addFloatVariable(server, opcua_ids::CART_GRIPPER, "GripperCmd", cartId);
    if (status != UA_STATUSCODE_GOOD) return status;
    status = addBoolVariable(server, opcua_ids::CART_DEADMAN, "Deadman", cartId);
    if (status != UA_STATUSCODE_GOOD) return status;
    status = addUInt32Variable(server, opcua_ids::CART_STAMP, "Stamp", cartId);
    if (status != UA_STATUSCODE_GOOD) return status;

    printf("[SkillTypes] CartesianInputSkill nodes added\n");
    return UA_STATUSCODE_GOOD;
}

// ─────────────────────────────────────────────
// Robot feedback
// ─────────────────────────────────────────────
UA_StatusCode addRobotFeedbackNodes(UA_Server *server) {
    UA_NodeId objectsId = UA_NODEID_NUMERIC(0, UA_NS0ID_OBJECTSFOLDER);
    UA_StatusCode status = addObjectNode(server, opcua_ids::OBJ_FEEDBACK, "Feedback", objectsId);
    if (status != UA_STATUSCODE_GOOD) return status;

    UA_NodeId feedbackId = UA_NODEID_NUMERIC(opcua_ids::NS, opcua_ids::OBJ_FEEDBACK);

    const char *pos_names[] = {"PosWaist", "PosShoulder", "PosElbow",
                                "PosWristAngle", "PosWristRotate"};
    for (int i = 0; i < 5; i++) {
        status = addFloatVariable(server, opcua_ids::FB_JOINT_POS_BASE + i,
                                   pos_names[i], feedbackId);
        if (status != UA_STATUSCODE_GOOD) return status;
    }

    const char *vel_names[] = {"VelFbWaist", "VelFbShoulder", "VelFbElbow",
                                "VelFbWristAngle", "VelFbWristRotate"};
    for (int i = 0; i < 5; i++) {
        status = addFloatVariable(server, opcua_ids::FB_JOINT_VEL_BASE + i,
                                   vel_names[i], feedbackId);
        if (status != UA_STATUSCODE_GOOD) return status;
    }

    const char *eff_names[] = {"EffWaist", "EffShoulder", "EffElbow",
                                "EffWristAngle", "EffWristRotate"};
    for (int i = 0; i < 5; i++) {
        status = addFloatVariable(server, opcua_ids::FB_JOINT_EFF_BASE + i,
                                   eff_names[i], feedbackId);
        if (status != UA_STATUSCODE_GOOD) return status;
    }

    status = addFloatVariable(server, opcua_ids::FB_GRIPPER_POS, "GripperPos", feedbackId);
    if (status != UA_STATUSCODE_GOOD) return status;

    status = addObjectNode(server, opcua_ids::OBJ_HEALTH, "Health", feedbackId);
    if (status != UA_STATUSCODE_GOOD) return status;

    UA_NodeId healthId = UA_NODEID_NUMERIC(opcua_ids::NS, opcua_ids::OBJ_HEALTH);
    addUInt32Variable(server, opcua_ids::FB_HEARTBEAT, "HeartbeatCounter", healthId);
    addBoolVariable(server, opcua_ids::FB_FAULT_ACTIVE, "FaultActive", healthId);
    addUInt32Variable(server, opcua_ids::FB_FAULT_CODE, "FaultCode", healthId);
    addBoolVariable(server, opcua_ids::FB_DRIVER_READY, "DriverReady", healthId);
    addUInt64Variable(server, opcua_ids::FB_TIMESTAMP, "Timestamp", healthId);

    printf("[SkillTypes] RobotFeedback nodes added\n");
    return UA_STATUSCODE_GOOD;
}

} // namespace teleop
