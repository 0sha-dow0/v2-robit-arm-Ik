#include "common/skill_types.h"

#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <unistd.h>
#include <algorithm>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

static float readFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static uint32_t readUInt32(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    uint32_t r = 0;
    if (v.type == &UA_TYPES[UA_TYPES_UINT32]) r = *(UA_UInt32*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static bool readBool(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    bool r = false;
    if (v.type == &UA_TYPES[UA_TYPES_BOOLEAN]) r = *(UA_Boolean*)v.data;
    UA_Variant_clear(&v);
    return r;
}

static void printBar(const char *label, float value, float mn, float mx) {
    int w = 30;
    float n = (value - mn) / (mx - mn);
    n = std::max(0.0f, std::min(1.0f, n));
    int fill = (int)(n * w);
    printf("  %-14s [", label);
    for (int i = 0; i < w; i++) printf("%c", i < fill ? '#' : '.');
    printf("] %+7.3f\n", value);
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    std::string endpoint = "opc.tcp://localhost:4843";
    if (argc > 1) endpoint = argv[1];

    printf("═══════════════════════════════════════════\n");
    printf("  Feedback Receiver / Dashboard\n");
    printf("  Endpoint: %s\n", endpoint.c_str());
    printf("═══════════════════════════════════════════\n");

    UA_Client *client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(client));
    if (UA_Client_connect(client, endpoint.c_str()) != UA_STATUSCODE_GOOD) {
        printf("ERROR: cannot connect\n");
        UA_Client_delete(client); return 1;
    }
    printf("Connected.\n\n");

    uint32_t last_hb = 0; int stale = 0;

    while (g_running) {
        float pos[5], vel[5], eff[5];
        for (int i = 0; i < 5; i++) {
            pos[i] = readFloat(client, teleop::opcua_ids::FB_JOINT_POS_BASE + i);
            vel[i] = readFloat(client, teleop::opcua_ids::FB_JOINT_VEL_BASE + i);
            eff[i] = readFloat(client, teleop::opcua_ids::FB_JOINT_EFF_BASE + i);
        }
        float grip = readFloat(client, teleop::opcua_ids::FB_GRIPPER_POS);
        uint32_t hb = readUInt32(client, teleop::opcua_ids::FB_HEARTBEAT);
        bool fault = readBool(client, teleop::opcua_ids::FB_FAULT_ACTIVE);
        bool ready = readBool(client, teleop::opcua_ids::FB_DRIVER_READY);

        if (hb == last_hb) stale++;
        else { stale = 0; last_hb = hb; }

        printf("\033[2J\033[H");
        printf("╔═══════════════════════════════════════════════════╗\n");
        printf("║        ROBOT FEEDBACK DASHBOARD                  ║\n");
        printf("╠═══════════════════════════════════════════════════╣\n");
        printf("║ JOINT POSITIONS (rad)                            ║\n");
        const char *names[] = {"Waist","Shoulder","Elbow","WristAngle","WristRotate"};
        for (int i = 0; i < 5; i++) printBar(names[i], pos[i], -3.14f, 3.14f);
        printf("║                                                   ║\n");
        printf("║ JOINT EFFORTS                                    ║\n");
        for (int i = 0; i < 5; i++) printf("  %-14s  %+7.1f\n", names[i], eff[i]);
        printf("║                                                   ║\n");
        printf("║ GRIPPER         %+7.4f                          ║\n", grip);
        printf("╠═══════════════════════════════════════════════════╣\n");
        printf("║ HEALTH                                           ║\n");
        printf("  Heartbeat:    %u\n", hb);
        printf("  Driver Ready: %s\n", ready ? "YES" : "NO");
        printf("  Fault Active: %s\n", fault ? "YES !!!" : "no");
        printf("  Stale:        %s\n", stale > 5 ? "WARNING" : "OK");
        printf("╚═══════════════════════════════════════════════════╝\n");
        printf("\n  Ctrl+C to exit\n");
        usleep(200000);
    }

    UA_Client_disconnect(client);
    UA_Client_delete(client);
    return 0;
}
