#include "ik/ik_solver.h"
#include "common/skill_types.h"
#include <cmath>
#include <algorithm>

namespace teleop {
namespace ik {

JointLimitsEigen JointLimitsEigen::vx300() {
    JointLimitsEigen jl;
    for (int i = 0; i < NUM_JOINTS; i++) {
        jl.lower(i) = VX300_JOINT_LIMITS[i].min;
        jl.upper(i) = VX300_JOINT_LIMITS[i].max;
    }
    return jl;
}

// ─────────────────────────────────────────────
// Joint-limit avoidance gradient (H-function method).
// Returns a vector of joint "velocities" that push each joint toward
// the middle of its range, weighted by how close it is to a limit.
// ─────────────────────────────────────────────
static Eigen::Matrix<double, NUM_JOINTS, 1> jointLimitGradient(
    const Eigen::Matrix<double, NUM_JOINTS, 1> &theta,
    const JointLimitsEigen &limits)
{
    Eigen::Matrix<double, NUM_JOINTS, 1> grad;
    for (int i = 0; i < NUM_JOINTS; i++) {
        double mid = 0.5 * (limits.lower(i) + limits.upper(i));
        double range = limits.upper(i) - limits.lower(i);
        // Gradient pushes toward midpoint; scales quadratically near limits.
        grad(i) = -(theta(i) - mid) / (0.5 * range);
    }
    return grad;
}

// ─────────────────────────────────────────────
// Damped least-squares pseudo-inverse with joint-limit null-space
// ─────────────────────────────────────────────
Eigen::Matrix<double, NUM_JOINTS, 1> dlsWithJLAvoidance(
    const Eigen::Matrix<double, 6, NUM_JOINTS> &J,
    const Eigen::Matrix<double, 6, 1> &V_err,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &theta,
    const JointLimitsEigen &limits,
    double damping_lambda,
    double jl_weight)
{
    // J⁺ = Jᵀ (J Jᵀ + λ² I)⁻¹
    Eigen::Matrix<double, 6, 6> JJt = J * J.transpose();
    Eigen::Matrix<double, 6, 6> damped = JJt + (damping_lambda * damping_lambda)
                                       * Eigen::Matrix<double, 6, 6>::Identity();
    Eigen::Matrix<double, NUM_JOINTS, 6> J_pinv = J.transpose() * damped.inverse();

    // Primary: reach target pose.
    Eigen::Matrix<double, NUM_JOINTS, 1> dtheta_primary = J_pinv * V_err;

    // Secondary: joint-limit avoidance in the null space of J.
    //   dtheta = J⁺ V + (I - J⁺ J) · q_dot_jl
    Eigen::Matrix<double, NUM_JOINTS, NUM_JOINTS> I =
        Eigen::Matrix<double, NUM_JOINTS, NUM_JOINTS>::Identity();
    Eigen::Matrix<double, NUM_JOINTS, NUM_JOINTS> nullProj = I - J_pinv * J;
    Eigen::Matrix<double, NUM_JOINTS, 1> q_dot_jl =
        jl_weight * jointLimitGradient(theta, limits);
    Eigen::Matrix<double, NUM_JOINTS, 1> dtheta_secondary = nullProj * q_dot_jl;

    return dtheta_primary + dtheta_secondary;
}

// ─────────────────────────────────────────────
// Main IK solver (Newton-Raphson)
// ─────────────────────────────────────────────
bool solveIK(
    const Eigen::Matrix4d &T_target,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &theta_init,
    const IKParams &params,
    const JointLimitsEigen &limits,
    Eigen::Matrix<double, NUM_JOINTS, 1> &theta_out)
{
    const Eigen::Matrix4d M = getM();
    const Eigen::Matrix<double, 6, NUM_JOINTS> Slist = getSlist();

    Eigen::Matrix<double, NUM_JOINTS, 1> theta = theta_init;

    for (int iter = 0; iter < params.max_iterations; iter++) {
        // 1) Forward kinematics
        Eigen::Matrix4d T_sb = fkInSpace(M, Slist, theta);

        // 2) Error twist in space frame: V_s = Ad_T_sb * [log(T_sb⁻¹ T_sd)]_vec
        Eigen::Matrix4d T_bd = trInv(T_sb) * T_target;
        Eigen::Matrix<double, 6, 1> V_b = se3ToVec(matrixLog6(T_bd));
        Eigen::Matrix<double, 6, 1> V_s = adjoint(T_sb) * V_b;

        // 3) Check convergence
        double w_err = V_s.head<3>().norm();
        double v_err = V_s.tail<3>().norm();
        if (w_err < params.eps_ori && v_err < params.eps_pos) {
            theta_out = theta;
            // Clamp to joint limits just in case
            for (int i = 0; i < NUM_JOINTS; i++) {
                theta_out(i) = std::max(limits.lower(i),
                                         std::min(limits.upper(i), theta_out(i)));
            }
            return true;
        }

        // 4) Compute Jacobian and solve for delta theta
        Eigen::Matrix<double, 6, NUM_JOINTS> Js = jacobianSpace(Slist, theta);
        Eigen::Matrix<double, NUM_JOINTS, 1> dtheta =
            dlsWithJLAvoidance(Js, V_s, theta, limits,
                               params.damping_lambda, params.jl_weight);

        // 5) Update theta
        theta += dtheta;

        // 6) Clamp to limits (hard clamp each iteration)
        for (int i = 0; i < NUM_JOINTS; i++) {
            theta(i) = std::max(limits.lower(i),
                                std::min(limits.upper(i), theta(i)));
        }
    }

    theta_out = theta;  // best-effort result
    return false;
}

// ─────────────────────────────────────────────
// Integrate a spatial twist into an SE(3) pose over dt.
// ─────────────────────────────────────────────
Eigen::Matrix4d integrateTwist(
    const Eigen::Matrix4d &T_current,
    const Eigen::Matrix<double, 6, 1> &twist_space,
    double dt)
{
    // T_new = exp([V_s] * dt) * T_current
    Eigen::Matrix<double, 6, 1> V_dt = twist_space * dt;
    return matrixExp6(vecToSe3(V_dt)) * T_current;
}

} // namespace ik
} // namespace teleop
