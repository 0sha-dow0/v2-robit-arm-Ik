#include "ik/kinematics.h"
#include <cmath>

namespace teleop {
namespace ik {

Eigen::Matrix4d getM() {
    Eigen::Matrix4d M = Eigen::Matrix4d::Identity();
    M(0, 3) = 0.536494;
    M(2, 3) = 0.42705;
    return M;
}

Eigen::Matrix<double, 6, NUM_JOINTS> getSlist() {
    // Each column is a screw axis: [omega; v] for a joint.
    Eigen::Matrix<double, 6, NUM_JOINTS> S;
    //        j1       j2         j3          j4          j5
    S <<  0.0,     0.0,       0.0,        0.0,        1.0,     // omega_x
          0.0,     1.0,       1.0,        1.0,        0.0,     // omega_y
          1.0,     0.0,       0.0,        0.0,        0.0,     // omega_z
          0.0,    -0.12705,  -0.42705,   -0.42705,    0.0,     // v_x
          0.0,     0.0,       0.0,        0.0,        0.42705, // v_y
          0.0,     0.0,       0.05955,    0.35955,    0.0;     // v_z
    return S;
}

// ─────────────────────────────────────────────
// SE(3) / se(3) helpers
// ─────────────────────────────────────────────
Eigen::Matrix3d vecToSo3(const Eigen::Vector3d &w) {
    Eigen::Matrix3d W;
    W <<   0.0, -w(2),  w(1),
          w(2),   0.0, -w(0),
         -w(1),  w(0),   0.0;
    return W;
}

Eigen::Vector3d so3ToVec(const Eigen::Matrix3d &W) {
    return Eigen::Vector3d(W(2, 1), W(0, 2), W(1, 0));
}

Eigen::Matrix4d vecToSe3(const Eigen::Matrix<double, 6, 1> &V) {
    Eigen::Matrix4d se3 = Eigen::Matrix4d::Zero();
    se3.block<3, 3>(0, 0) = vecToSo3(V.head<3>());
    se3.block<3, 1>(0, 3) = V.tail<3>();
    return se3;
}

Eigen::Matrix<double, 6, 1> se3ToVec(const Eigen::Matrix4d &T) {
    Eigen::Matrix<double, 6, 1> V;
    V.head<3>() = so3ToVec(T.block<3, 3>(0, 0));
    V.tail<3>() = T.block<3, 1>(0, 3);
    return V;
}

Eigen::Matrix3d matrixExp3(const Eigen::Matrix3d &so3mat) {
    Eigen::Vector3d omgtheta = so3ToVec(so3mat);
    double theta = omgtheta.norm();
    if (theta < 1e-6) {
        return Eigen::Matrix3d::Identity();
    }
    Eigen::Matrix3d omgmat = so3mat / theta;
    return Eigen::Matrix3d::Identity()
         + std::sin(theta) * omgmat
         + (1.0 - std::cos(theta)) * omgmat * omgmat;
}

Eigen::Matrix4d matrixExp6(const Eigen::Matrix4d &se3mat) {
    Eigen::Matrix3d omgmat = se3mat.block<3, 3>(0, 0);
    Eigen::Vector3d v      = se3mat.block<3, 1>(0, 3);
    Eigen::Vector3d omgvec = so3ToVec(omgmat);
    double theta = omgvec.norm();

    Eigen::Matrix4d result = Eigen::Matrix4d::Identity();

    if (theta < 1e-6) {
        // Pure translation
        result.block<3, 3>(0, 0) = Eigen::Matrix3d::Identity();
        result.block<3, 1>(0, 3) = v;
        return result;
    }

    Eigen::Matrix3d omgmat_normalized = omgmat / theta;
    Eigen::Matrix3d R = Eigen::Matrix3d::Identity()
                      + std::sin(theta) * omgmat_normalized
                      + (1.0 - std::cos(theta)) * omgmat_normalized * omgmat_normalized;
    Eigen::Matrix3d G = Eigen::Matrix3d::Identity() * theta
                      + (1.0 - std::cos(theta)) * omgmat_normalized
                      + (theta - std::sin(theta)) * omgmat_normalized * omgmat_normalized;

    result.block<3, 3>(0, 0) = R;
    result.block<3, 1>(0, 3) = G * (v / theta);
    return result;
}

Eigen::Matrix3d matrixLog3(const Eigen::Matrix3d &R) {
    double acosinput = (R.trace() - 1.0) / 2.0;
    Eigen::Matrix3d so3mat = Eigen::Matrix3d::Zero();

    if (acosinput >= 1.0) {
        return so3mat;  // R is identity → zero rotation
    } else if (acosinput <= -1.0) {
        Eigen::Vector3d omg;
        if (std::abs(1.0 + R(2, 2)) > 1e-6) {
            omg = (1.0 / std::sqrt(2.0 * (1.0 + R(2, 2))))
                * Eigen::Vector3d(R(0, 2), R(1, 2), 1.0 + R(2, 2));
        } else if (std::abs(1.0 + R(1, 1)) > 1e-6) {
            omg = (1.0 / std::sqrt(2.0 * (1.0 + R(1, 1))))
                * Eigen::Vector3d(R(0, 1), 1.0 + R(1, 1), R(2, 1));
        } else {
            omg = (1.0 / std::sqrt(2.0 * (1.0 + R(0, 0))))
                * Eigen::Vector3d(1.0 + R(0, 0), R(1, 0), R(2, 0));
        }
        return vecToSo3(M_PI * omg);
    } else {
        double theta = std::acos(acosinput);
        so3mat = theta / (2.0 * std::sin(theta)) * (R - R.transpose());
        return so3mat;
    }
}

Eigen::Matrix4d matrixLog6(const Eigen::Matrix4d &T) {
    Eigen::Matrix3d R = T.block<3, 3>(0, 0);
    Eigen::Vector3d p = T.block<3, 1>(0, 3);
    Eigen::Matrix4d result = Eigen::Matrix4d::Zero();
    Eigen::Matrix3d omgmat = matrixLog3(R);

    if (omgmat.isZero(1e-9)) {
        result.block<3, 3>(0, 0) = Eigen::Matrix3d::Zero();
        result.block<3, 1>(0, 3) = p;
        return result;
    }

    double theta = std::acos(std::min(std::max((R.trace() - 1.0) / 2.0, -1.0), 1.0));
    Eigen::Matrix3d Ginv =
        Eigen::Matrix3d::Identity() / theta
      - 0.5 * omgmat / theta
      + (1.0 / theta - 0.5 / std::tan(theta / 2.0))
        * (omgmat / theta) * (omgmat / theta);

    result.block<3, 3>(0, 0) = omgmat;
    result.block<3, 1>(0, 3) = Ginv * p * theta;
    return result;
}

Eigen::Matrix<double, 6, 6> adjoint(const Eigen::Matrix4d &T) {
    Eigen::Matrix<double, 6, 6> AdT = Eigen::Matrix<double, 6, 6>::Zero();
    Eigen::Matrix3d R = T.block<3, 3>(0, 0);
    Eigen::Vector3d p = T.block<3, 1>(0, 3);
    AdT.block<3, 3>(0, 0) = R;
    AdT.block<3, 3>(3, 0) = vecToSo3(p) * R;
    AdT.block<3, 3>(3, 3) = R;
    return AdT;
}

Eigen::Matrix4d trInv(const Eigen::Matrix4d &T) {
    Eigen::Matrix3d R = T.block<3, 3>(0, 0);
    Eigen::Vector3d p = T.block<3, 1>(0, 3);
    Eigen::Matrix4d Tinv = Eigen::Matrix4d::Identity();
    Tinv.block<3, 3>(0, 0) = R.transpose();
    Tinv.block<3, 1>(0, 3) = -R.transpose() * p;
    return Tinv;
}

// ─────────────────────────────────────────────
// Forward kinematics (PoE)
// ─────────────────────────────────────────────
Eigen::Matrix4d fkInSpace(
    const Eigen::Matrix4d &M,
    const Eigen::Matrix<double, 6, NUM_JOINTS> &Slist,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &thetaList)
{
    Eigen::Matrix4d T = M;
    // Apply exponentials in reverse (PoE: exp(S1*θ1) * exp(S2*θ2) * ... * M)
    for (int i = NUM_JOINTS - 1; i >= 0; i--) {
        Eigen::Matrix<double, 6, 1> S = Slist.col(i);
        T = matrixExp6(vecToSe3(S * thetaList(i))) * T;
    }
    return T;
}

// ─────────────────────────────────────────────
// Space Jacobian
// ─────────────────────────────────────────────
Eigen::Matrix<double, 6, NUM_JOINTS> jacobianSpace(
    const Eigen::Matrix<double, 6, NUM_JOINTS> &Slist,
    const Eigen::Matrix<double, NUM_JOINTS, 1> &thetaList)
{
    Eigen::Matrix<double, 6, NUM_JOINTS> Js;
    Js.col(0) = Slist.col(0);
    Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
    for (int i = 1; i < NUM_JOINTS; i++) {
        Eigen::Matrix<double, 6, 1> S_prev = Slist.col(i - 1);
        T = T * matrixExp6(vecToSe3(S_prev * thetaList(i - 1)));
        Js.col(i) = adjoint(T) * Slist.col(i);
    }
    return Js;
}

} // namespace ik
} // namespace teleop
