#include "common/skill_types.h"
#include "common/config_loader.h"
#include "common/safety.h"
#include "ik/ik_solver.h"
#include "ik/kinematics.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <cstring>
#include <chrono>
#include <unistd.h>
#include <Eigen/Dense>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

// ── OPC UA server-side I/O helpers ──
static float readLocalFloat(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static bool readLocalBool(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    bool r = false;
    if (v.type == &UA_TYPES[UA_TYPES_BOOLEAN]) r = *(UA_Boolean*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static uint32_t readLocalUInt32(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    uint32_t r = 0;
    if (v.type == &UA_TYPES[UA_TYPES_UINT32]) r = *(UA_UInt32*)v.data;
    UA_Variant_clear(&v);
    return r;
}

// ── OPC UA client-side I/O helpers ──
static float clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static void clientWriteFloat(UA_Client *c, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteBool(UA_Client *c, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteUInt32(UA_Client *c, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    std::string config_path = "configs/ik.yaml";
    if (argc > 1) config_path = argv[1];

    printf("═══════════════════════════════════════════\n");
    printf("  OPC UA IK Server (Cartesian → Joint)\n");
    printf("  Config: %s\n", config_path.c_str());
    printf("═══════════════════════════════════════════\n");

    teleop::IKConfig config;
    try { config = teleop::loadIKConfig(config_path); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    // ── Create OPC UA server (for selector to write Cartesian input into) ──
    UA_Server *server = UA_Server_new();
    UA_ServerConfig *sc = UA_Server_getConfig(server);
    UA_ServerConfig_setMinimal(sc, config.opcua_port, NULL);
    sc->applicationDescription.applicationName =
        UA_LOCALIZEDTEXT_ALLOC("en-US", "IKServer");

    if (teleop::addCartesianInputSkillNodes(server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: add Cartesian skill nodes failed\n");
        UA_Server_delete(server); return 1;
    }

    if (UA_Server_run_startup(server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: server startup failed\n");
        UA_Server_delete(server); return 1;
    }
    printf("[IK] Cartesian-input OPC UA server on port %d\n", config.opcua_port);

    // ── Clients to feedback server (read current joints) and bridge (write commands) ──
    UA_Client *fb_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(fb_client));
    bool fb_connected = false;

    UA_Client *bridge_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(bridge_client));
    bool bridge_connected = false;

    printf("[IK] Will connect feedback client on first tick...\n");
    printf("[IK] Will connect bridge client on first tick...\n");

    // ── IK params ──
    teleop::ik::IKParams ik_params;
    ik_params.max_iterations = config.max_iterations;
    ik_params.eps_pos = config.eps_pos;
    ik_params.eps_ori = config.eps_ori;
    ik_params.damping_lambda = config.damping_lambda;
    ik_params.jl_weight = config.jl_weight;
    auto limits = teleop::ik::JointLimitsEigen::vx300();

    // ── State ──
    Eigen::Matrix<double, 5, 1> current_joints; current_joints.setZero();
    Eigen::Matrix<double, 5, 1> target_joints;  target_joints.setZero();
    Eigen::Matrix4d T_target;  // integrated target pose
    bool have_initial_pose = false;

    uint32_t last_stamp = 0;
    auto last_cmd_time = std::chrono::steady_clock::now();

    printf("[IK] Running at 50 Hz. Ctrl+C to stop.\n\n");
    int period_us = 20000;
    uint32_t loop_count = 0;

    while (g_running) {
        UA_Server_run_iterate(server, false);

        // Lazy-connect feedback client
        if (!fb_connected) {
            if (UA_Client_connect(fb_client, config.feedback_endpoint.c_str())
                == UA_STATUSCODE_GOOD) {
                fb_connected = true;
                printf("[IK] Connected to feedback server %s\n",
                       config.feedback_endpoint.c_str());
            }
        }
        // Lazy-connect bridge client
        if (!bridge_connected) {
            if (UA_Client_connect(bridge_client, config.bridge_endpoint.c_str())
                == UA_STATUSCODE_GOOD) {
                bridge_connected = true;
                printf("[IK] Connected to bridge %s\n", config.bridge_endpoint.c_str());
            }
        }

        // ── Read current joint positions from feedback server ──
        if (fb_connected) {
            for (int i = 0; i < 5; i++) {
                current_joints(i) = (double)clientReadFloat(fb_client,
                    teleop::opcua_ids::FB_JOINT_POS_BASE + i);
            }
        }

        // ── Read Cartesian command from our own server ──
        teleop::CartesianInputCommand cmd;
        cmd.linear_vel[0]  = readLocalFloat(server, teleop::opcua_ids::CART_VEL_X);
        cmd.linear_vel[1]  = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Y);
        cmd.linear_vel[2]  = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Z);
        cmd.angular_vel[0] = readLocalFloat(server, teleop::opcua_ids::CART_VEL_ROLL);
        cmd.angular_vel[1] = readLocalFloat(server, teleop::opcua_ids::CART_VEL_PITCH);
        cmd.angular_vel[2] = readLocalFloat(server, teleop::opcua_ids::CART_VEL_YAW);
        cmd.gripper_cmd    = readLocalFloat(server, teleop::opcua_ids::CART_GRIPPER);
        cmd.deadman        = readLocalBool(server, teleop::opcua_ids::CART_DEADMAN);
        cmd.stamp          = readLocalUInt32(server, teleop::opcua_ids::CART_STAMP);

        if (cmd.stamp != last_stamp) {
            last_stamp = cmd.stamp;
            last_cmd_time = std::chrono::steady_clock::now();
        }
        auto elapsed_ms = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - last_cmd_time).count();
        bool fresh = elapsed_ms < config.command_timeout_ms;

        // ── Initialize target pose on first valid feedback ──
        if (!have_initial_pose && fb_connected) {
            T_target = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
            have_initial_pose = true;
            target_joints = current_joints;
            printf("[IK] Initial target pose set from current joints.\n");
        }

        // ── Build spatial twist from Cartesian command ──
        Eigen::Matrix<double, 6, 1> V_space;
        V_space.setZero();
        if (cmd.deadman && fresh && have_initial_pose) {
            V_space(0) = cmd.angular_vel[0] * config.angular_vel_scale;
            V_space(1) = cmd.angular_vel[1] * config.angular_vel_scale;
            V_space(2) = cmd.angular_vel[2] * config.angular_vel_scale;
            V_space(3) = cmd.linear_vel[0]  * config.linear_vel_scale;
            V_space(4) = cmd.linear_vel[1]  * config.linear_vel_scale;
            V_space(5) = cmd.linear_vel[2]  * config.linear_vel_scale;
        }

        // ── Integrate the twist into the target pose ──
        double dt = 0.02;  // 50 Hz
        if (have_initial_pose && V_space.norm() > 1e-9) {
            T_target = teleop::ik::integrateTwist(T_target, V_space, dt);
        }

        // ── Solve IK if we have a target ──
        Eigen::Matrix<double, 5, 1> new_joints = current_joints;
        bool ik_ok = false;
        if (have_initial_pose && cmd.deadman && fresh) {
            ik_ok = teleop::ik::solveIK(T_target, current_joints,
                                         ik_params, limits, new_joints);
            if (!ik_ok) {
                // Failed to converge — reset target to current pose (reject bad target)
                T_target = teleop::ik::fkInSpace(
                    teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
                new_joints = current_joints;
            }
        }

        // ── Compute velocity commands: (new_joints - current_joints) / dt ──
        // Then normalize to [-1,1] for the bridge's joint_velocity_scale
        //   The bridge multiplies by its own scale again; we send raw rad/s
        //   normalized by an assumed max velocity.
        const float BRIDGE_MAX_RAD_S = 1.0f; // must match bridge.yaml's expectation
        float joint_vels_normalized[5];
        for (int i = 0; i < 5; i++) {
            double raw_vel = (new_joints(i) - current_joints(i)) / dt;
            float n = (float)(raw_vel / BRIDGE_MAX_RAD_S);
            if (n > 1.0f) n = 1.0f;
            if (n < -1.0f) n = -1.0f;
            joint_vels_normalized[i] = n;
        }

        // ── Write to bridge as ArmInput skill ──
        if (bridge_connected) {
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WAIST,
                             joint_vels_normalized[0]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_SHOULDER,
                             joint_vels_normalized[1]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_ELBOW,
                             joint_vels_normalized[2]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ANGLE,
                             joint_vels_normalized[3]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ROT,
                             joint_vels_normalized[4]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::GRIPPER_CMD,
                             cmd.gripper_cmd);
            clientWriteBool(bridge_client, teleop::opcua_ids::DEADMAN,
                            cmd.deadman && fresh);
            clientWriteUInt32(bridge_client, teleop::opcua_ids::STAMP, cmd.stamp);
        }

        if (++loop_count % 100 == 0) {
            Eigen::Vector3d p = T_target.block<3,1>(0,3);
            printf("[IK] target=(%.3f,%.3f,%.3f) ik_ok=%d dm=%d fresh=%d\n",
                   p(0), p(1), p(2), ik_ok, cmd.deadman, fresh);
        }

        usleep(period_us);
    }

    printf("\n[IK] Shutting down...\n");
    if (fb_connected) UA_Client_disconnect(fb_client);
    UA_Client_delete(fb_client);
    if (bridge_connected) UA_Client_disconnect(bridge_client);
    UA_Client_delete(bridge_client);
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    printf("[IK] Done.\n");
    return 0;
}
