#include "input/gamepad_handler.h"
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cerrno>

namespace teleop {

GamepadHandler::GamepadHandler(const InputConfig &config) : config_(config) {}

GamepadHandler::~GamepadHandler() { stop(); }

bool GamepadHandler::start() {
    if (config_.evdev_path.empty()) {
        printf("[Gamepad] ERROR: evdev_path must be specified\n");
        return false;
    }
    evdev_fd_ = open(config_.evdev_path.c_str(), O_RDONLY | O_NONBLOCK);
    if (evdev_fd_ < 0) {
        printf("[Gamepad] ERROR: %s: %s\n", config_.evdev_path.c_str(), strerror(errno));
        return false;
    }
    int rc = libevdev_new_from_fd(evdev_fd_, &evdev_);
    if (rc < 0) { close(evdev_fd_); evdev_fd_ = -1; return false; }
    printf("[Gamepad] Opened: %s\n", libevdev_get_name(evdev_));

    running_.store(true);
    read_thread_ = std::thread(&GamepadHandler::readLoop, this);
    return true;
}

void GamepadHandler::stop() {
    running_.store(false);
    if (read_thread_.joinable()) read_thread_.join();
    if (evdev_) { libevdev_free(evdev_); evdev_ = nullptr; }
    if (evdev_fd_ >= 0) { close(evdev_fd_); evdev_fd_ = -1; }
}

void GamepadHandler::readLoop() {
    int period_us = 1000000 / config_.publish_hz;
    std::map<int, float> axis_values;
    std::map<int, bool>  button_states;

    while (running_.load()) {
        struct input_event ev;
        int rc;
        do {
            rc = libevdev_next_event(evdev_,
                LIBEVDEV_READ_FLAG_NORMAL | LIBEVDEV_READ_FLAG_BLOCKING, &ev);
            if (rc == LIBEVDEV_READ_STATUS_SUCCESS) {
                if (ev.type == EV_ABS) {
                    const struct input_absinfo *abs = libevdev_get_abs_info(evdev_, ev.code);
                    if (abs) {
                        float range = (float)(abs->maximum - abs->minimum);
                        float norm  = 2.0f * (ev.value - abs->minimum) / range - 1.0f;
                        axis_values[ev.code] = norm;
                    }
                } else if (ev.type == EV_KEY) {
                    if (ev.value != 2) button_states[ev.code] = (ev.value == 1);
                }
            }
        } while (rc == LIBEVDEV_READ_STATUS_SUCCESS ||
                 rc == LIBEVDEV_READ_STATUS_SYNC);

        CartesianInputCommand cmd;
        memset(&cmd, 0, sizeof(cmd));

        float vals[7] = {0};
        for (const auto &am : config_.axis_mappings) {
            float v = axis_values.count(am.axis_code) ? axis_values[am.axis_code] : 0.0f;
            if (am.invert) v = -v;
            if (std::abs(v) < am.deadzone) v = 0.0f;
            v *= am.scale;
            v = std::max(-1.0f, std::min(1.0f, v));
            if (am.axis_index >= 0 && am.axis_index < 7) vals[am.axis_index] = v;
        }
        for (const auto &bm : config_.button_mappings) {
            if (button_states.count(bm.button_code) && button_states[bm.button_code]) {
                if (bm.axis_index >= 0 && bm.axis_index < 7)
                    vals[bm.axis_index] = bm.direction;
            }
        }

        for (int i = 0; i < 3; i++) cmd.linear_vel[i]  = vals[i];
        for (int i = 0; i < 3; i++) cmd.angular_vel[i] = vals[3 + i];
        cmd.gripper_cmd = vals[6];
        cmd.deadman = (config_.deadman_button != 0) ?
                      (button_states.count(config_.deadman_button) &&
                       button_states[config_.deadman_button]) : true;
        cmd.stamp = stamp_counter_.fetch_add(1);

        {
            std::lock_guard<std::mutex> lock(cmd_mutex_);
            current_cmd_ = cmd;
        }
        usleep(period_us);
    }
}

CartesianInputCommand GamepadHandler::getCommand() {
    std::lock_guard<std::mutex> lock(cmd_mutex_);
    return current_cmd_;
}

} // namespace teleop
