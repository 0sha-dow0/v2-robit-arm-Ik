#include "input/input_device_factory.h"
#include <cstdio>

namespace teleop {

std::unique_ptr<InputDeviceHandler> createInputDevice(const InputConfig &config) {
    if (config.device_type == "keyboard") {
        printf("[Factory] Creating keyboard handler\n");
        return std::make_unique<KeyboardHandler>(config);
    } else if (config.device_type == "gamepad" || config.device_type == "joystick") {
        printf("[Factory] Creating gamepad handler\n");
        return std::make_unique<GamepadHandler>(config);
    }
    printf("[Factory] ERROR: Unknown device type: %s\n", config.device_type.c_str());
    return nullptr;
}

} // namespace teleop
