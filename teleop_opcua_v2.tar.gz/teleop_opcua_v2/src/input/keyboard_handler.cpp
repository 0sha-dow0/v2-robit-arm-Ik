#include "input/keyboard_handler.h"
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <cstring>
#include <cstdio>
#include <chrono>
#include <algorithm>
#include <cerrno>

namespace teleop {

KeyboardHandler::KeyboardHandler(const InputConfig &config) : config_(config) {
    for (int i = 0; i < 7; i++) ramped_values_[i] = 0.0f;
}

KeyboardHandler::~KeyboardHandler() {
    stop();
}

std::string KeyboardHandler::findKeyboardDevice() {
    if (!config_.evdev_path.empty()) return config_.evdev_path;

    DIR *dir = opendir("/dev/input");
    if (!dir) {
        printf("[Keyboard] Cannot open /dev/input\n");
        return "";
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (strncmp(entry->d_name, "event", 5) != 0) continue;
        std::string path = std::string("/dev/input/") + entry->d_name;

        int fd = open(path.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;

        struct libevdev *dev = nullptr;
        int rc = libevdev_new_from_fd(fd, &dev);
        if (rc < 0) { close(fd); continue; }

        bool has_keys = libevdev_has_event_type(dev, EV_KEY) &&
                        libevdev_has_event_code(dev, EV_KEY, KEY_A) &&
                        libevdev_has_event_code(dev, EV_KEY, KEY_SPACE);

        const char *name = libevdev_get_name(dev);
        printf("[Keyboard] Found: %s at %s (has_keys=%d)\n",
               name ? name : "unknown", path.c_str(), has_keys);

        libevdev_free(dev);
        close(fd);

        if (has_keys) {
            closedir(dir);
            printf("[Keyboard] Auto-selected: %s\n", path.c_str());
            return path;
        }
    }
    closedir(dir);
    return "";
}

bool KeyboardHandler::start() {
    std::string devpath = findKeyboardDevice();
    if (devpath.empty()) {
        printf("[Keyboard] ERROR: No device found\n");
        return false;
    }

    evdev_fd_ = open(devpath.c_str(), O_RDONLY | O_NONBLOCK);
    if (evdev_fd_ < 0) {
        printf("[Keyboard] ERROR: Cannot open %s: %s\n",
               devpath.c_str(), strerror(errno));
        return false;
    }

    int rc = libevdev_new_from_fd(evdev_fd_, &evdev_);
    if (rc < 0) {
        printf("[Keyboard] libevdev init failed: %s\n", strerror(-rc));
        close(evdev_fd_); evdev_fd_ = -1;
        return false;
    }
    printf("[Keyboard] Opened: %s\n", libevdev_get_name(evdev_));

    for (const auto &km : config_.key_mappings) key_states_[km.key_code] = false;
    if (config_.deadman_key != 0) key_states_[config_.deadman_key] = false;

    running_.store(true);
    read_thread_ = std::thread(&KeyboardHandler::readLoop, this);
    return true;
}

void KeyboardHandler::stop() {
    running_.store(false);
    if (read_thread_.joinable()) read_thread_.join();
    if (evdev_) { libevdev_free(evdev_); evdev_ = nullptr; }
    if (evdev_fd_ >= 0) { close(evdev_fd_); evdev_fd_ = -1; }
}

void KeyboardHandler::readLoop() {
    auto last_time = std::chrono::steady_clock::now();
    int period_us = 1000000 / config_.publish_hz;

    while (running_.load()) {
        struct input_event ev;
        int rc;
        do {
            rc = libevdev_next_event(evdev_,
                LIBEVDEV_READ_FLAG_NORMAL | LIBEVDEV_READ_FLAG_BLOCKING, &ev);
            if (rc == LIBEVDEV_READ_STATUS_SUCCESS) {
                if (ev.type == EV_KEY) {
                    int code = ev.code;
                    if (ev.value == 2) continue;  // skip repeat
                    bool pressed = (ev.value == 1);
                    if (code == config_.deadman_key) key_states_[code] = pressed;
                    if (key_states_.count(code)) key_states_[code] = pressed;
                }
            }
        } while (rc == LIBEVDEV_READ_STATUS_SUCCESS ||
                 rc == LIBEVDEV_READ_STATUS_SYNC);

        auto now = std::chrono::steady_clock::now();
        double dt = std::chrono::duration<double>(now - last_time).count();
        last_time = now;

        updateRamps(dt);

        CartesianInputCommand cmd;
        for (int i = 0; i < 3; i++) cmd.linear_vel[i]  = ramped_values_[i]     * config_.max_velocity;
        for (int i = 0; i < 3; i++) cmd.angular_vel[i] = ramped_values_[3 + i] * config_.max_velocity;
        cmd.gripper_cmd = ramped_values_[6];
        cmd.deadman = (config_.deadman_key != 0) ? key_states_[config_.deadman_key] : true;
        cmd.stamp = stamp_counter_.fetch_add(1);

        {
            std::lock_guard<std::mutex> lock(cmd_mutex_);
            current_cmd_ = cmd;
        }

        usleep(period_us);
    }
}

void KeyboardHandler::updateRamps(double dt) {
    float targets[7] = {0};
    for (const auto &km : config_.key_mappings) {
        auto it = key_states_.find(km.key_code);
        if (it != key_states_.end() && it->second) {
            targets[km.axis_index] += km.direction;
        }
    }
    for (int i = 0; i < 7; i++) {
        targets[i] = std::max(-1.0f, std::min(1.0f, targets[i]));
    }
    float ramp = config_.ramp_rate * (float)dt;
    for (int i = 0; i < 7; i++) {
        float diff = targets[i] - ramped_values_[i];
        if (std::abs(diff) < ramp) ramped_values_[i] = targets[i];
        else ramped_values_[i] += (diff > 0 ? ramp : -ramp);
    }
}

CartesianInputCommand KeyboardHandler::getCommand() {
    std::lock_guard<std::mutex> lock(cmd_mutex_);
    return current_cmd_;
}

} // namespace teleop
