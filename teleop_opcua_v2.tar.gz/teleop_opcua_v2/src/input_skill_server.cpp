#include "common/skill_types.h"
#include "common/config_loader.h"
#include "input/input_device_factory.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>

#include <csignal>
#include <cstdio>
#include <cstring>
#include <unistd.h>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

static void writeFloat(UA_Server *s, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Server_writeValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), val);
}
static void writeBool(UA_Server *s, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Server_writeValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), val);
}
static void writeUInt32(UA_Server *s, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Server_writeValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), val);
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    std::string config_path = "configs/keyboard.yaml";
    if (argc > 1) config_path = argv[1];

    printf("═══════════════════════════════════════════\n");
    printf("  OPC UA Input Skill Server (Cartesian)\n");
    printf("  Config: %s\n", config_path.c_str());
    printf("═══════════════════════════════════════════\n");

    teleop::InputConfig config;
    try { config = teleop::loadInputConfig(config_path); }
    catch (const std::exception &e) {
        printf("ERROR: %s\n", e.what()); return 1;
    }

    UA_Server *server = UA_Server_new();
    UA_ServerConfig *sc = UA_Server_getConfig(server);
    UA_ServerConfig_setMinimal(sc, config.opcua_port, NULL);
    sc->applicationDescription.applicationName =
        UA_LOCALIZEDTEXT_ALLOC("en-US", "CartesianInputSkillServer");

    if (teleop::addCartesianInputSkillNodes(server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: add skill nodes failed\n");
        UA_Server_delete(server); return 1;
    }

    if (UA_Server_run_startup(server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: server startup failed\n");
        UA_Server_delete(server); return 1;
    }
    printf("[Server] OPC UA server on port %d\n", config.opcua_port);

    auto device = teleop::createInputDevice(config);
    if (!device || !device->start()) {
        printf("ERROR: input device start failed\n");
        UA_Server_delete(server); return 1;
    }

    printf("[Server] Publishing at %d Hz. Press Ctrl+C to stop.\n\n", config.publish_hz);

    int period_us = 1000000 / config.publish_hz;
    uint32_t loop_count = 0;

    while (g_running) {
        UA_Server_run_iterate(server, false);
        teleop::CartesianInputCommand cmd = device->getCommand();

        writeFloat(server, teleop::opcua_ids::CART_VEL_X,     cmd.linear_vel[0]);
        writeFloat(server, teleop::opcua_ids::CART_VEL_Y,     cmd.linear_vel[1]);
        writeFloat(server, teleop::opcua_ids::CART_VEL_Z,     cmd.linear_vel[2]);
        writeFloat(server, teleop::opcua_ids::CART_VEL_ROLL,  cmd.angular_vel[0]);
        writeFloat(server, teleop::opcua_ids::CART_VEL_PITCH, cmd.angular_vel[1]);
        writeFloat(server, teleop::opcua_ids::CART_VEL_YAW,   cmd.angular_vel[2]);
        writeFloat(server, teleop::opcua_ids::CART_GRIPPER,   cmd.gripper_cmd);
        writeBool (server, teleop::opcua_ids::CART_DEADMAN,   cmd.deadman);
        writeUInt32(server, teleop::opcua_ids::CART_STAMP,    cmd.stamp);

        if (++loop_count % (config.publish_hz * 2) == 0) {
            printf("[Input] x=%.2f y=%.2f z=%.2f r=%.2f p=%.2f yw=%.2f "
                   "grip=%.2f dm=%d stamp=%u\n",
                   cmd.linear_vel[0], cmd.linear_vel[1], cmd.linear_vel[2],
                   cmd.angular_vel[0], cmd.angular_vel[1], cmd.angular_vel[2],
                   cmd.gripper_cmd, cmd.deadman, cmd.stamp);
        }
        usleep(period_us);
    }

    printf("\n[Server] Shutting down...\n");
    device->stop();
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    printf("[Server] Done.\n");
    return 0;
}
