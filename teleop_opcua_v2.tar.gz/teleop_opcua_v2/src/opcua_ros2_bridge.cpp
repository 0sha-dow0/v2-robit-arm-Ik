#include "common/skill_types.h"
#include "common/config_loader.h"
#include "bridge/bridge_node.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <rclcpp/rclcpp.hpp>

#include <csignal>
#include <cstdio>
#include <thread>
#include <chrono>

static volatile bool g_running = true;
static void signalHandler(int) {
    g_running = false;
    rclcpp::shutdown();
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("opcua_ros2_bridge");

    std::string config_path = "configs/bridge.yaml";
    if (argc > 1) config_path = argv[1];

    printf("═══════════════════════════════════════════\n");
    printf("  OPC UA ↔ ROS 2 Bridge\n");
    printf("  Config: %s\n", config_path.c_str());
    printf("═══════════════════════════════════════════\n");

    teleop::BridgeConfig config;
    try { config = teleop::loadBridgeConfig(config_path); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    // Command server (port 4842): ArmInput skill — IK server writes here
    UA_Server *cmd_server = UA_Server_new();
    UA_ServerConfig *cs = UA_Server_getConfig(cmd_server);
    UA_ServerConfig_setMinimal(cs, config.opcua_command_port, NULL);
    cs->applicationDescription.applicationName =
        UA_LOCALIZEDTEXT_ALLOC("en-US", "BridgeCommandServer");
    if (teleop::addArmInputSkillNodes(cmd_server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: add cmd skill nodes failed\n"); return 1;
    }
    if (UA_Server_run_startup(cmd_server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: cmd server startup failed\n"); return 1;
    }
    printf("[Bridge] Command OPC UA server on port %d\n", config.opcua_command_port);

    // Feedback server (port 4843): robot state — IK server + dashboard read here
    UA_Server *fb_server = UA_Server_new();
    UA_ServerConfig *fc = UA_Server_getConfig(fb_server);
    UA_ServerConfig_setMinimal(fc, config.opcua_feedback_port, NULL);
    fc->applicationDescription.applicationName =
        UA_LOCALIZEDTEXT_ALLOC("en-US", "BridgeFeedbackServer");
    if (teleop::addRobotFeedbackNodes(fb_server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: add feedback nodes failed\n"); return 1;
    }
    if (UA_Server_run_startup(fb_server) != UA_STATUSCODE_GOOD) {
        printf("ERROR: fb server startup failed\n"); return 1;
    }
    printf("[Bridge] Feedback OPC UA server on port %d\n", config.opcua_feedback_port);

    teleop::CommandBridge cmd_bridge(cmd_server, node, config);
    teleop::FeedbackBridge fb_bridge(fb_server, node, config, &cmd_bridge);

    printf("[Bridge] Running. Press Ctrl+C to stop.\n\n");

    rclcpp::executors::SingleThreadedExecutor executor;
    executor.add_node(node);

    int loop_count = 0;
    auto rate = std::chrono::milliseconds(20);

    while (g_running && rclcpp::ok()) {
        UA_Server_run_iterate(cmd_server, false);
        UA_Server_run_iterate(fb_server, false);
        executor.spin_some(std::chrono::milliseconds(1));

        cmd_bridge.tick();
        fb_bridge.tick();

        if (++loop_count % 250 == 0) {
            printf("[Bridge] Running... cmd_fresh=%d\n", cmd_bridge.isCommandFresh());
        }
        std::this_thread::sleep_for(rate);
    }

    printf("\n[Bridge] Shutting down...\n");
    UA_Server_run_shutdown(cmd_server);
    UA_Server_delete(cmd_server);
    UA_Server_run_shutdown(fb_server);
    UA_Server_delete(fb_server);
    rclcpp::shutdown();
    printf("[Bridge] Done.\n");
    return 0;
}
