#include "selector/selector_logic.h"
#include <cstdio>
#include <cstring>

namespace teleop {

SelectorLogic::SelectorLogic(const SelectorConfig &config)
    : config_(config), safety_(config.stale_timeout_ms) {}

SelectorLogic::~SelectorLogic() { shutdown(); }

static float readFloat(UA_Client *c, uint32_t id) {
    UA_Variant val; UA_Variant_init(&val);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(opcua_ids::NS, id), &val);
    float r = 0.0f;
    if (val.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)val.data;
    UA_Variant_clear(&val);
    return r;
}
static bool readBool(UA_Client *c, uint32_t id) {
    UA_Variant val; UA_Variant_init(&val);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(opcua_ids::NS, id), &val);
    bool r = false;
    if (val.type == &UA_TYPES[UA_TYPES_BOOLEAN]) r = *(UA_Boolean*)val.data;
    UA_Variant_clear(&val);
    return r;
}
static uint32_t readUInt32(UA_Client *c, uint32_t id) {
    UA_Variant val; UA_Variant_init(&val);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(opcua_ids::NS, id), &val);
    uint32_t r = 0;
    if (val.type == &UA_TYPES[UA_TYPES_UINT32]) r = *(UA_UInt32*)val.data;
    UA_Variant_clear(&val);
    return r;
}
static void writeFloat(UA_Client *c, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(opcua_ids::NS, id), &val);
}
static void writeBool(UA_Client *c, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(opcua_ids::NS, id), &val);
}
static void writeUInt32(UA_Client *c, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(opcua_ids::NS, id), &val);
}

bool SelectorLogic::initialize() {
    for (const auto &pe : config_.providers) {
        ProviderState ps;
        ps.name = pe.name; ps.endpoint = pe.endpoint; ps.priority = pe.priority;
        ps.client = UA_Client_new();
        UA_ClientConfig_setDefault(UA_Client_getConfig(ps.client));

        printf("[Selector] Connecting to '%s' at %s ...\n",
               ps.name.c_str(), ps.endpoint.c_str());
        UA_StatusCode st = UA_Client_connect(ps.client, ps.endpoint.c_str());
        ps.connected = (st == UA_STATUSCODE_GOOD);
        ps.last_update = std::chrono::steady_clock::now();
        if (ps.connected) printf("[Selector] Connected to '%s'\n", ps.name.c_str());
        else printf("[Selector] WARN: connect '%s' failed: 0x%08x\n", ps.name.c_str(), st);

        providers_.push_back(std::move(ps));
    }

    ik_client_ = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(ik_client_));
    printf("[Selector] Connecting to IK server at %s ...\n", config_.ik_endpoint.c_str());
    UA_StatusCode st = UA_Client_connect(ik_client_, config_.ik_endpoint.c_str());
    ik_connected_ = (st == UA_STATUSCODE_GOOD);
    printf("[Selector] IK server: %s\n", ik_connected_ ? "OK" : "FAIL");

    return true;
}

bool SelectorLogic::readProvider(ProviderState &prov, CartesianInputCommand &cmd) {
    if (!prov.connected) {
        UA_StatusCode st = UA_Client_connect(prov.client, prov.endpoint.c_str());
        if (st != UA_STATUSCODE_GOOD) return false;
        prov.connected = true;
        printf("[Selector] Reconnected to '%s'\n", prov.name.c_str());
    }

    cmd.linear_vel[0]  = readFloat(prov.client, opcua_ids::CART_VEL_X);
    cmd.linear_vel[1]  = readFloat(prov.client, opcua_ids::CART_VEL_Y);
    cmd.linear_vel[2]  = readFloat(prov.client, opcua_ids::CART_VEL_Z);
    cmd.angular_vel[0] = readFloat(prov.client, opcua_ids::CART_VEL_ROLL);
    cmd.angular_vel[1] = readFloat(prov.client, opcua_ids::CART_VEL_PITCH);
    cmd.angular_vel[2] = readFloat(prov.client, opcua_ids::CART_VEL_YAW);
    cmd.gripper_cmd    = readFloat(prov.client, opcua_ids::CART_GRIPPER);
    cmd.deadman        = readBool(prov.client, opcua_ids::CART_DEADMAN);
    cmd.stamp          = readUInt32(prov.client, opcua_ids::CART_STAMP);

    if (cmd.stamp != prov.last_stamp) {
        prov.last_stamp = cmd.stamp;
        prov.last_update = std::chrono::steady_clock::now();
        return true;
    }
    auto elapsed = std::chrono::duration<double, std::milli>(
        std::chrono::steady_clock::now() - prov.last_update).count();
    return elapsed < config_.stale_timeout_ms;
}

bool SelectorLogic::writeToIKServer(const CartesianInputCommand &cmd) {
    if (!ik_connected_) {
        UA_StatusCode st = UA_Client_connect(ik_client_, config_.ik_endpoint.c_str());
        if (st != UA_STATUSCODE_GOOD) return false;
        ik_connected_ = true;
    }
    writeFloat(ik_client_, opcua_ids::CART_VEL_X,     cmd.linear_vel[0]);
    writeFloat(ik_client_, opcua_ids::CART_VEL_Y,     cmd.linear_vel[1]);
    writeFloat(ik_client_, opcua_ids::CART_VEL_Z,     cmd.linear_vel[2]);
    writeFloat(ik_client_, opcua_ids::CART_VEL_ROLL,  cmd.angular_vel[0]);
    writeFloat(ik_client_, opcua_ids::CART_VEL_PITCH, cmd.angular_vel[1]);
    writeFloat(ik_client_, opcua_ids::CART_VEL_YAW,   cmd.angular_vel[2]);
    writeFloat(ik_client_, opcua_ids::CART_GRIPPER,   cmd.gripper_cmd);
    writeBool (ik_client_, opcua_ids::CART_DEADMAN,   cmd.deadman);
    writeUInt32(ik_client_, opcua_ids::CART_STAMP,    cmd.stamp);
    return true;
}

int SelectorLogic::selectBestProvider() {
    int best = -1, best_p = -1;
    for (size_t i = 0; i < providers_.size(); i++) {
        if (!providers_[i].connected) continue;
        auto elapsed = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - providers_[i].last_update).count();
        if (elapsed > config_.stale_timeout_ms * 2) continue;
        if (providers_[i].priority > best_p) {
            best_p = providers_[i].priority;
            best = (int)i;
        }
    }
    return best;
}

void SelectorLogic::tick() {
    std::vector<CartesianInputCommand> cmds(providers_.size());
    std::vector<bool> valid(providers_.size(), false);

    for (size_t i = 0; i < providers_.size(); i++) {
        valid[i] = readProvider(providers_[i], cmds[i]);
    }

    int best = selectBestProvider();
    if (best != active_index_ && best >= 0) {
        printf("[Selector] Switching to '%s' (prio %d)\n",
               providers_[best].name.c_str(), providers_[best].priority);
        active_index_ = best;
    }

    CartesianInputCommand out;
    memset(&out, 0, sizeof(out));
    if (best >= 0 && valid[best]) {
        out = cmds[best];
        safety_.setDeadman(out.deadman);
        if (out.deadman) safety_.markAlive();
    }

    if (safety_.shouldStop()) {
        for (int i = 0; i < 3; i++) { out.linear_vel[i] = 0; out.angular_vel[i] = 0; }
        out.gripper_cmd = 0;
    }

    writeToIKServer(out);
}

void SelectorLogic::shutdown() {
    for (auto &p : providers_) {
        if (p.client) {
            if (p.connected) UA_Client_disconnect(p.client);
            UA_Client_delete(p.client);
            p.client = nullptr;
        }
    }
    if (ik_client_) {
        if (ik_connected_) UA_Client_disconnect(ik_client_);
        UA_Client_delete(ik_client_);
        ik_client_ = nullptr;
    }
}

std::string SelectorLogic::getActiveProvider() const {
    if (active_index_ >= 0 && active_index_ < (int)providers_.size())
        return providers_[active_index_].name;
    return "none";
}

} // namespace teleop
