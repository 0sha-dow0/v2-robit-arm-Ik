#include "selector/selector_logic.h"
#include "common/config_loader.h"

#include <csignal>
#include <cstdio>
#include <unistd.h>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    std::string cfg = "configs/selector.yaml";
    if (argc > 1) cfg = argv[1];

    printf("═══════════════════════════════════════════\n");
    printf("  OPC UA Selector Client\n");
    printf("  Config: %s\n", cfg.c_str());
    printf("═══════════════════════════════════════════\n");

    teleop::SelectorConfig config;
    try { config = teleop::loadSelectorConfig(cfg); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    teleop::SelectorLogic selector(config);
    if (!selector.initialize()) { printf("ERROR: init\n"); return 1; }
    printf("[Selector] Running at 50 Hz. Ctrl+C to stop.\n\n");

    int loop = 0;
    while (g_running) {
        selector.tick();
        if (++loop % 100 == 0)
            printf("[Selector] Active: %s\n", selector.getActiveProvider().c_str());
        usleep(20000);
    }

    printf("\n[Selector] Shutting down...\n");
    selector.shutdown();
    return 0;
}
