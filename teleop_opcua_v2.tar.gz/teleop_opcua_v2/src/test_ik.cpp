#include "ik/ik_solver.h"
#include "ik/kinematics.h"
#include <iostream>
#include <iomanip>

int main() {
    using namespace teleop::ik;

    std::cout << "═══════════════════════════════════════════\n";
    std::cout << "  Standalone IK Math Test\n";
    std::cout << "═══════════════════════════════════════════\n\n";

    Eigen::Matrix4d M = getM();
    auto Slist = getSlist();

    std::cout << "M (home) =\n" << M << "\n\n";
    std::cout << "Slist =\n" << Slist << "\n\n";

    // Test 1: FK at home position
    Eigen::Matrix<double, NUM_JOINTS, 1> theta0;
    theta0.setZero();
    auto T_home = fkInSpace(M, Slist, theta0);
    std::cout << "FK at θ=0 should equal M:\n" << T_home << "\n\n";

    // Test 2: FK at θ = {0.5, 0.3, -0.2, 0.1, 0.0}
    Eigen::Matrix<double, NUM_JOINTS, 1> theta1;
    theta1 << 0.5, 0.3, -0.2, 0.1, 0.0;
    auto T1 = fkInSpace(M, Slist, theta1);
    std::cout << "FK at θ=(0.5,0.3,-0.2,0.1,0.0):\n" << T1 << "\n\n";

    // Test 3: IK round-trip - take the T1 from FK and see if we recover θ1
    IKParams params;
    JointLimitsEigen limits = JointLimitsEigen::vx300();
    Eigen::Matrix<double, NUM_JOINTS, 1> theta_seed;
    theta_seed.setZero();
    Eigen::Matrix<double, NUM_JOINTS, 1> theta_out;

    bool ok = solveIK(T1, theta_seed, params, limits, theta_out);
    std::cout << "IK round-trip result (expected θ=(0.5,0.3,-0.2,0.1,0.0)):\n";
    std::cout << "  Converged: " << (ok ? "YES" : "NO") << "\n";
    std::cout << "  θ_out = " << theta_out.transpose() << "\n\n";

    // Verify by FK
    auto T_verify = fkInSpace(M, Slist, theta_out);
    double pos_err = (T_verify.block<3, 1>(0, 3) - T1.block<3, 1>(0, 3)).norm();
    std::cout << "Position error: " << std::scientific << pos_err << " m\n";

    // Test 4: Jacobian sanity
    auto J = jacobianSpace(Slist, theta0);
    std::cout << "\nJacobian at home:\n" << J << "\n";

    return 0;
}
