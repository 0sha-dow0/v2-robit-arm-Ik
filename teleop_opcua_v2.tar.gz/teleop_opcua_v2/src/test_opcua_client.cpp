#include "common/skill_types.h"

#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <unistd.h>

static volatile bool g_running = true;
static void signalHandler(int) { g_running = false; }

int main(int argc, char *argv[]) {
    signal(SIGINT, signalHandler);
    std::string endpoint = "opc.tcp://localhost:4840";
    if (argc > 1) endpoint = argv[1];

    printf("Test client -> %s\n", endpoint.c_str());

    UA_Client *client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(client));
    if (UA_Client_connect(client, endpoint.c_str()) != UA_STATUSCODE_GOOD) {
        printf("ERROR: cannot connect\n"); return 1;
    }

    while (g_running) {
        uint32_t ids[] = {
            teleop::opcua_ids::CART_VEL_X, teleop::opcua_ids::CART_VEL_Y,
            teleop::opcua_ids::CART_VEL_Z, teleop::opcua_ids::CART_VEL_ROLL,
            teleop::opcua_ids::CART_VEL_PITCH, teleop::opcua_ids::CART_VEL_YAW,
            teleop::opcua_ids::CART_GRIPPER
        };
        const char *names[] = {"x","y","z","r","p","yw","g"};
        printf("\r");
        for (int i = 0; i < 7; i++) {
            UA_Variant v; UA_Variant_init(&v);
            UA_Client_readValueAttribute(client,
                UA_NODEID_NUMERIC(teleop::opcua_ids::NS, ids[i]), &v);
            float val = 0.0f;
            if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) val = *(UA_Float*)v.data;
            printf("%s=%+.2f ", names[i], val);
            UA_Variant_clear(&v);
        }
        fflush(stdout);
        usleep(100000);
    }

    UA_Client_disconnect(client);
    UA_Client_delete(client);
    return 0;
}
