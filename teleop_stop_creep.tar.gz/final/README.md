# VX-300 Target-State Teleop — Fix Summary

## Root cause of arm not moving

The previous teleop pipeline streamed Cartesian **velocities** through:
keyboard → input server → selector → IK server → bridge → ROS 2.

Three things broke it:

1. **5-DOF IK with 6-DOF target**: IK tried to control full pose including
   arbitrary yaw. With only 5 joints, most targets were unreachable, IK
   returned `ok=0`, arm stayed still. Fix: `yaw = atan2(y, x)` (derived, not
   independently controllable).
2. **Pulse loss across OPC UA hops**: each hop (input → selector → IK) runs
   at 50 Hz asynchronously; single-tick pulses got overwritten before they
   were read. Fix: keyboard handler now holds a pulse for 5 ticks (100 ms),
   and IK uses rising-edge detection to commit exactly one step per press.
3. **Velocity-mode against a position-mode arm**: the Interbotix arm driver
   is in `position` operating mode with `time` profile. Streaming velocities
   and reintegrating into positions inside the bridge drifted and produced
   near-zero net motion. Fix: maintain an **absolute target state** and
   compute `step = target - current` each tick, clamped to `MAX_STEP`.

## Architecture

```
keyboard (evdev) ──[pulses]──> input server (4840) ──> selector ──> IK node (4844)
                                                                       │
                                                               [target state]
                                                                       │
                                                                       ▼
                                                             IK (PoE + DLS + seeds)
                                                                       │
                                                                       ▼
                                                            bridge (4842) ──> /vx300/commands/joint_group
```

Bridge still does the ROS 2 publishing. IK node holds target state, solves,
and emits joint commands through bridge's OPC UA interface.

## Keyboard controls

| Key | Action | Step |
|-----|--------|------|
| W/S | ±x | 5 mm |
| A/D | ±y | 5 mm |
| R/F | ±z | 5 mm |
| I/K | ±pitch | 0.05 rad |
| U/J | ±wrist_rotate | 0.0873 rad (5°) |
| O/P | gripper open/close | 15% |

Each tap = one step. Hold a key → still one step (auto-repeat ignored).

## Install

```bash
cd ~/Downloads
tar xzf final_teleop.tar.gz

PROJ=~/Downloads/v2-robit-arm-Ik-master/teleop_opcua_v2
cp final/ik_server.cpp        $PROJ/src/ik_server.cpp
cp final/keyboard_handler.cpp $PROJ/src/input/keyboard_handler.cpp
cp final/keyboard.yaml        $PROJ/configs/keyboard.yaml

cd $PROJ/build
make -j$(nproc)
```

## Run (6 terminals, same as before)

T1: `ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=vx300 use_rviz:=true`
T2: `./opcua_ros2_bridge ../configs/bridge.yaml`
T3: `./ik_server ../configs/ik.yaml`
T4: `./input_skill_server ../configs/keyboard.yaml`
T5: `./selector_client ../configs/selector.yaml`
T6: `./feedback_receiver opc.tcp://localhost:4843`

## Self-check (no arm needed)

```bash
cd $PROJ/build
./test_ik
```

Round-trips FK→IK. Expected: position error < 1 mm, "Converged: YES".

## Assumptions

- Topic: `/vx300/commands/joint_group`, type `interbotix_xs_msgs/JointGroupCommand`
- Joint order: `[waist, shoulder, elbow, wrist_angle, wrist_rotate]`
- Operating mode: `position` with `time` profile (arm driver default)
- Gripper is a separate group; command passes through the same bridge path
- `yaw = atan2(y, x)` is baked in — no user-controllable yaw

## Troubleshooting

- **Nothing moves**: check T3 log for `[KEY] +X`, `[IK] SOLVED` — both must appear on each keypress.
- **`[IK] FAILED: target not reachable`**: target drifted outside workspace.
  Tap the opposite key a few times to bring target back in range.
- **Keyboard pulses appear but IK doesn't react**: selector may not be
  forwarding. Try running without selector (IK reads directly from 4840).
