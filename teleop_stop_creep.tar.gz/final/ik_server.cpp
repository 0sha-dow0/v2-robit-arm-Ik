// ─────────────────────────────────────────────────────────────
// IK Server — target-state based keyboard teleop for VX-300
// ─────────────────────────────────────────────────────────────
// Maintains absolute target (x,y,z, roll, pitch, gripper, wrist_rotate).
// Each keypress updates target, runs IK, writes absolute joint positions
// to the bridge. Bridge's joint_group command → ROS 2.
//
// yaw = atan2(y, x)  (vx300 is 5-DOF; no independent yaw)
//
// Keys (evdev codes read via OPC UA input server on port 4840):
//   W/S = +x/-x, A/D = +y/-y, R/F = +z/-z
//   I/K = +pitch/-pitch
//   U/J = +wrist_rotate/-wrist_rotate
//   O/P = gripper open/close
//   H   = home
//
// Uses:
//   - PoE forward kinematics
//   - Damped-least-squares Newton-Raphson IK
//   - Multiple seed attempts
//   - Joint-limit clamp + workspace clamp
// ─────────────────────────────────────────────────────────────

#include "common/skill_types.h"
#include "common/config_loader.h"
#include "ik/ik_solver.h"
#include "ik/kinematics.h"

#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/client.h>
#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include <csignal>
#include <cstdio>
#include <cmath>
#include <unistd.h>
#include <Eigen/Dense>

static volatile bool g_running = true;
static void sig_handler(int) { g_running = false; }

// ── OPC UA read/write helpers ───────────────────────────────
static float  readLocalFloat(UA_Server *s, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Server_readValue(s, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static float  clientReadFloat(UA_Client *c, uint32_t id) {
    UA_Variant v; UA_Variant_init(&v);
    UA_Client_readValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &v);
    float r = 0.0f;
    if (v.type == &UA_TYPES[UA_TYPES_FLOAT]) r = *(UA_Float*)v.data;
    UA_Variant_clear(&v);
    return r;
}
static void clientWriteFloat(UA_Client *c, uint32_t id, float v) {
    UA_Variant val; UA_Variant_setScalar(&val, &v, &UA_TYPES[UA_TYPES_FLOAT]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteBool(UA_Client *c, uint32_t id, bool v) {
    UA_Boolean b = v; UA_Variant val;
    UA_Variant_setScalar(&val, &b, &UA_TYPES[UA_TYPES_BOOLEAN]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}
static void clientWriteUInt32(UA_Client *c, uint32_t id, uint32_t v) {
    UA_UInt32 x = v; UA_Variant val;
    UA_Variant_setScalar(&val, &x, &UA_TYPES[UA_TYPES_UINT32]);
    UA_Client_writeValueAttribute(c, UA_NODEID_NUMERIC(teleop::opcua_ids::NS, id), &val);
}

// Build R from roll, pitch, yaw (ZYX)
static Eigen::Matrix3d rpyToR(double roll, double pitch, double yaw) {
    double cy = cos(yaw), sy = sin(yaw);
    double cp = cos(pitch), sp = sin(pitch);
    double cr = cos(roll), sr = sin(roll);
    Eigen::Matrix3d Rz, Ry, Rx;
    Rz << cy, -sy, 0,  sy, cy, 0,  0, 0, 1;
    Ry << cp, 0, sp,   0, 1, 0,   -sp, 0, cp;
    Rx << 1, 0, 0,   0, cr, -sr,  0, sr, cr;
    return Rz * Ry * Rx;
}

// Try IK with multiple seeds; return first valid solution.
// Enforces joint limits; returns false if no seed converges.
static bool solveWithSeeds(
    const Eigen::Matrix4d &T_target,
    const Eigen::Matrix<double, 5, 1> &current,
    const teleop::ik::IKParams &params,
    const teleop::ik::JointLimitsEigen &limits,
    Eigen::Matrix<double, 5, 1> &out)
{
    std::vector<Eigen::Matrix<double, 5, 1>> seeds;
    seeds.push_back(current);                                      // current joints
    Eigen::Matrix<double, 5, 1> z; z.setZero(); seeds.push_back(z); // zeros
    Eigen::Matrix<double, 5, 1> a; a.setZero(); a(0) = -2.094;      // waist -120°
    seeds.push_back(a);
    Eigen::Matrix<double, 5, 1> b; b.setZero(); b(0) =  2.094;      // waist +120°
    seeds.push_back(b);

    for (auto &seed : seeds) {
        Eigen::Matrix<double, 5, 1> solved = seed;
        bool ok = teleop::ik::solveIK(T_target, seed, params, limits, solved);
        if (!ok) continue;
        // Validate limits strictly
        bool in_limits = true;
        for (int i = 0; i < 5; i++) {
            if (solved(i) < limits.lower(i) - 1e-6 ||
                solved(i) > limits.upper(i) + 1e-6) {
                in_limits = false; break;
            }
        }
        if (!in_limits) continue;
        out = solved;
        return true;
    }
    return false;
}

int main(int argc, char *argv[]) {
    signal(SIGINT,  sig_handler);
    signal(SIGTERM, sig_handler);
    std::string config_path = "configs/ik.yaml";
    if (argc > 1) config_path = argv[1];

    printf("╔══════════════════════════════════════════════╗\n");
    printf("║  IK Teleop — target-state, vx300, 5-DOF      ║\n");
    printf("║  yaw = atan2(y,x) (not independently ctrl'd) ║\n");
    printf("╚══════════════════════════════════════════════╝\n");

    teleop::IKConfig config;
    try { config = teleop::loadIKConfig(config_path); }
    catch (const std::exception &e) { printf("ERROR: %s\n", e.what()); return 1; }

    // Our own OPC UA server (for the input channel at port 4844)
    UA_Server *server = UA_Server_new();
    UA_ServerConfig_setMinimal(UA_Server_getConfig(server), config.opcua_port, NULL);
    if (teleop::addCartesianInputSkillNodes(server) != UA_STATUSCODE_GOOD) return 1;
    if (UA_Server_run_startup(server) != UA_STATUSCODE_GOOD) return 1;
    printf("[IK] OPC UA in-server on port %d\n", config.opcua_port);

    // Clients: feedback (joint states) + bridge (command sink)
    UA_Client *fb_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(fb_client));
    bool fb_connected = false;
    UA_Client *bridge_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(bridge_client));
    bool bridge_connected = false;

    // IK parameters
    teleop::ik::IKParams ik_params;
    ik_params.max_iterations = 50;
    ik_params.eps_pos = 1e-3;
    ik_params.eps_ori = 1e-3;
    ik_params.damping_lambda = 0.1;
    ik_params.jl_weight = 0.02;
    auto limits = teleop::ik::JointLimitsEigen::vx300();

    // ─── STEP SIZES (per spec) ───
    const double STEP_XYZ   = 0.005;     // 5 mm
    const double STEP_PITCH = 0.05;      // 0.05 rad
    const double STEP_WRIST = 0.0872665; // 5°
    const float  STEP_GRIP  = 0.15f;     // 15% of gripper range

    // ─── TARGET STATE (absolute) ───
    Eigen::Vector3d tgt_pos;        // x, y, z
    double tgt_roll  = 0.0;
    double tgt_pitch = 0.0;
    double tgt_wrist = 0.0;         // wrist_rotate joint (joint 4)
    float  tgt_grip  = 0.0f;
    bool   state_init = false;

    // Current joints (from feedback)
    Eigen::Matrix<double, 5, 1> current_joints; current_joints.setZero();
    // Last valid solved joints (seed + command)
    Eigen::Matrix<double, 5, 1> last_solution; last_solution.setZero();
    bool last_solution_valid = false;

    // Edge-detection state for keyboard (rising edge)
    bool e_xp=false, e_xn=false, e_yp=false, e_yn=false, e_zp=false, e_zn=false;
    bool e_pp=false, e_pn=false, e_wp=false, e_wn=false, e_gp=false, e_gn=false;

    uint32_t loop_count = 0;

    printf("[IK] step_xyz=%.3fm step_pitch=%.3frad step_wrist=%.3frad step_grip=%.2f\n",
           STEP_XYZ, STEP_PITCH, STEP_WRIST, STEP_GRIP);

    while (g_running) {
        UA_Server_run_iterate(server, false);

        // Connect / reconnect
        if (!fb_connected && UA_Client_connect(fb_client,
                config.feedback_endpoint.c_str()) == UA_STATUSCODE_GOOD) {
            fb_connected = true;
            printf("[IK] feedback server connected: %s\n",
                   config.feedback_endpoint.c_str());
        }
        if (!bridge_connected && UA_Client_connect(bridge_client,
                config.bridge_endpoint.c_str()) == UA_STATUSCODE_GOOD) {
            bridge_connected = true;
            printf("[IK] bridge connected: %s\n", config.bridge_endpoint.c_str());
        }

        // Read current joints
        if (fb_connected) {
            for (int i = 0; i < 5; i++) {
                current_joints(i) = (double)clientReadFloat(
                    fb_client, teleop::opcua_ids::FB_JOINT_POS_BASE + i);
            }
        }

        // Read input (from selector or directly, doesn't matter — we treat
        // the in-server vars as the source of truth for this IK node)
        float vx    = readLocalFloat(server, teleop::opcua_ids::CART_VEL_X);
        float vy    = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Y);
        float vz    = readLocalFloat(server, teleop::opcua_ids::CART_VEL_Z);
        float vpitch= readLocalFloat(server, teleop::opcua_ids::CART_VEL_PITCH);
        float vwrist= readLocalFloat(server, teleop::opcua_ids::CART_VEL_YAW);  // reuse yaw axis → wrist
        float vgrip = readLocalFloat(server, teleop::opcua_ids::CART_GRIPPER);

        // Initialize state from current pose once feedback arrives
        if (!state_init && fb_connected) {
            Eigen::Matrix4d T0 = teleop::ik::fkInSpace(
                teleop::ik::getM(), teleop::ik::getSlist(), current_joints);
            tgt_pos = T0.block<3, 1>(0, 3);
            Eigen::Matrix3d R = T0.block<3, 3>(0, 0);
            tgt_pitch = atan2(-R(2,0), sqrt(R(2,1)*R(2,1) + R(2,2)*R(2,2)));
            tgt_roll  = 0.0;                      // not independently controllable either
            tgt_wrist = current_joints(4);
            last_solution = current_joints;
            last_solution_valid = true;
            state_init = true;
            printf("[IK] init: pos=(%.3f,%.3f,%.3f) pitch=%.3f wrist=%.3f\n",
                   tgt_pos(0), tgt_pos(1), tgt_pos(2), tgt_pitch, tgt_wrist);
        }

        // ── Edge detection ──
        const float TH = 0.5f;
        bool xp = vx >  TH, xn = vx < -TH;
        bool yp = vy >  TH, yn = vy < -TH;
        bool zp = vz >  TH, zn = vz < -TH;
        bool pp = vpitch >  TH, pn = vpitch < -TH;
        bool wp = vwrist >  TH, wn = vwrist < -TH;
        bool gp = vgrip  >  TH, gn = vgrip  < -TH;

        bool any_step = false;
        Eigen::Vector3d new_pos = tgt_pos;
        double new_pitch = tgt_pitch;
        double new_wrist = tgt_wrist;
        float  new_grip  = tgt_grip;

        if (xp && !e_xp) { new_pos(0) += STEP_XYZ; any_step = true; printf("[KEY] +X\n"); }
        if (xn && !e_xn) { new_pos(0) -= STEP_XYZ; any_step = true; printf("[KEY] -X\n"); }
        if (yp && !e_yp) { new_pos(1) += STEP_XYZ; any_step = true; printf("[KEY] +Y\n"); }
        if (yn && !e_yn) { new_pos(1) -= STEP_XYZ; any_step = true; printf("[KEY] -Y\n"); }
        if (zp && !e_zp) { new_pos(2) += STEP_XYZ; any_step = true; printf("[KEY] +Z\n"); }
        if (zn && !e_zn) { new_pos(2) -= STEP_XYZ; any_step = true; printf("[KEY] -Z\n"); }
        if (pp && !e_pp) { new_pitch += STEP_PITCH; any_step = true; printf("[KEY] +pitch\n"); }
        if (pn && !e_pn) { new_pitch -= STEP_PITCH; any_step = true; printf("[KEY] -pitch\n"); }
        if (wp && !e_wp) { new_wrist += STEP_WRIST; any_step = true; printf("[KEY] +wrist\n"); }
        if (wn && !e_wn) { new_wrist -= STEP_WRIST; any_step = true; printf("[KEY] -wrist\n"); }
        if (gp && !e_gp) {
            new_grip += STEP_GRIP;
            if (new_grip > 1.0f) new_grip = 1.0f;
            any_step = true; printf("[KEY] grip+\n");
        }
        if (gn && !e_gn) {
            new_grip -= STEP_GRIP;
            if (new_grip < -1.0f) new_grip = -1.0f;
            any_step = true; printf("[KEY] grip-\n");
        }
        e_xp=xp; e_xn=xn; e_yp=yp; e_yn=yn; e_zp=zp; e_zn=zn;
        e_pp=pp; e_pn=pn; e_wp=wp; e_wn=wn; e_gp=gp; e_gn=gn;

        // Clamp wrist to its joint limit
        new_wrist = std::max(limits.lower(4), std::min(limits.upper(4), new_wrist));
        // Clamp pitch to a sane range
        new_pitch = std::max(-1.4, std::min(1.4, new_pitch));

        // Workspace clamp
        new_pos(0) = std::max(0.10, std::min(0.55, new_pos(0)));
        new_pos(1) = std::max(-0.40, std::min(0.40, new_pos(1)));
        new_pos(2) = std::max(0.05, std::min(0.55, new_pos(2)));

        // If ANY step happened AND we have state, run IK
        if (any_step && state_init) {
            // Derive yaw from new target position: yaw = atan2(y, x)
            double new_yaw = atan2(new_pos(1), new_pos(0));

            // Build target transform
            Eigen::Matrix4d T_target = Eigen::Matrix4d::Identity();
            T_target.block<3, 3>(0, 0) = rpyToR(tgt_roll, new_pitch, new_yaw);
            T_target.block<3, 1>(0, 3) = new_pos;

            Eigen::Matrix<double, 5, 1> solved;
            bool ok = solveWithSeeds(
                T_target,
                last_solution_valid ? last_solution : current_joints,
                ik_params, limits, solved);

            if (ok) {
                // Override wrist_rotate joint with our step target (5-DOF convention)
                solved(4) = new_wrist;
                // Commit new state
                tgt_pos   = new_pos;
                tgt_pitch = new_pitch;
                tgt_wrist = new_wrist;
                last_solution = solved;
                last_solution_valid = true;
                printf("[IK] SOLVED yaw(derived)=%.3f joints=(%.2f,%.2f,%.2f,%.2f,%.2f)\n",
                       new_yaw, solved(0), solved(1), solved(2), solved(3), solved(4));
            } else {
                printf("[IK] FAILED: target (%.3f,%.3f,%.3f) not reachable — reverting\n",
                       new_pos(0), new_pos(1), new_pos(2));
                // Don't update tgt_* on failure → arm won't chase unreachable target
            }

            // Gripper is independent of IK
            tgt_grip = new_grip;
        }

        // ── Publish joint positions to the bridge ──
        // Bridge expects JOINT_VEL_* in [-1,1] range (velocity-scaled).
        // We convert absolute target → joint-step-per-tick then normalize.
        if (bridge_connected && last_solution_valid) {
            const double dt = 0.02;
            const double MAX_STEP = 0.04;   // rad per tick ceiling
            const double DEADBAND = 0.003;  // rad — stop sending once within this
            const float  BRIDGE_MAX = 1.0f;

            float jvel[5];
            for (int i = 0; i < 5; i++) {
                double err = last_solution(i) - current_joints(i);
                // DEADBAND: if we're close enough to target, send ZERO velocity.
                // Prevents continuous creep from noise / integration drift.
                if (std::abs(err) < DEADBAND) {
                    jvel[i] = 0.0f;
                    continue;
                }
                double step = err;
                if (step >  MAX_STEP) step =  MAX_STEP;
                if (step < -MAX_STEP) step = -MAX_STEP;
                double raw_vel = step / dt;
                float n = (float)(raw_vel / BRIDGE_MAX);
                if (n >  1.0f) n =  1.0f;
                if (n < -1.0f) n = -1.0f;
                jvel[i] = n;
            }

            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WAIST,       jvel[0]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_SHOULDER,    jvel[1]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_ELBOW,       jvel[2]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ANGLE, jvel[3]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::JOINT_VEL_WRIST_ROT,   jvel[4]);
            clientWriteFloat(bridge_client, teleop::opcua_ids::GRIPPER_CMD,           tgt_grip);
            clientWriteBool (bridge_client, teleop::opcua_ids::DEADMAN, true);
            clientWriteUInt32(bridge_client, teleop::opcua_ids::STAMP, loop_count);
        }

        if (++loop_count % 100 == 0 && state_init) {
            printf("[IK] TGT pos=(%.3f,%.3f,%.3f) pitch=%.2f wrist=%.2f "
                   "grip=%.2f | CUR joints=(%.2f,%.2f,%.2f,%.2f,%.2f)\n",
                   tgt_pos(0), tgt_pos(1), tgt_pos(2), tgt_pitch, tgt_wrist, tgt_grip,
                   current_joints(0), current_joints(1), current_joints(2),
                   current_joints(3), current_joints(4));
        }

        usleep(20000); // 50 Hz
    }

    printf("\n[IK] Shutting down...\n");
    if (fb_connected)    UA_Client_disconnect(fb_client);
    UA_Client_delete(fb_client);
    if (bridge_connected) UA_Client_disconnect(bridge_client);
    UA_Client_delete(bridge_client);
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    return 0;
}
